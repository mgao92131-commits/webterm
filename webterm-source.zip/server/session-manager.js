import { TerminalSession } from './terminal-session.js';

export class SessionManager {
  constructor({ SessionClass = TerminalSession } = {}) {
    this.sessions = new Map();
    this.managerClients = new Set();
    this.nextID = 1;
    this.SessionClass = SessionClass;
  }

  list() {
    return [...this.sessions.values()].map((session) => session.info());
  }

  get(id) {
    return this.sessions.get(id);
  }

  create({ name, cwd }) {
    const id = `s${this.nextID}`;
    let session;
    try {
      session = new this.SessionClass({
        id,
        name,
        cwd,
        onExit: (sessionID) => this.removeExited(sessionID),
        onInfo: (info) => this.broadcastManager({ type: 'session', data: info }),
      });
    } catch (err) {
      throw new Error(`failed to start terminal session: ${err.message}`);
    }
    this.nextID += 1;
    this.sessions.set(id, session);
    this.broadcastManager({ type: 'session', data: session.info() });
    return session;
  }

  rename(id, name) {
    const session = this.get(id);
    if (!session) return null;
    session.rename(name);
    return session;
  }

  close(id) {
    const session = this.get(id);
    if (!session) return false;
    session.close();
    this.sessions.delete(id);
    this.broadcastManager({ type: 'session-closed', id });
    return true;
  }

  removeExited(id) {
    if (!this.sessions.delete(id)) return;
    this.broadcastManager({ type: 'session-closed', id });
  }

  attachManager(ws) {
    const client = new ManagerClient(ws);
    this.managerClients.add(client);
    if (process.env.WEBTERM_TRACE_TITLE === '1') {
      console.log(`[TitleTrace][Server] manager attached clients=${this.managerClients.size}`);
    }
    client.send({ type: 'sessions', data: this.list() });
    ws.on('close', () => {
      this.managerClients.delete(client);
    });
    ws.on('error', () => {
      this.managerClients.delete(client);
    });
  }

  broadcastManager(message) {
    if (process.env.WEBTERM_TRACE_TITLE === '1') {
      const info = message?.data || {};
      const id = message?.id || info.id || '';
      const title = info.termTitle || '';
      console.log(`[TitleTrace][Server] manager broadcast type=${message?.type} id=${id} termTitle=${JSON.stringify(title)} clients=${this.managerClients.size}`);
    }
    for (const client of [...this.managerClients]) {
      if (!client.send(message)) {
        this.managerClients.delete(client);
      }
    }
  }
}

class ManagerClient {
  constructor(ws) {
    this.ws = ws;
  }

  send(message) {
    if (this.ws.readyState !== 1) return false;
    try {
      this.ws.send(JSON.stringify(message));
      return true;
    } catch {
      return false;
    }
  }
}
