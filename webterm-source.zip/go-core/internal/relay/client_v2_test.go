package relay

import (
	"bytes"
	"context"
	"errors"
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	"nhooyr.io/websocket"

	"webterm/go-core/internal/app"
	"webterm/go-core/internal/config"
	"webterm/go-core/internal/protocol"
	"webterm/go-core/internal/relayapp"
	"webterm/go-core/internal/relaycontrol"
	"webterm/go-core/internal/testutil"
)

func TestV2ClientWorksWithGoRelayHTTPAndWebSocket(t *testing.T) {
	testutil.SkipIfLoopbackListenUnavailable(t)

	relayApp := relayapp.NewInMemory(relayapp.Config{})
	user, err := relayApp.Store().CreateUser("owner@example.com", "secret", "admin")
	if err != nil {
		t.Fatalf("CreateUser returned error: %v", err)
	}
	device, credential, err := relayApp.Store().CreateDevice(user.ID, "Go Agent")
	if err != nil {
		t.Fatalf("CreateDevice returned error: %v", err)
	}
	token, err := relayApp.Store().IssueToken(user.ID, time.Hour)
	if err != nil {
		t.Fatalf("IssueToken returned error: %v", err)
	}

	server := httptest.NewServer(relayApp.Handler())
	defer server.Close()

	cfg := config.Config{
		Mode:  config.ModeRelay,
		Relay: config.RelayConfig{URL: server.URL, Secret: credential, DeviceName: "Go Agent"},
		Shell: config.ShellConfig{Command: "/bin/sh", CWD: "."},
	}
	agentApp := app.New(cfg, "test")
	client := NewV2(cfg.Relay, agentApp)
	ctx, cancel := context.WithTimeout(context.Background(), 8*time.Second)
	defer cancel()
	errCh := make(chan error, 1)
	go func() {
		errCh <- client.runOnce(ctx)
	}()
	waitForV2Presence(t, relayApp, user.ID, device.ID)

	req, err := http.NewRequestWithContext(ctx, http.MethodPost, server.URL+"/api/sessions", bytes.NewBufferString(`{"name":"v2","cwd":"."}`))
	if err != nil {
		t.Fatalf("new request: %v", err)
	}
	req.AddCookie(&http.Cookie{Name: relaycontrol.AuthCookieName, Value: token.Value})
	req.Header.Set("x-device-id", device.ID)
	res, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatalf("create session request failed: %v", err)
	}
	body, _ := io.ReadAll(res.Body)
	res.Body.Close()
	if res.StatusCode != http.StatusCreated {
		t.Fatalf("create session status = %d body=%s", res.StatusCode, body)
	}
	if !strings.Contains(string(body), `"id":"s1"`) {
		t.Fatalf("create session body = %s, want s1", body)
	}

	wsURL := "ws" + strings.TrimPrefix(server.URL, "http") + "/ws/terminal/s1?deviceId=" + device.ID
	ws, _, err := websocket.Dial(ctx, wsURL, &websocket.DialOptions{
		HTTPHeader:   http.Header{"Cookie": []string{(&http.Cookie{Name: relaycontrol.AuthCookieName, Value: token.Value}).String()}},
		Subprotocols: []string{protocol.BinarySubprotocol},
	})
	if err != nil {
		t.Fatalf("terminal websocket dial failed: %v", err)
	}
	defer ws.Close(websocket.StatusNormalClosure, "")

	hello := append([]byte{protocol.MsgHello}, []byte(`{"lastSeq":0,"cols":80,"rows":24}`)...)
	if err := ws.Write(ctx, websocket.MessageBinary, hello); err != nil {
		t.Fatalf("write hello: %v", err)
	}
	if err := ws.Write(ctx, websocket.MessageBinary, append([]byte{protocol.MsgInput}, []byte("printf V2_RELAY_OK\\n\r")...)); err != nil {
		t.Fatalf("write input: %v", err)
	}

	deadline := time.Now().Add(5 * time.Second)
	for time.Now().Before(deadline) {
		messageType, data, err := ws.Read(ctx)
		if err != nil {
			t.Fatalf("read terminal output: %v", err)
		}
		if messageType != websocket.MessageBinary || len(data) == 0 {
			continue
		}
		if data[0] == protocol.MsgOutput && strings.Contains(string(data), "V2_RELAY_OK") {
			cancel()
			if err := <-errCh; !isContextCanceledError(err) {
				t.Fatalf("client returned %v, want context.Canceled", err)
			}
			return
		}
	}
	t.Fatalf("did not receive V2_RELAY_OK")
}

func isContextCanceledError(err error) bool {
	if err == nil {
		return false
	}
	message := err.Error()
	return errors.Is(err, context.Canceled) ||
		strings.Contains(message, "context canceled") ||
		strings.Contains(message, "use of closed network connection")
}

func waitForV2Presence(t *testing.T, relayApp *relayapp.App, userID, deviceID string) {
	t.Helper()
	deadline := time.Now().Add(2 * time.Second)
	for time.Now().Before(deadline) {
		if _, ok := relayApp.Registry().GetAgentForUser(userID, deviceID); ok {
			return
		}
		time.Sleep(10 * time.Millisecond)
	}
	t.Fatalf("agent presence %s/%s did not appear", userID, deviceID)
}
