package relaystore

import (
	"crypto/rand"
	"crypto/sha256"
	"crypto/subtle"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"sync"
	"time"
)

var (
	ErrNotFound       = errors.New("not found")
	ErrConflict       = errors.New("conflict")
	ErrUnauthorized   = errors.New("unauthorized")
	ErrInvalidInput   = errors.New("invalid input")
	ErrDeviceDisabled = errors.New("device disabled")
)

type User struct {
	ID           string
	Username     string
	PasswordHash string
	Role         string
	Disabled     bool
	CreatedAt    time.Time
}

type Device struct {
	ID             string
	UserID         string
	Name           string
	CredentialHash string
	Disabled       bool
	CreatedAt      time.Time
	LastSeenAt     time.Time
}

type Token struct {
	Value     string
	UserID    string
	ExpiresAt time.Time
	Revoked   bool
}

type MemoryStore struct {
	mu            sync.RWMutex
	now           func() time.Time
	persistPath   string
	nextUserID    int
	nextDeviceID  int
	users         map[string]User
	usersByName   map[string]string
	devices       map[string]Device
	tokens        map[string]Token
	refreshTokens map[string]Token
}

func NewMemoryStore() *MemoryStore {
	return &MemoryStore{
		now:           time.Now,
		nextUserID:    1,
		nextDeviceID:  1,
		users:         make(map[string]User),
		usersByName:   make(map[string]string),
		devices:       make(map[string]Device),
		tokens:        make(map[string]Token),
		refreshTokens: make(map[string]Token),
	}
}

func NewPersistentStore(path string) (*MemoryStore, error) {
	store := NewMemoryStore()
	store.persistPath = path
	if path == "" {
		return store, nil
	}
	data, err := os.ReadFile(path)
	if errors.Is(err, os.ErrNotExist) {
		return store, nil
	}
	if err != nil {
		return nil, err
	}
	var snapshot storeSnapshot
	if err := json.Unmarshal(data, &snapshot); err != nil {
		return nil, err
	}
	store.nextUserID = snapshot.NextUserID
	if store.nextUserID <= 0 {
		store.nextUserID = 1
	}
	store.nextDeviceID = snapshot.NextDeviceID
	if store.nextDeviceID <= 0 {
		store.nextDeviceID = 1
	}
	for _, user := range snapshot.Users {
		store.users[user.ID] = user
		store.usersByName[user.Username] = user.ID
	}
	for _, device := range snapshot.Devices {
		store.devices[device.ID] = device
	}
	for _, token := range snapshot.Tokens {
		store.tokens[token.Value] = token
	}
	for _, token := range snapshot.RefreshTokens {
		store.refreshTokens[token.Value] = token
	}
	return store, nil
}

func (store *MemoryStore) CreateUser(username, password, role string) (User, error) {
	if username == "" || password == "" {
		return User{}, ErrInvalidInput
	}
	if role == "" {
		role = "user"
	}
	passwordHash, err := HashPassword(password)
	if err != nil {
		return User{}, err
	}

	store.mu.Lock()
	defer store.mu.Unlock()
	if _, exists := store.usersByName[username]; exists {
		return User{}, ErrConflict
	}
	id := fmt.Sprintf("u%d", store.nextUserID)
	store.nextUserID++
	user := User{
		ID:           id,
		Username:     username,
		PasswordHash: passwordHash,
		Role:         role,
		CreatedAt:    store.now().UTC(),
	}
	store.users[id] = user
	store.usersByName[username] = id
	if err := store.saveLocked(); err != nil {
		delete(store.users, id)
		delete(store.usersByName, username)
		store.nextUserID--
		return User{}, err
	}
	return user, nil
}

func (store *MemoryStore) AuthenticateUser(username, password string) (User, error) {
	store.mu.RLock()
	id, ok := store.usersByName[username]
	if !ok {
		store.mu.RUnlock()
		return User{}, ErrUnauthorized
	}
	user := store.users[id]
	store.mu.RUnlock()
	if user.Disabled || !VerifyPassword(password, user.PasswordHash) {
		return User{}, ErrUnauthorized
	}
	return user, nil
}

func (store *MemoryStore) FindUser(id string) (User, bool) {
	store.mu.RLock()
	defer store.mu.RUnlock()
	user, ok := store.users[id]
	return user, ok
}

func (store *MemoryStore) IssueToken(userID string, ttl time.Duration) (Token, error) {
	if ttl <= 0 {
		return Token{}, ErrInvalidInput
	}
	store.mu.Lock()
	defer store.mu.Unlock()
	user, ok := store.users[userID]
	if !ok || user.Disabled {
		return Token{}, ErrUnauthorized
	}
	value, err := randomToken(32)
	if err != nil {
		return Token{}, err
	}
	token := Token{
		Value:     value,
		UserID:    userID,
		ExpiresAt: store.now().UTC().Add(ttl),
	}
	store.tokens[value] = token
	if err := store.saveLocked(); err != nil {
		delete(store.tokens, value)
		return Token{}, err
	}
	return token, nil
}

func (store *MemoryStore) IssueRefreshToken(userID string, ttl time.Duration) (Token, error) {
	if ttl <= 0 {
		return Token{}, ErrInvalidInput
	}
	store.mu.Lock()
	defer store.mu.Unlock()
	user, ok := store.users[userID]
	if !ok || user.Disabled {
		return Token{}, ErrUnauthorized
	}
	value, err := randomToken(32)
	if err != nil {
		return Token{}, err
	}
	token := Token{
		Value:     value,
		UserID:    userID,
		ExpiresAt: store.now().UTC().Add(ttl),
	}
	store.refreshTokens[value] = token
	if err := store.saveLocked(); err != nil {
		delete(store.refreshTokens, value)
		return Token{}, err
	}
	return token, nil
}

func (store *MemoryStore) RefreshTokens(refreshValue string, accessTTL, refreshTTL time.Duration) (Token, Token, error) {
	if refreshValue == "" || accessTTL <= 0 || refreshTTL <= 0 {
		return Token{}, Token{}, ErrInvalidInput
	}
	store.mu.Lock()
	defer store.mu.Unlock()
	current, ok := store.refreshTokens[refreshValue]
	if !ok || current.Revoked || !store.now().UTC().Before(current.ExpiresAt) {
		return Token{}, Token{}, ErrUnauthorized
	}
	user, ok := store.users[current.UserID]
	if !ok || user.Disabled {
		return Token{}, Token{}, ErrUnauthorized
	}
	accessValue, err := randomToken(32)
	if err != nil {
		return Token{}, Token{}, err
	}
	refreshValueNext, err := randomToken(32)
	if err != nil {
		return Token{}, Token{}, err
	}
	now := store.now().UTC()
	access := Token{
		Value:     accessValue,
		UserID:    user.ID,
		ExpiresAt: now.Add(accessTTL),
	}
	refresh := Token{
		Value:     refreshValueNext,
		UserID:    user.ID,
		ExpiresAt: now.Add(refreshTTL),
	}
	current.Revoked = true
	store.refreshTokens[refreshValue] = current
	store.tokens[access.Value] = access
	store.refreshTokens[refresh.Value] = refresh
	if err := store.saveLocked(); err != nil {
		delete(store.tokens, access.Value)
		delete(store.refreshTokens, refresh.Value)
		current.Revoked = false
		store.refreshTokens[refreshValue] = current
		return Token{}, Token{}, err
	}
	return access, refresh, nil
}

func (store *MemoryStore) AuthenticateToken(value string) (User, error) {
	store.mu.RLock()
	token, ok := store.tokens[value]
	if !ok || token.Revoked || !store.now().UTC().Before(token.ExpiresAt) {
		store.mu.RUnlock()
		return User{}, ErrUnauthorized
	}
	user, ok := store.users[token.UserID]
	store.mu.RUnlock()
	if !ok || user.Disabled {
		return User{}, ErrUnauthorized
	}
	return user, nil
}

func (store *MemoryStore) CreateDevice(userID, name string) (Device, string, error) {
	if userID == "" || name == "" {
		return Device{}, "", ErrInvalidInput
	}
	secret, err := randomToken(32)
	if err != nil {
		return Device{}, "", err
	}
	store.mu.Lock()
	defer store.mu.Unlock()
	if _, ok := store.users[userID]; !ok {
		return Device{}, "", ErrNotFound
	}
	id := fmt.Sprintf("d%d", store.nextDeviceID)
	store.nextDeviceID++
	now := store.now().UTC()
	device := Device{
		ID:             id,
		UserID:         userID,
		Name:           name,
		CredentialHash: CredentialHash(secret),
		CreatedAt:      now,
		LastSeenAt:     now,
	}
	store.devices[id] = device
	if err := store.saveLocked(); err != nil {
		delete(store.devices, id)
		store.nextDeviceID--
		return Device{}, "", err
	}
	return device, secret, nil
}

func (store *MemoryStore) ListDevices(userID string) []Device {
	store.mu.RLock()
	defer store.mu.RUnlock()
	devices := make([]Device, 0)
	for _, device := range store.devices {
		if device.UserID == userID {
			devices = append(devices, device)
		}
	}
	return devices
}

func (store *MemoryStore) FindDeviceForUser(userID, deviceID string) (Device, error) {
	store.mu.RLock()
	defer store.mu.RUnlock()
	device, ok := store.devices[deviceID]
	if !ok || device.UserID != userID {
		return Device{}, ErrNotFound
	}
	return device, nil
}

func (store *MemoryStore) SetDeviceDisabled(userID, deviceID string, disabled bool) (Device, error) {
	store.mu.Lock()
	defer store.mu.Unlock()
	device, ok := store.devices[deviceID]
	if !ok || device.UserID != userID {
		return Device{}, ErrNotFound
	}
	previous := device
	device.Disabled = disabled
	store.devices[deviceID] = device
	if err := store.saveLocked(); err != nil {
		store.devices[deviceID] = previous
		return Device{}, err
	}
	return device, nil
}

func (store *MemoryStore) DeleteDevice(userID, deviceID string) error {
	store.mu.Lock()
	defer store.mu.Unlock()
	device, ok := store.devices[deviceID]
	if !ok || device.UserID != userID {
		return ErrNotFound
	}
	delete(store.devices, deviceID)
	if err := store.saveLocked(); err != nil {
		store.devices[deviceID] = device
		return err
	}
	return nil
}

func (store *MemoryStore) RotateDeviceCredential(userID, deviceID string) (Device, string, error) {
	secret, err := randomToken(32)
	if err != nil {
		return Device{}, "", err
	}
	store.mu.Lock()
	defer store.mu.Unlock()
	device, ok := store.devices[deviceID]
	if !ok || device.UserID != userID {
		return Device{}, "", ErrNotFound
	}
	previous := device
	device.CredentialHash = CredentialHash(secret)
	store.devices[deviceID] = device
	if err := store.saveLocked(); err != nil {
		store.devices[deviceID] = previous
		return Device{}, "", err
	}
	return device, secret, nil
}

func (store *MemoryStore) FindDeviceByCredential(secret string) (Device, error) {
	hash := CredentialHash(secret)
	store.mu.RLock()
	defer store.mu.RUnlock()
	for _, device := range store.devices {
		if subtle.ConstantTimeCompare([]byte(device.CredentialHash), []byte(hash)) == 1 {
			if device.Disabled {
				return Device{}, ErrDeviceDisabled
			}
			return device, nil
		}
	}
	return Device{}, ErrUnauthorized
}

func (store *MemoryStore) TouchDevice(deviceID string, at time.Time) error {
	store.mu.Lock()
	defer store.mu.Unlock()
	device, ok := store.devices[deviceID]
	if !ok {
		return ErrNotFound
	}
	previous := device
	device.LastSeenAt = at.UTC()
	store.devices[deviceID] = device
	if err := store.saveLocked(); err != nil {
		store.devices[deviceID] = previous
		return err
	}
	return nil
}

type storeSnapshot struct {
	NextUserID    int      `json:"nextUserId"`
	NextDeviceID  int      `json:"nextDeviceId"`
	Users         []User   `json:"users"`
	Devices       []Device `json:"devices"`
	Tokens        []Token  `json:"tokens"`
	RefreshTokens []Token  `json:"refreshTokens"`
}

func (store *MemoryStore) saveLocked() error {
	if store.persistPath == "" {
		return nil
	}
	snapshot := storeSnapshot{
		NextUserID:    store.nextUserID,
		NextDeviceID:  store.nextDeviceID,
		Users:         make([]User, 0, len(store.users)),
		Devices:       make([]Device, 0, len(store.devices)),
		Tokens:        make([]Token, 0, len(store.tokens)),
		RefreshTokens: make([]Token, 0, len(store.refreshTokens)),
	}
	for _, user := range store.users {
		snapshot.Users = append(snapshot.Users, user)
	}
	for _, device := range store.devices {
		snapshot.Devices = append(snapshot.Devices, device)
	}
	for _, token := range store.tokens {
		snapshot.Tokens = append(snapshot.Tokens, token)
	}
	for _, token := range store.refreshTokens {
		snapshot.RefreshTokens = append(snapshot.RefreshTokens, token)
	}
	data, err := json.MarshalIndent(snapshot, "", "  ")
	if err != nil {
		return err
	}
	data = append(data, '\n')
	if err := os.MkdirAll(filepath.Dir(store.persistPath), 0o700); err != nil {
		return err
	}
	tmp := store.persistPath + ".tmp"
	if err := os.WriteFile(tmp, data, 0o600); err != nil {
		return err
	}
	return os.Rename(tmp, store.persistPath)
}

func CredentialHash(secret string) string {
	sum := sha256.Sum256([]byte(secret))
	return hex.EncodeToString(sum[:])
}

func HashPassword(password string) (string, error) {
	salt, err := randomBytes(16)
	if err != nil {
		return "", err
	}
	sum := sha256.Sum256(append(salt, []byte(password)...))
	return base64.RawURLEncoding.EncodeToString(salt) + "$" + hex.EncodeToString(sum[:]), nil
}

func VerifyPassword(password, stored string) bool {
	parts := splitOnce(stored, '$')
	if parts == nil {
		return false
	}
	saltText, hashText := parts[0], parts[1]
	salt, err := base64.RawURLEncoding.DecodeString(saltText)
	if err != nil {
		return false
	}
	sum := sha256.Sum256(append(salt, []byte(password)...))
	expected := hex.EncodeToString(sum[:])
	return subtle.ConstantTimeCompare([]byte(expected), []byte(hashText)) == 1
}

func splitOnce(value string, sep byte) []string {
	for i := 0; i < len(value); i++ {
		if value[i] == sep {
			return []string{value[:i], value[i+1:]}
		}
	}
	return nil
}

func randomToken(size int) (string, error) {
	data, err := randomBytes(size)
	if err != nil {
		return "", err
	}
	return base64.RawURLEncoding.EncodeToString(data), nil
}

func randomBytes(size int) ([]byte, error) {
	data := make([]byte, size)
	if _, err := rand.Read(data); err != nil {
		return nil, err
	}
	return data, nil
}
