import { createRequire } from 'node:module';
import * as fs from 'fs';
import pty from 'node-pty';

const require = createRequire(import.meta.url);
const { Terminal } = require('@xterm/headless');
const { SerializeAddon } = require('@xterm/addon-serialize');

const term = new Terminal({
  cols: 100,
  rows: 30,
  scrollback: 10000,
  allowProposedApi: true,
  windowsMode: false
});
const serializeAddon = new SerializeAddon();
term.loadAddon(serializeAddon);

const ptyProcess = pty.spawn('/Users/gao/.local/bin/claude', ['plugins', 'list'], {
  name: 'xterm-color',
  cols: 100,
  rows: 30,
  cwd: process.cwd(),
  env: process.env
});

let rawData = [];
ptyProcess.onData((data) => {
  const buf = Buffer.from(data, 'utf8');
  rawData.push(buf);
});

ptyProcess.onExit(({ exitCode, signal }) => {
  const rawBuffer = Buffer.concat(rawData);
  fs.writeFileSync('scripts/claude_raw.bin', rawBuffer);
  
  term.write(rawBuffer, () => {
    const snapshot = serializeAddon.serialize();
    fs.writeFileSync('scripts/claude_node_snapshot.txt', snapshot);
    console.log(`Generated raw bin (${rawBuffer.length} bytes) and node snapshot (${snapshot.length} bytes)`);
    process.exit(0);
  });
});
