import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import http from 'node:http';
import net from 'node:net';
import os from 'node:os';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { WebSocket } from 'ws';
import {
  BINARY_SUBPROTOCOL,
  MSG_HELLO,
  MSG_INPUT,
  MSG_OUTPUT,
  MSG_STATE,
} from '../shared/constants.js';

const args = parseArgs(process.argv.slice(2));
const agentPath = args.agent;
const cwd = args.cwd || process.cwd();
const timeoutMs = Number(args.timeout || 15000);
const repoRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

if (!agentPath) {
  console.error('--agent is required');
  process.exit(2);
}

const deadline = Date.now() + timeoutMs;
const tempDir = await fs.mkdtemp(path.join(os.tmpdir(), 'webterm-go-relay-smoke-'));
const dbPath = path.join(tempDir, 'relay.db');
const jwtSecret = crypto.randomBytes(32).toString('hex');
const user = {
  username: 'smoke@example.com',
  password: 'smoke-password-123',
  deviceCookie: 'smoke-browser-device',
};

class CookieJar {
  #values = new Map();

  set(cookie) {
    const [pair] = cookie.split(';');
    const index = pair.indexOf('=');
    if (index <= 0) return;
    this.#values.set(pair.slice(0, index).trim(), pair.slice(index + 1).trim());
  }

  addSetCookie(values) {
    if (!values) return;
    for (const value of Array.isArray(values) ? values : [values]) {
      this.set(value);
    }
  }

  header() {
    return Array.from(this.#values.entries())
      .map(([key, value]) => `${key}=${value}`)
      .join('; ');
  }
}

let relayProcess;
let agentProcess;

try {
  process.env.WEBTERM_DB_PATH = dbPath;
  process.env.JWT_SECRET = jwtSecret;
  const { default: db } = await import('../server/db.js');
  const { hashPassword } = await import('../server/auth.js');
  const { createUser } = await import('../server/stores/user-store.js');
  const { addTrustedDevice } = await import('../server/stores/trusted-device-store.js');
  const { createDevice } = await import('../server/stores/device-store.js');

  const passwordHash = await hashPassword(user.password);
  const createdUser = createUser(
    user.username,
    passwordHash,
    'admin',
    new Date().toISOString(),
  );
  addTrustedDevice(createdUser.id, user.deviceCookie, 'Smoke Browser');
  const device = createDevice(createdUser.id, 'Go Core Relay Smoke');
  db.close();

  const relayPort = await freePort();
  relayProcess = spawn(process.execPath, ['relay-server/main.js'], {
    cwd: repoRoot,
    env: {
      ...process.env,
      WEBTERM_DB_PATH: dbPath,
      JWT_SECRET: jwtSecret,
      RELAY_PORT: String(relayPort),
      WEBTERM_STRICT_ORIGIN: '0',
    },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  const relayOutput = captureOutput(relayProcess);
  await waitForText(relayOutput, 'WebTerm Relay Server listening', 'relay server');

  const baseURL = `http://127.0.0.1:${relayPort}`;
  const cookieJar = new CookieJar();
  cookieJar.set(`webterm_device_id=${user.deviceCookie}`);
  await requestJSON({
    method: 'POST',
    url: `${baseURL}/api/auth/login`,
    cookieJar,
    body: { username: user.username, password: user.password },
  });

  agentProcess = spawn(agentPath, ['--mode', 'relay'], {
    cwd,
    env: {
      ...process.env,
      RELAY_URL: baseURL,
      RELAY_SECRET: device.agentSecret,
      DEVICE_NAME: 'Go Core Relay Smoke',
      WEBTERM_CONTROL_ADDR: '127.0.0.1:0',
      WEBTERM_SHELL: '/bin/sh',
    },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  const agentOutput = captureOutput(agentProcess);
  await waitForDeviceOnline(baseURL, cookieJar, `d${device.id}`);

  const created = await requestJSON({
    method: 'POST',
    url: `${baseURL}/api/sessions`,
    cookieJar,
    body: { name: 'relay-server-smoke', cwd },
  });
  const sessionId = created.id;
  if (!sessionId) {
    throw new Error(`session create returned no id: ${JSON.stringify(created)}`);
  }

  await smokeTerminalViaRelay(baseURL, cookieJar, `d${device.id}`, sessionId);
  await smokeP2PFallback(baseURL, cookieJar, `d${device.id}`);
  console.log('go relay-server smoke ok');

  stopProcess(agentProcess);
  stopProcess(relayProcess);
  await Promise.allSettled([waitProcess(agentProcess), waitProcess(relayProcess)]);

  if (agentOutput.text.includes('webterm-agent failed')) {
    throw new Error(`agent reported failure:\n${agentOutput.text}`);
  }
} catch (error) {
  stopProcess(agentProcess);
  stopProcess(relayProcess);
  await Promise.allSettled([
    agentProcess ? waitProcess(agentProcess) : Promise.resolve(),
    relayProcess ? waitProcess(relayProcess) : Promise.resolve(),
  ]);
  console.error(`go relay-server smoke failed: ${error.message}`);
  process.exit(1);
} finally {
  await fs.rm(tempDir, { recursive: true, force: true });
}

async function smokeTerminalViaRelay(baseURL, cookieJar, deviceId, sessionId) {
  const globalSessionId = sessionId.includes(':') ? sessionId : `${deviceId}:${sessionId}`;
  const wsURL = new URL(`/ws/sessions/${encodeURIComponent(globalSessionId)}`, baseURL);
  wsURL.protocol = 'ws:';
  const ws = new WebSocket(wsURL, BINARY_SUBPROTOCOL, {
    headers: { Cookie: cookieJar.header() },
  });
  await onceOpen(ws);

  const helloPayload = Buffer.from(JSON.stringify({ lastSeq: 0, cols: 100, rows: 30 }));
  ws.send(Buffer.concat([Buffer.from([MSG_HELLO]), helloPayload]));

  const marker = `GO_RELAY_SERVER_SMOKE_${Date.now()}`;
  ws.send(Buffer.concat([Buffer.from([MSG_INPUT]), Buffer.from(`printf ${marker}\\n`)]));

  await new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('terminal output timeout')), remaining());
    ws.on('message', (data, isBinary) => {
      if (!isBinary) {
        if (String(data).includes(marker)) {
          clearTimeout(timer);
          resolve();
        }
        return;
      }
      const buffer = Buffer.from(data);
      if (buffer.length < 1) return;
      if (buffer[0] !== MSG_OUTPUT && buffer[0] !== MSG_STATE) return;
      const payload = buffer.length >= 9 ? buffer.subarray(9) : buffer.subarray(1);
      if (payload.includes(Buffer.from(marker))) {
        clearTimeout(timer);
        resolve();
      }
    });
    ws.on('error', (error) => {
      clearTimeout(timer);
      reject(error);
    });
    ws.on('close', () => {
      clearTimeout(timer);
      reject(new Error('terminal websocket closed before marker output'));
    });
  });
  ws.close();
}

async function smokeP2PFallback(baseURL, cookieJar, deviceId) {
  const started = Date.now();
  const response = await requestText({
    method: 'POST',
    url: `${baseURL}/api/p2p/offer`,
    cookieJar,
    body: {
      deviceId,
      sdp: 'v=0\r\no=- 0 0 IN IP4 127.0.0.1\r\ns=-\r\nt=0 0\r\n',
    },
    headers: { 'X-Client-Id': 'go-relay-smoke-client' },
  });
  if (response.statusCode !== 503) {
    throw new Error(`p2p fallback status ${response.statusCode}, want 503: ${response.body}`);
  }
  if (Date.now() - started > 5000) {
    throw new Error('p2p fallback took too long');
  }
}

async function waitForDeviceOnline(baseURL, cookieJar, deviceId) {
  while (Date.now() < deadline) {
    const devices = await requestJSON({
      method: 'GET',
      url: `${baseURL}/api/devices`,
      cookieJar,
    });
    if (Array.isArray(devices) && devices.some((device) => device.deviceId === deviceId && device.online)) {
      return;
    }
    await delay(100);
  }
  throw new Error(`device ${deviceId} did not become online`);
}

function requestJSON({ method, url, cookieJar, body }) {
  return requestText({ method, url, cookieJar, body }).then((response) => {
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw new Error(`${method} ${url} -> ${response.statusCode}: ${response.body}`);
    }
    try {
      return response.body ? JSON.parse(response.body) : {};
    } catch (error) {
      throw new Error(`invalid JSON response: ${response.body}; ${error.message}`);
    }
  });
}

function requestText({ method, url, cookieJar, body, headers = {} }) {
  return new Promise((resolve, reject) => {
    const data = body === undefined ? null : Buffer.from(JSON.stringify(body));
    const parsed = new URL(url);
    const request = http.request({
      method,
      hostname: parsed.hostname,
      port: parsed.port,
      path: parsed.pathname + parsed.search,
      headers: {
        ...(data ? { 'Content-Type': 'application/json', 'Content-Length': data.length } : {}),
        ...(cookieJar.header() ? { Cookie: cookieJar.header() } : {}),
        ...headers,
      },
    }, (response) => {
      cookieJar.addSetCookie(response.headers['set-cookie']);
      const chunks = [];
      response.on('data', (chunk) => chunks.push(chunk));
      response.on('end', () => {
        resolve({
          statusCode: response.statusCode,
          headers: response.headers,
          body: Buffer.concat(chunks).toString('utf8'),
        });
      });
    });
    request.on('error', reject);
    if (data) request.write(data);
    request.end();
  });
}

function captureOutput(child) {
  const state = { text: '' };
  for (const stream of [child.stdout, child.stderr]) {
    stream?.on('data', (chunk) => {
      state.text += chunk.toString('utf8');
    });
  }
  return state;
}

async function waitForText(output, text, label) {
  while (Date.now() < deadline) {
    if (output.text.includes(text)) return;
    await delay(50);
  }
  throw new Error(`${label} did not print ${text}; output:\n${output.text}`);
}

function onceOpen(ws) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('websocket open timeout')), remaining());
    ws.once('open', () => {
      clearTimeout(timer);
      resolve();
    });
    ws.once('error', (error) => {
      clearTimeout(timer);
      reject(error);
    });
  });
}

function freePort() {
  return new Promise((resolve, reject) => {
    const server = net.createServer();
    server.listen(0, '127.0.0.1', () => {
      const address = server.address();
      server.close(() => resolve(address.port));
    });
    server.on('error', reject);
  });
}

function waitProcess(child) {
  if (!child) return Promise.resolve();
  return new Promise((resolve) => {
    if (child.exitCode !== null || child.signalCode !== null) {
      resolve();
      return;
    }
    child.once('exit', resolve);
  });
}

function stopProcess(child) {
  if (child && child.exitCode === null && child.signalCode === null) {
    child.kill('SIGTERM');
  }
}

function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function remaining() {
  return Math.max(1, deadline - Date.now());
}

function parseArgs(items) {
  const parsed = {};
  for (let index = 0; index < items.length; index += 1) {
    const item = items[index];
    if (!item.startsWith('--')) continue;
    const key = item.slice(2);
    const value = items[index + 1]?.startsWith('--') ? true : items[index + 1];
    parsed[key] = value ?? true;
    if (value !== true) index += 1;
  }
  return parsed;
}
