package com.webterm.webterm_mobile

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
