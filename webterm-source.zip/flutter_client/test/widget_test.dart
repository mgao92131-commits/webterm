import 'dart:typed_data';
import 'package:flutter_test/flutter_test.dart';
import 'package:webterm_mobile/core/network/webterm_protocol.dart';
import 'package:webterm_mobile/core/network/webterm_urls.dart';
import 'package:webterm_mobile/models/go_core_agent.dart';
import 'package:webterm_mobile/models/server_config.dart';
import 'package:webterm_mobile/models/session_identity.dart';
import 'package:webterm_mobile/services/terminal_cache_scope.dart';

void main() {
  group('WebTermProtocol', () {
    test('frame() builds correct binary frame', () {
      final payload = Uint8List.fromList([0x01, 0x02, 0x03]);
      final frame = WebTermProtocol.frame(WebTermProtocol.msgInput, payload);
      expect(frame.length, 4);
      expect(frame[0], 0x01);
      expect(frame.sublist(1), payload);
    });

    test('frame() handles null payload', () {
      final frame = WebTermProtocol.frame(WebTermProtocol.msgHello, null);
      expect(frame.length, 1);
      expect(frame[0], 0x04);
    });

    test('readUint64() reads big-endian correctly', () {
      final data = Uint8List.fromList([
        0x00,
        0x00,
        0x00,
        0x00,
        0x00,
        0x00,
        0x00,
        0x2A,
      ]);
      expect(WebTermProtocol.readUint64(data, 0), 42);
    });

    test('controlPayload() decodes JSON', () {
      final payload = Uint8List.fromList('{"code": 0}'.codeUnits);
      final result = WebTermProtocol.controlPayload(payload);
      expect(result['code'], 0);
    });

    test('controlPayload() handles empty payload', () {
      expect(WebTermProtocol.controlPayload(null), {});
      expect(WebTermProtocol.controlPayload(Uint8List(0)), {});
    });
  });

  group('WebTermUrls', () {
    test('normalizeBaseUrl() adds http scheme', () {
      expect(
        WebTermUrls.normalizeBaseUrl('example.com:8081'),
        'http://example.com:8081',
      );
    });

    test('normalizeBaseUrl() strips trailing slash', () {
      expect(
        WebTermUrls.normalizeBaseUrl('http://example.com/'),
        'http://example.com',
      );
    });

    test('toWebSocketUrl() converts http to ws', () {
      expect(
        WebTermUrls.toWebSocketUrl('http://example.com'),
        'ws://example.com',
      );
    });

    test('toWebSocketUrl() converts https to wss', () {
      expect(
        WebTermUrls.toWebSocketUrl('https://example.com'),
        'wss://example.com',
      );
    });
  });

  group('SessionIdentity', () {
    test('value() prefers instanceId', () {
      final v = SessionIdentity.value('sess1', 'inst1', '2024-01-01');
      expect(v, 'instance:inst1');
    });

    test('value() falls back to createdAt', () {
      final v = SessionIdentity.value('sess1', '', '2024-01-01');
      expect(v, 'created:sess1@2024-01-01');
    });

    test('value() returns empty when neither is set', () {
      expect(SessionIdentity.value('sess1', '', ''), '');
    });
  });

  group('TerminalCacheScope', () {
    test('matches() returns true for same server', () {
      final server = ServerConfig(id: 'srv1', url: 'http://example.com');
      expect(
        TerminalCacheScope.matches(server, 'http://example.com', 'any-session'),
        true,
      );
    });

    test('matches() returns false for different server', () {
      final server = ServerConfig(id: 'srv1', url: 'http://example.com');
      expect(
        TerminalCacheScope.matches(server, 'http://other.com', 'any-session'),
        false,
      );
    });
  });

  group('ServerConfig', () {
    test('toJson() and fromJson() round-trip', () {
      final config = ServerConfig(
        id: 'test-1',
        name: 'Test Server',
        url: 'http://example.com',
        cookie: 'token=abc',
        username: 'user',
        password: 'pass',
        relayMaster: true,
      );
      final json = config.toJson();
      final restored = ServerConfig.fromJson(json);
      expect(restored.id, config.id);
      expect(restored.name, config.name);
      expect(restored.url, config.url);
      expect(restored.cookie, config.cookie);
      expect(restored.relayMaster, config.relayMaster);
    });

    test('copyWith() preserves unchanged fields', () {
      final config = ServerConfig(id: 'srv1', name: 'Old');
      final updated = config.copyWith(name: 'New');
      expect(updated.name, 'New');
      expect(updated.id, 'srv1');
    });
  });

  group('GoCoreAgent models', () {
    test('GoCoreAgentConfig parses nested config', () {
      final config = GoCoreAgentConfig.fromJson({
        'mode': 'relay',
        'direct': {
          'addr': '127.0.0.1:8080',
          'user': 'admin',
          'password': '********',
        },
        'relay': {
          'url': 'https://relay.example',
          'secret': 'secret',
          'deviceName': 'mac',
        },
        'shell': {'command': '/bin/zsh', 'cwd': '/Users/gao'},
      });
      expect(config.mode, 'relay');
      expect(config.direct.user, 'admin');
      expect(config.relay.url, 'https://relay.example');
      expect(config.shell.command, '/bin/zsh');
      expect(config.toJson()['mode'], 'relay');
    });

    test('GoCoreAgentStatus parses runtime fields', () {
      final status = GoCoreAgentStatus.fromJson({
        'running': true,
        'mode': 'direct',
        'configMode': 'relay',
        'restartRequired': true,
        'direct': {'listening': true, 'addr': '127.0.0.1:8080'},
        'relay': {
          'configured': true,
          'connected': false,
          'lastError': 'offline',
        },
        'sessions': {'count': 3},
      });
      expect(status.running, true);
      expect(status.directListening, true);
      expect(status.relayLastError, 'offline');
      expect(status.sessionCount, 3);
    });
  });
}
