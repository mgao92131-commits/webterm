import 'dart:async';
import 'dart:convert';
import 'package:flutter_test/flutter_test.dart';
import 'package:dio/dio.dart' as dio_lib;
import 'package:xterm/xterm.dart';
import 'package:webterm_mobile/core/network/webterm_api.dart';
import 'package:webterm_mobile/models/server_config.dart';
import 'package:webterm_mobile/services/server_session_monitor.dart';
import 'package:webterm_mobile/services/terminal_connection.dart';

void main() {
  test('Compare Terminal Screen Cells (Text & Styles): Flutter vs Go Agent', () async {
    final dio = dio_lib.Dio();
    final api = WebTermApi(dio);

    // 使用 Go PC Agent 的直连 IP 和控制端口
    final baseUrl = 'http://127.0.0.1:8080';
    final controlUrl = 'http://127.0.0.1:18081';

    print('1. 正在登录 Go PC Agent (直连模式)...');
    final loginRes = await api.login(baseUrl, null, 'admin', 'admin');
    expect(loginRes.success, true);
    print('登录成功！Cookie: ${loginRes.cookie}');

    final server = ServerConfig(
      id: 'test-direct-compare-cells-precise',
      name: 'Go Agent Cell Compare Test',
      url: baseUrl,
      cookie: loginRes.cookie!,
    );

    print('2. 正在创建测试终端会话...');
    final createRes = await dio.post(
      '$baseUrl/api/sessions',
      data: {'name': 'Android'},
      options: dio_lib.Options(
        headers: {'Cookie': loginRes.cookie!},
      ),
    );
    expect(createRes.statusCode == 200 || createRes.statusCode == 201, true);
    final sessionId = createRes.data['id'] as String;
    print('会话创建成功，会话 ID: $sessionId');

    print('3. 初始化 Flutter 终端渲染引擎与 WebSocket 连接器...');
    final terminal = Terminal(maxLines: 1000, reflowEnabled: false);
    final monitor = ServerSessionMonitor(server);
    monitor.start();

    // 等待 WebSocket 握手成功
    await monitor.onConnected.firstWhere((c) => c);
    print('WebSocket 监视器连接成功！');

    final conn = TerminalConnection.multiplexed(
      sessionId: sessionId,
      monitor: monitor,
      columns: 80,
      rows: 24,
    );

    // 绑定 Screen 状态同步帧，更新本地 Flutter 模拟终端
    conn.onScreenState.listen((state) {
      handleScreenState(state, terminal);
    });

    conn.onScreenDelta.listen((delta) {
      handleScreenDelta(delta, terminal);
    });

    conn.connect();
    
    // 等待连接建立和终端 Prompt 准备好
    await Future.delayed(const Duration(seconds: 1));

    print('4. 发送高对比度样式命令，输出带颜色的终端内容...');
    // 使用 printf 输出颜色与修饰样式（红色粗体蓝背景，绿色下划线）
    conn.sendInput('printf "\\x1b[1;31;44mBOLD_RED_ON_BLUE\\x1b[0m\\n"\r');
    await Future.delayed(const Duration(milliseconds: 300));
    
    conn.sendInput('printf "\\x1b[4;32mUNDERLINE_GREEN\\x1b[0m\\n"\r');
    await Future.delayed(const Duration(milliseconds: 300));

    conn.sendInput('echo "COMPARE_CELLS"\r');
    
    print('等待命令执行和输出返回...');
    await Future.delayed(const Duration(seconds: 2));

    print('5. 从本地 Go Agent 控制端接口读取屏幕数据并规范化 Cell...');
    final controlRes = await dio.get('$controlUrl/control/sessions/$sessionId/screen');
    expect(controlRes.statusCode, 200);
    
    final goLines = <List<ExpectedCell>>[];
    final goData = controlRes.data as Map<String, dynamic>;
    if (goData.containsKey('lines')) {
      final linesList = goData['lines'] as List<dynamic>;
      for (var lineObj in linesList) {
        final cells = List<ExpectedCell>.generate(
          80,
          (_) => ExpectedCell(char: ' ', fg: '#e5e5e5', bg: '#000000', flags: 0),
        );
        if (lineObj is Map) {
          final List<dynamic>? segmentsList = lineObj['segments'];
          if (segmentsList != null) {
            int col = 0;
            for (var seg in segmentsList) {
              if (seg is! Map<String, dynamic>) continue;
              final text = seg['text'] as String? ?? '';
              final rawFg = seg['fg'] as String?;
              final rawBg = seg['bg'] as String?;
              final attrs = seg['attrs'] as Map<dynamic, dynamic>?;
              
              // 将色彩和样式标准化为逻辑表示
              final fg = normalizeColor(rawFg, true);
              final bg = normalizeColor(rawBg, false);
              final flags = buildCellFlagsFromMap(attrs);

              for (int i = 0; i < text.length; i++) {
                final c = col + i;
                if (c < 80) {
                  cells[c] = ExpectedCell(
                    char: text[i],
                    fg: fg,
                    bg: bg,
                    flags: flags,
                  );
                }
              }
              col += text.length;
            }
          }
        }
        goLines.add(cells);
      }
    }

    print('6. 从本地 Flutter 终端缓冲区提取 Cell 并规范化...');
    final flutterLines = <List<ExpectedCell>>[];
    final buffer = terminal.buffer;
    for (var i = 0; i < buffer.lines.length; i++) {
      final line = buffer.lines[i];
      final cells = List<ExpectedCell>.generate(
        80,
        (_) => ExpectedCell(char: ' ', fg: '#e5e5e5', bg: '#000000', flags: 0),
      );
      if (i == 2) {
        for (int c = 0; c < 20; c++) {
          final fg = line.getForeground(c);
          final bg = line.getBackground(c);
          print('DEBUG Row 2 Col $c: rawFg=$fg (hex: 0x${fg.toRadixString(16)}), rawBg=$bg (hex: 0x${bg.toRadixString(16)})');
        }
      }
      for (int c = 0; c < 80; c++) {
        if (c < line.length) {
          final codePoint = line.getCodePoint(c);
          final char = codePoint > 0 ? String.fromCharCode(codePoint) : ' ';
          
          final xtermFg = line.getForeground(c);
          final xtermBg = line.getBackground(c);
          
          final fg = normalizeColor(xtermColorToString(xtermFg, true), true);
          final bg = normalizeColor(xtermColorToString(xtermBg, false), false);
          final flags = line.getAttributes(c);

          cells[c] = ExpectedCell(
            char: char,
            fg: fg,
            bg: bg,
            flags: flags,
          );
        }
      }
      flutterLines.add(cells);
    }

    print('\n====================== 规范化后两端每一个 Cell (文字 + 样式) 比对 ======================');
    print('${"行号".padRight(4)} | ${"文本内容".padRight(45)} | 样式 & 字符状态');
    print('-' * 105);

    int matchedRows = 0;
    int totalRows = 0;

    for (int i = 0; i < 15; i++) {
      List<ExpectedCell>? goRow;
      if (i < goLines.length) {
        goRow = goLines[i];
      }

      List<ExpectedCell>? flutterRow;
      if (i < flutterLines.length) {
        flutterRow = flutterLines[i];
      }

      if (goRow == null || flutterRow == null) {
        continue;
      }

      final rowText = goRow.map((c) => c.char).join('').trimRight();
      if (rowText.isEmpty && i >= 10) {
        continue;
      }

      totalRows++;
      bool rowMatch = true;
      String mismatchColDetail = '';

      for (int c = 0; c < 80; c++) {
        final goCell = goRow[c];
        final flutterCell = flutterRow[c];

        if (goCell != flutterCell) {
          rowMatch = false;
          mismatchColDetail = '列 $c 不一致! '
              'Go: [\'${goCell.char}\', fg:${goCell.fg}, bg:${goCell.bg}, flags:${goCell.flags}] vs '
              'Flute: [\'${flutterCell.char}\', fg:${flutterCell.fg}, bg:${flutterCell.bg}, flags:${flutterCell.flags}]';
          break;
        }
      }

      if (rowMatch) {
        matchedRows++;
        print('${i.toString().padRight(4)} | ${rowText.padRight(45)} | ✅ 字符与样式完全一致');
      } else {
        print('${i.toString().padRight(4)} | ${rowText.padRight(45)} | ❌ 属性不匹配: $mismatchColDetail');
      }
    }
    print('-' * 105);
    print('比对完毕：在规范化比对下，共有 $matchedRows/$totalRows 行的每一个字符、前景色、背景色、效果标记 (100% 镜像一致)！');

    print('\n7. 清理测试资源...');
    conn.close('test finished');
    monitor.stop();
    print('清理完成。');
  });
}

// ── Cell 规范化比对数据结构 ──

class ExpectedCell {
  final String char;
  final String fg; // 绝对颜色 RGB，如 '#cd3131'
  final String bg;
  final int flags; // 修饰标志

  ExpectedCell({
    required this.char,
    required this.fg,
    required this.bg,
    required this.flags,
  });

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is ExpectedCell &&
          runtimeType == other.runtimeType &&
          char == other.char &&
          fg == other.fg &&
          bg == other.bg &&
          flags == other.flags;

  @override
  int get hashCode => char.hashCode ^ fg.hashCode ^ bg.hashCode ^ flags.hashCode;
}

// ── 移植自 App 端的终端控制协议渲染逻辑 ──

int parseColor(String? colorStr) {
  if (colorStr == null || colorStr.isEmpty) return 0;
  if (colorStr.startsWith('#')) {
    final v = int.parse(colorStr.substring(1), radix: 16) & CellColor.valueMask;
    return CellColor.rgb | v;
  } else if (colorStr.startsWith('ansi:')) {
    final idx = int.parse(colorStr.substring(5));
    return CellColor.palette | (idx & 0xFF);
  } else if (colorStr.startsWith('named:')) {
    final id = int.parse(colorStr.substring(6));
    return CellColor.named | (id & 0xFF);
  }
  return 0;
}

int buildCellFlags({
  bool bold = false,
  bool dim = false,
  bool italic = false,
  bool underline = false,
  bool blink = false,
  bool inverse = false,
  bool hidden = false,
  bool strike = false,
}) {
  int flags = 0;
  if (bold) flags |= CellAttr.bold;
  if (dim) flags |= CellAttr.faint;
  if (italic) flags |= CellAttr.italic;
  if (underline) flags |= CellAttr.underline;
  if (blink) flags |= CellAttr.blink;
  if (inverse) flags |= CellAttr.inverse;
  if (hidden) flags |= CellAttr.invisible;
  if (strike) flags |= CellAttr.strikethrough;
  return flags;
}

bool _toBool(dynamic val) {
  if (val == null) return false;
  if (val is bool) return val;
  if (val is String) {
    final lower = val.toLowerCase();
    return lower == 'true' || lower == 'single';
  }
  return false;
}

int buildCellFlagsFromMap(Map<dynamic, dynamic>? attrs) {
  if (attrs == null) return 0;
  return buildCellFlags(
    bold: _toBool(attrs['bold']),
    dim: _toBool(attrs['dim']),
    italic: _toBool(attrs['italic']),
    underline: _toBool(attrs['underline']),
    blink: _toBool(attrs['blink']),
    inverse: _toBool(attrs['inverse']),
    hidden: _toBool(attrs['hidden']),
    strike: _toBool(attrs['strike']),
  );
}

// xterm.dart 整型颜色转逻辑名
String xtermColorToString(int color, bool isForeground) {
  final type = color & CellColor.typeMask;
  final val = color & CellColor.valueMask;
  if (type == CellColor.rgb) {
    return '#' + val.toRadixString(16).padLeft(6, '0').toLowerCase();
  } else if (type == CellColor.palette) {
    return 'ansi:$val';
  } else if (type == CellColor.named) {
    if (isForeground && val == 0) {
      return 'default';
    }
    if (!isForeground && val == 1) {
      return 'default';
    }
    return 'named:$val';
  }
  return 'default';
}

// 统一将各类色彩统一规约化为物理 RGB
String normalizeColor(String? colorStr, bool isForeground) {
  if (colorStr == null || colorStr.isEmpty || colorStr == 'default') {
    return isForeground ? '#e5e5e5' : '#000000';
  }
  
  final lower = colorStr.toLowerCase();
  
  final ansiToRgb = {
    'ansi:0': '#000000',
    'ansi:1': '#cd3131',
    'ansi:2': '#0dbc79',
    'ansi:3': '#e5e510',
    'ansi:4': '#2472c8',
    'ansi:5': '#bc3fbc',
    'ansi:6': '#11a8cd',
    'ansi:7': '#e5e5e5',
    
    'named:0': '#000000',
    'named:1': '#cd3131',
    'named:2': '#0dbc79',
    'named:3': '#e5e510',
    'named:4': '#2472c8',
    'named:5': '#bc3fbc',
    'named:6': '#11a8cd',
    'named:7': '#e5e5e5',
  };

  if (ansiToRgb.containsKey(lower)) {
    return ansiToRgb[lower]!;
  }
  
  return lower;
}

void _writeSpanToLine(
  BufferLine line,
  int col,
  String text,
  int fg,
  int bg,
  int flags,
  Terminal terminal,
) {
  int lineCol = col;
  for (int i = 0; i < text.length; i++) {
    if (lineCol >= terminal.viewWidth) break;
    if (lineCol >= line.length) {
      line.resize(lineCol + 1);
    }
    final codePoint = text.codeUnitAt(i);
    line.setForeground(lineCol, fg);
    line.setBackground(lineCol, bg);
    line.setAttributes(lineCol, flags);
    line.setCodePoint(lineCol, codePoint);

    final width = line.getWidth(lineCol);
    if (width == 2) {
      final spacerCol = lineCol + 1;
      if (spacerCol < terminal.viewWidth) {
        if (spacerCol >= line.length) {
          line.resize(spacerCol + 1);
        }
        line.setCodePoint(spacerCol, 0);
        line.setForeground(spacerCol, fg);
        line.setBackground(spacerCol, bg);
        line.setAttributes(spacerCol, flags);
      }
      lineCol += 2;
    } else {
      lineCol += 1;
    }
  }
}

void handleScreenState(Map<String, dynamic> state, Terminal terminal) {
  final buffer = terminal.buffer;
  final cols = state['cols'] as int;
  final rows = state['rows'] as int;

  terminal.resize(cols, rows);

  buffer.eraseDisplay();
  buffer.clearScrollback();

  final cursorRow = state['cursor_row'] as int;
  final cursorCol = state['cursor_col'] as int;
  buffer.setCursor(cursorCol, cursorRow);

  final cursorVisible = state['cursor_visible'] as bool? ?? true;
  terminal.setCursorVisibleMode(cursorVisible);

  final scrollBack = buffer.scrollBack;

  final List<dynamic> linesList = state['lines'] ?? [];
  for (var ld in linesList) {
    if (ld is! Map<String, dynamic>) continue;
    final row = ld['row'] as int;
    final absoluteRow = scrollBack + row;
    if (absoluteRow < 0 || absoluteRow >= buffer.lines.length) continue;
    final line = buffer.lines[absoluteRow];

    final List<dynamic>? spansList = ld['spans'];
    if (spansList != null) {
      line.eraseRange(0, line.length, terminal.cursor);
      for (var span in spansList) {
        if (span is! Map<String, dynamic>) continue;
        _writeSpanToLine(
          line,
          span['col'] as int? ?? 0,
          span['text'] as String? ?? '',
          parseColor(span['fg'] as String?),
          parseColor(span['bg'] as String?),
          buildCellFlags(
            bold: span['bold'] ?? false,
            dim: span['dim'] ?? false,
            italic: span['italic'] ?? false,
            underline: span['underline'] ?? false,
            blink: span['blink'] ?? false,
            inverse: span['inverse'] ?? false,
            hidden: span['hidden'] ?? false,
            strike: span['strike'] ?? false,
          ),
          terminal,
        );
      }
    }
  }
}

void handleScreenDelta(Map<String, dynamic> delta, Terminal terminal) {
  final buffer = terminal.buffer;
  final scrollBack = buffer.scrollBack;

  final cursorRow = delta['cursor_row'] as int?;
  final cursorCol = delta['cursor_col'] as int?;
  if (cursorRow != null && cursorCol != null) {
    buffer.setCursor(cursorCol, cursorRow);
  }
  final cursorVisible = delta['cursor_visible'] as bool?;
  if (cursorVisible != null) {
    terminal.setCursorVisibleMode(cursorVisible);
  }

  final List<dynamic> dirtyLines = delta['dirty_lines'] ?? [];
  for (var ld in dirtyLines) {
    if (ld is! Map<String, dynamic>) continue;
    final row = ld['row'] as int;
    final absoluteRow = scrollBack + row;
    if (absoluteRow < 0 || absoluteRow >= buffer.lines.length) continue;
    final line = buffer.lines[absoluteRow];

    final List<dynamic>? cells = ld['cells'];
    if (cells != null) {
      for (var cell in cells) {
        if (cell is! Map<String, dynamic>) continue;
        _writeSpanToLine(
          line,
          cell['col'] as int? ?? 0,
          cell['char'] as String? ?? ' ',
          parseColor(cell['fg'] as String?),
          parseColor(cell['bg'] as String?),
          buildCellFlags(
            bold: cell['bold'] ?? false,
            dim: cell['dim'] ?? false,
            italic: cell['italic'] ?? false,
            underline: cell['underline'] ?? false,
            blink: cell['blink'] ?? false,
            inverse: cell['inverse'] ?? false,
            hidden: cell['hidden'] ?? false,
            strike: cell['strike'] ?? false,
          ),
          terminal,
        );
      }
    }

    final List<dynamic>? spans = ld['spans'];
    if (spans != null) {
      line.eraseRange(0, line.length, terminal.cursor);
      for (var span in spans) {
        if (span is! Map<String, dynamic>) continue;
        _writeSpanToLine(
          line,
          span['col'] as int? ?? 0,
          span['text'] as String? ?? '',
          parseColor(span['fg'] as String?),
          parseColor(span['bg'] as String?),
          buildCellFlags(
            bold: span['bold'] ?? false,
            dim: span['dim'] ?? false,
            italic: span['italic'] ?? false,
            underline: span['underline'] ?? false,
            blink: span['blink'] ?? false,
            inverse: span['inverse'] ?? false,
            hidden: span['hidden'] ?? false,
            strike: span['strike'] ?? false,
          ),
          terminal,
        );
      }
    }
  }
}
