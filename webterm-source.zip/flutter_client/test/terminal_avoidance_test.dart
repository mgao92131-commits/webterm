import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:xterm/xterm.dart';
import 'package:webterm_mobile/core/providers/app_providers.dart';
import 'package:webterm_mobile/core/storage/terminal_disk_cache.dart';
import 'package:webterm_mobile/screens/terminal_screen.dart';

// Fake TerminalDiskCache that returns dummy results for Riverpod setup
class FakeTerminalDiskCache extends Fake implements TerminalDiskCache {
  @override
  Future<int> saveMetadata(DiskCacheMetadata metadata) async => metadata.lastSeq;

  @override
  Future<RestoreResult?> restore(
    String baseUrl,
    String sessionId,
    String expectedInstanceId,
    String expectedCreatedAt,
  ) async => null;
}

// Stateful app wrapper that changes constraints without tearing down ProviderScope
class TestAppWrapper extends StatefulWidget {
  const TestAppWrapper({super.key});

  @override
  TestAppWrapperState createState() => TestAppWrapperState();
}

class TestAppWrapperState extends State<TestAppWrapper> {
  double bottomInset = 0.0;
  double screenHeight = 800.0;
  double screenWidth = 400.0;

  void update({
    double? bottomInset,
    double? screenHeight,
    double? screenWidth,
  }) {
    setState(() {
      if (bottomInset != null) this.bottomInset = bottomInset;
      if (screenHeight != null) this.screenHeight = screenHeight;
      if (screenWidth != null) this.screenWidth = screenWidth;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: MediaQuery(
        data: MediaQueryData(
          size: Size(screenWidth, screenHeight),
          viewInsets: EdgeInsets.only(bottom: bottomInset),
          devicePixelRatio: 1.0,
        ),
        // Removed the outer Scaffold that was consuming the viewInsets and compressing heights
        child: const TerminalScreen(
          serverId: 'test-server',
          baseUrl: 'http://test-server',
          cookie: 'test-cookie',
          sessionId: 'test-session',
          requestTitle: 'Test Title',
          requestSubtitle: 'Test Subtitle',
        ),
      ),
    );
  }
}

void main() {
  SharedPreferences.setMockInitialValues({});

  group('TerminalScreen Keyboard Avoidance and Size Lock Tests', () {
    late SharedPreferences prefs;
    late FakeTerminalDiskCache fakeDiskCache;

    setUp(() async {
      prefs = await SharedPreferences.getInstance();
      fakeDiskCache = FakeTerminalDiskCache();
    });

    testWidgets('Verify size constraints are locked and latest content shifts correctly', (WidgetTester tester) async {
      // Create global ProviderContainer once to prevent elements from being recreated during pump
      final container = ProviderContainer(
        overrides: [
          sharedPreferencesProvider.overrideWithValue(prefs),
          diskCacheProvider.overrideWithValue(fakeDiskCache),
        ],
      );

      // 1. Initial Render: Height = 800, No keyboard (bottomInset = 0)
      await tester.pumpWidget(
        UncontrolledProviderScope(
          container: container,
          child: const TestAppWrapper(),
        ),
      );
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 100));

      final terminalViewFinder = find.byType(TerminalView);
      expect(terminalViewFinder, findsOneWidget);

      final RenderBox initialBox = tester.renderObject(terminalViewFinder);
      final double initialHeight = initialBox.size.height;
      final double initialWidth = initialBox.size.width;

      final dynamic state = tester.state(find.byType(TerminalScreen));
      final terminal = state.terminalForTest;
      expect(terminal, isNotNull);

      // Verify layout rows/columns setup initially
      final int initialRows = terminal!.viewHeight;
      final int initialCols = terminal.viewWidth;

      // 2. Simulate Keyboard Pop Up: height remains 800, bottomInset = 300, preserving existing State
      final TestAppWrapperState wrapperState = tester.state(find.byType(TestAppWrapper));

      wrapperState.update(bottomInset: 300.0);
      await tester.pump();

      // Check sizes: Must remain completely locked
      final RenderBox keyboardBox = tester.renderObject(terminalViewFinder);
      expect(keyboardBox.size.height, equals(initialHeight), reason: 'Height of TerminalView must be locked');
      expect(keyboardBox.size.width, equals(initialWidth), reason: 'Width of TerminalView must be locked');
      expect(terminal.viewHeight, equals(initialRows), reason: 'Terminal rows count must be locked');
      expect(terminal.viewWidth, equals(initialCols), reason: 'Terminal columns count must be locked');

      // 3. Test scenario A: Text is sparse (few lines at the top)
      terminal.write('Line 1\r\nLine 2\r\n');
      state.refreshForTest();
      await tester.pump();

      final transformFinder = find.ancestor(of: terminalViewFinder, matching: find.byType(Transform));
      expect(transformFinder, findsOneWidget);
      final Transform t1 = tester.widget(transformFinder.first);
      expect(t1.transform.getTranslation().y, equals(0.0), reason: 'Translation shift should be 0 when cursor is at the top');

      // 4. Test scenario B: Text is full (content filled to bottom, keyboard blocks cursor)
      for (int i = 0; i < 40; i++) {
        terminal.write('Log Line $i\r\n');
      }
      state.refreshForTest();
      await tester.pump();

      // Viewport must shift upwards
      final Transform t2 = tester.widget(transformFinder.first);
      final double shiftY = t2.transform.getTranslation().y;
      expect(shiftY, lessThan(0.0), reason: 'Viewport translation must shift upwards (negative Y offset) when cursor is obscured');

      // Verify final Y alignment gap is exactly 0
      final double quickBarTopY = tester.getTopLeft(find.byKey(const ValueKey('quick_bar'))).dy;
      final double terminalViewTopY = tester.getTopLeft(find.byType(TerminalView)).dy;
      
      final int lastRow = state.lastContentRowForTest;
      final int cursorRow = terminal.buffer.cursorY.clamp(0, terminal.viewHeight - 1);
      final int protectedRow = (cursorRow > lastRow ? cursorRow : lastRow).clamp(0, terminal.viewHeight - 1).toInt();
      final double lineHeight = state.lineHeightForTest;
      
      final double protectedBottomY = terminalViewTopY + (protectedRow + 1) * lineHeight;
      final double gap = quickBarTopY - protectedBottomY;
      // ignore: avoid_print
      print('DEBUG: QuickBar Top Y: $quickBarTopY, Protected Row Bottom Y: $protectedBottomY, Gap: $gap');
      expect(gap, equals(0.0), reason: 'Gap between last content row bottom and quickbar top must be exactly 0.0');

      // 5. Test height increase: keyboard retracted (bottomInset = 0)
      wrapperState.update(bottomInset: 0.0);
      await tester.pump();

      // Offset must go back to 0
      final Transform t3 = tester.widget(transformFinder.first);
      expect(t3.transform.getTranslation().y, equals(0.0), reason: 'Translation must return to 0 when keyboard is hidden');

      // Cleanup: Render dummy widget to dispose state cleanly
      await tester.pumpWidget(const SizedBox.shrink());
      await tester.pump();

      // Wait for the 8-second WebSocket connect timeout timer to expire and clean up
      await tester.pump(const Duration(seconds: 10));
    });
  });
}
