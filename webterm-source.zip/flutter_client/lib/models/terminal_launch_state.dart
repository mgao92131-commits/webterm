import 'cached_terminal.dart';

class TerminalLaunchState {
  final String headerTitle;
  final String headerSubtitle;
  final String createdAt;
  final String instanceId;
  final int lastSeq;
  final int columns;
  final int rows;

  const TerminalLaunchState({
    required this.headerTitle,
    required this.headerSubtitle,
    required this.createdAt,
    required this.instanceId,
    required this.lastSeq,
    required this.columns,
    required this.rows,
  });

  static TerminalLaunchState resolve({
    CachedTerminal? memory,
    CachedTerminal? disk,
    required String requestTitle,
    required String requestSubtitle,
    String? requestCreatedAt,
    String? requestInstanceId,
    int? requestLastSeq,
    int? requestColumns,
    int? requestRows,
  }) {
    final term = memory ?? disk;

    return TerminalLaunchState(
      headerTitle: term != null && term.termTitle.isNotEmpty
          ? term.termTitle
          : requestTitle,
      headerSubtitle: term != null && term.sessionName.isNotEmpty
          ? term.sessionName
          : requestSubtitle,
      createdAt: term?.createdAt ?? requestCreatedAt ?? '',
      instanceId: term?.instanceId ?? requestInstanceId ?? '',
      lastSeq: term?.lastSeq ?? requestLastSeq ?? 0,
      columns: (term != null && term.columns > 0) ? term.columns : (requestColumns ?? 80),
      rows: (term != null && term.rows > 0) ? term.rows : (requestRows ?? 24),
    );
  }
}
