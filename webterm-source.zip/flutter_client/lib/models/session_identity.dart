import 'package:webterm_mobile/core/network/webterm_urls.dart';

class SessionIdentity {
  SessionIdentity._();

  static String cacheKey(String baseUrl, String sessionId, String instanceId, String createdAt) {
    final identity = value(sessionId, instanceId, createdAt);
    if (identity.isEmpty) return '';
    return '${WebTermUrls.normalizeBaseUrl(baseUrl)}#$identity';
  }

  static String value(String sessionId, String instanceId, String createdAt) {
    final normalizedInstance = normalizePart(instanceId);
    if (normalizedInstance.isNotEmpty) return 'instance:$normalizedInstance';
    
    final normalizedCreated = normalizePart(createdAt);
    if (normalizedCreated.isNotEmpty) return 'created:$sessionId@$normalizedCreated';
    
    return '';
  }

  static String normalizePart(String? value) => (value ?? '').trim();
}
