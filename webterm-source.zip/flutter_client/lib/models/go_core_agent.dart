class GoCoreAgentConfig {
  final String mode;
  final GoCoreDirectConfig direct;
  final GoCoreRelayConfig relay;
  final GoCoreControlConfig control;
  final GoCoreShellConfig shell;

  const GoCoreAgentConfig({
    this.mode = 'direct',
    this.direct = const GoCoreDirectConfig(),
    this.relay = const GoCoreRelayConfig(),
    this.control = const GoCoreControlConfig(),
    this.shell = const GoCoreShellConfig(),
  });

  factory GoCoreAgentConfig.fromJson(Map<String, dynamic> json) {
    return GoCoreAgentConfig(
      mode: json['mode'] as String? ?? 'direct',
      direct: GoCoreDirectConfig.fromJson(_map(json['direct'])),
      relay: GoCoreRelayConfig.fromJson(_map(json['relay'])),
      control: GoCoreControlConfig.fromJson(_map(json['control'])),
      shell: GoCoreShellConfig.fromJson(_map(json['shell'])),
    );
  }

  Map<String, dynamic> toJson() => {
    'mode': mode,
    'direct': direct.toJson(),
    'relay': relay.toJson(),
    'control': control.toJson(),
    'shell': shell.toJson(),
  };

  GoCoreAgentConfig copyWith({
    String? mode,
    GoCoreDirectConfig? direct,
    GoCoreRelayConfig? relay,
    GoCoreControlConfig? control,
    GoCoreShellConfig? shell,
  }) {
    return GoCoreAgentConfig(
      mode: mode ?? this.mode,
      direct: direct ?? this.direct,
      relay: relay ?? this.relay,
      control: control ?? this.control,
      shell: shell ?? this.shell,
    );
  }
}

class GoCoreDirectConfig {
  final String addr;
  final String user;
  final String password;
  final String webRoot;

  const GoCoreDirectConfig({
    this.addr = '127.0.0.1:8080',
    this.user = 'admin',
    this.password = '',
    this.webRoot = '',
  });

  factory GoCoreDirectConfig.fromJson(Map<String, dynamic> json) {
    return GoCoreDirectConfig(
      addr: json['addr'] as String? ?? '127.0.0.1:8080',
      user: json['user'] as String? ?? 'admin',
      password: json['password'] as String? ?? '',
      webRoot: json['webRoot'] as String? ?? '',
    );
  }

  Map<String, dynamic> toJson() => {
    'addr': addr,
    'user': user,
    'password': password,
    'webRoot': webRoot,
  };
}

class GoCoreRelayConfig {
  final String url;
  final String secret;
  final String deviceName;

  const GoCoreRelayConfig({
    this.url = '',
    this.secret = '',
    this.deviceName = '',
  });

  factory GoCoreRelayConfig.fromJson(Map<String, dynamic> json) {
    return GoCoreRelayConfig(
      url: json['url'] as String? ?? '',
      secret: json['secret'] as String? ?? '',
      deviceName: json['deviceName'] as String? ?? '',
    );
  }

  Map<String, dynamic> toJson() => {
    'url': url,
    'secret': secret,
    'deviceName': deviceName,
  };
}

class GoCoreControlConfig {
  final String addr;

  const GoCoreControlConfig({this.addr = '127.0.0.1:18081'});

  factory GoCoreControlConfig.fromJson(Map<String, dynamic> json) {
    return GoCoreControlConfig(
      addr: json['addr'] as String? ?? '127.0.0.1:18081',
    );
  }

  Map<String, dynamic> toJson() => {'addr': addr};
}

class GoCoreShellConfig {
  final String command;
  final String cwd;

  const GoCoreShellConfig({this.command = '', this.cwd = ''});

  factory GoCoreShellConfig.fromJson(Map<String, dynamic> json) {
    return GoCoreShellConfig(
      command: json['command'] as String? ?? '',
      cwd: json['cwd'] as String? ?? '',
    );
  }

  Map<String, dynamic> toJson() => {'command': command, 'cwd': cwd};
}

class GoCoreAgentStatus {
  final bool running;
  final String mode;
  final String configMode;
  final bool restartRequired;
  final String version;
  final bool directListening;
  final String directAddr;
  final bool relayConfigured;
  final bool relayConnected;
  final String relayUrl;
  final String relayDeviceId;
  final String relayLastError;
  final int sessionCount;

  const GoCoreAgentStatus({
    this.running = false,
    this.mode = '',
    this.configMode = '',
    this.restartRequired = false,
    this.version = '',
    this.directListening = false,
    this.directAddr = '',
    this.relayConfigured = false,
    this.relayConnected = false,
    this.relayUrl = '',
    this.relayDeviceId = '',
    this.relayLastError = '',
    this.sessionCount = 0,
  });

  factory GoCoreAgentStatus.fromJson(Map<String, dynamic> json) {
    final direct = _map(json['direct']);
    final relay = _map(json['relay']);
    final sessions = _map(json['sessions']);
    return GoCoreAgentStatus(
      running: json['running'] as bool? ?? false,
      mode: json['mode'] as String? ?? '',
      configMode: json['configMode'] as String? ?? '',
      restartRequired: json['restartRequired'] as bool? ?? false,
      version: json['version'] as String? ?? '',
      directListening: direct['listening'] as bool? ?? false,
      directAddr: direct['addr'] as String? ?? '',
      relayConfigured: relay['configured'] as bool? ?? false,
      relayConnected: relay['connected'] as bool? ?? false,
      relayUrl: relay['url'] as String? ?? '',
      relayDeviceId: relay['deviceId'] as String? ?? '',
      relayLastError: relay['lastError'] as String? ?? '',
      sessionCount: sessions['count'] as int? ?? 0,
    );
  }
}

class GoCoreLogEntry {
  final int seq;
  final String time;
  final String level;
  final String source;
  final String message;

  const GoCoreLogEntry({
    required this.seq,
    required this.time,
    required this.level,
    required this.source,
    required this.message,
  });

  factory GoCoreLogEntry.fromJson(Map<String, dynamic> json) {
    return GoCoreLogEntry(
      seq: json['seq'] as int? ?? 0,
      time: json['time'] as String? ?? '',
      level: json['level'] as String? ?? 'info',
      source: json['source'] as String? ?? 'core',
      message: json['message'] as String? ?? '',
    );
  }
}

class GoCoreConnectionTestResult {
  final bool ok;
  final String mode;
  final bool live;
  final String message;
  final String error;

  const GoCoreConnectionTestResult({
    this.ok = false,
    this.mode = '',
    this.live = false,
    this.message = '',
    this.error = '',
  });

  factory GoCoreConnectionTestResult.fromJson(Map<String, dynamic> json) {
    return GoCoreConnectionTestResult(
      ok: json['ok'] as bool? ?? false,
      mode: json['mode'] as String? ?? '',
      live: json['live'] as bool? ?? false,
      message: json['message'] as String? ?? '',
      error: json['error'] as String? ?? '',
    );
  }
}

Map<String, dynamic> _map(Object? value) {
  if (value is Map<String, dynamic>) {
    return value;
  }
  if (value is Map) {
    return value.map((key, val) => MapEntry(key.toString(), val));
  }
  return <String, dynamic>{};
}
