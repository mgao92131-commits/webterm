/// Mutable cache entry representing a previously-connected terminal session.
///
/// Stored in the disk cache so reconnections can resume at the correct
/// sequence number and restore the terminal viewport dimensions.
class CachedTerminal {
  String baseUrl;
  String sessionId;
  String cookie;
  String instanceId;
  String termTitle;
  String sessionName;
  String createdAt;
  int lastSeq;
  int columns;
  int rows;
  dynamic terminalSession;

  CachedTerminal({
    this.baseUrl = '',
    this.sessionId = '',
    this.cookie = '',
    this.instanceId = '',
    this.termTitle = '',
    this.sessionName = '',
    this.createdAt = '',
    this.lastSeq = 0,
    this.columns = 0,
    this.rows = 0,
    this.terminalSession,
  });

  // ── JSON serialization ──

  factory CachedTerminal.fromJson(Map<String, dynamic> json) {
    return CachedTerminal(
      baseUrl: json['baseUrl'] as String? ?? '',
      sessionId: json['sessionId'] as String? ?? '',
      cookie: json['cookie'] as String? ?? '',
      instanceId: json['instanceId'] as String? ?? '',
      termTitle: json['termTitle'] as String? ?? '',
      sessionName: json['sessionName'] as String? ?? '',
      createdAt: json['createdAt'] as String? ?? '',
      lastSeq: json['lastSeq'] as int? ?? 0,
      columns: json['columns'] as int? ?? 0,
      rows: json['rows'] as int? ?? 0,
    );
  }

  Map<String, dynamic> toJson() => {
        'baseUrl': baseUrl,
        'sessionId': sessionId,
        'cookie': cookie,
        'instanceId': instanceId,
        'termTitle': termTitle,
        'sessionName': sessionName,
        'createdAt': createdAt,
        'lastSeq': lastSeq,
        'columns': columns,
        'rows': rows,
      };

  @override
  String toString() =>
      'CachedTerminal(baseUrl: $baseUrl, sessionId: $sessionId, '
      'instanceId: $instanceId, lastSeq: $lastSeq)';
}
