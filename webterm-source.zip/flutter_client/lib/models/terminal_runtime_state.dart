/// Mutable state container for a live terminal session.
///
/// Holds all runtime fields that may change as the session progresses —
/// sequence numbers, viewport dimensions, and display titles.
class TerminalRuntimeState {
  String baseUrl;
  String cookie;
  String sessionId;
  String instanceId;
  String createdAt;
  int lastSeq;
  int columns;
  int rows;
  String headerTitle;
  String headerSubtitle;
  String termTitle;
  String sessionName;

  TerminalRuntimeState({
    this.baseUrl = '',
    this.cookie = '',
    this.sessionId = '',
    this.instanceId = '',
    this.createdAt = '',
    this.lastSeq = 0,
    this.columns = 0,
    this.rows = 0,
    this.headerTitle = '',
    this.headerSubtitle = '',
    this.termTitle = '',
    this.sessionName = '',
  });

  /// Resets all fields to their default values.
  void reset() {
    baseUrl = '';
    cookie = '';
    sessionId = '';
    instanceId = '';
    createdAt = '';
    lastSeq = 0;
    columns = 0;
    rows = 0;
    headerTitle = '';
    headerSubtitle = '';
    termTitle = '';
    sessionName = '';
  }

  @override
  String toString() =>
      'TerminalRuntimeState(baseUrl: $baseUrl, sessionId: $sessionId, '
      'instanceId: $instanceId, lastSeq: $lastSeq, '
      'cols: $columns, rows: $rows)';
}
