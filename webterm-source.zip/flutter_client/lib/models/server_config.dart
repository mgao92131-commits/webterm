/// Immutable configuration for a single WebTerm server connection.
class ServerConfig {
  final String id;
  final String name;
  final String url;
  final String cookie;
  final String username;
  final String password;
  final bool relayMaster;
  final bool relayDevice;
  final String deviceId;

  const ServerConfig({
    required this.id,
    this.name = '',
    this.url = '',
    this.cookie = '',
    this.username = '',
    this.password = '',
    this.relayMaster = false,
    this.relayDevice = false,
    this.deviceId = '',
  });

  // ── JSON serialization ──

  factory ServerConfig.fromJson(Map<String, dynamic> json) {
    return ServerConfig(
      id: json['id'] as String? ?? '',
      name: json['name'] as String? ?? '',
      url: json['url'] as String? ?? '',
      cookie: json['cookie'] as String? ?? '',
      username: json['username'] as String? ?? '',
      password: json['password'] as String? ?? '',
      relayMaster: json['relayMaster'] as bool? ?? false,
      relayDevice: json['relayDevice'] as bool? ?? false,
      deviceId: json['deviceId'] as String? ?? '',
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'url': url,
        'cookie': cookie,
        'username': username,
        'password': password,
        'relayMaster': relayMaster,
        'relayDevice': relayDevice,
        'deviceId': deviceId,
      };

  // ── Copy-with ──

  ServerConfig copyWith({
    String? id,
    String? name,
    String? url,
    String? cookie,
    String? username,
    String? password,
    bool? relayMaster,
    bool? relayDevice,
    String? deviceId,
  }) {
    return ServerConfig(
      id: id ?? this.id,
      name: name ?? this.name,
      url: url ?? this.url,
      cookie: cookie ?? this.cookie,
      username: username ?? this.username,
      password: password ?? this.password,
      relayMaster: relayMaster ?? this.relayMaster,
      relayDevice: relayDevice ?? this.relayDevice,
      deviceId: deviceId ?? this.deviceId,
    );
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is ServerConfig &&
          runtimeType == other.runtimeType &&
          id == other.id;

  @override
  int get hashCode => id.hashCode;

  @override
  String toString() => 'ServerConfig(id: $id, name: $name, url: $url)';
}
