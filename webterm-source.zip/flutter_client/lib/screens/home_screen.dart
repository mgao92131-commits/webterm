import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:webterm_mobile/core/theme/app_colors.dart';
import 'package:webterm_mobile/core/theme/app_theme.dart';
import 'package:webterm_mobile/core/theme/app_typography.dart';
import 'package:webterm_mobile/core/theme/app_motion.dart';
import 'package:webterm_mobile/core/providers/app_providers.dart';
import 'package:webterm_mobile/models/server_config.dart';
import 'package:webterm_mobile/services/relay_coordinator.dart';
import 'package:webterm_mobile/core/crash_reporter.dart';

class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});

  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _initRelay();
    });
  }

  void _initRelay() {
    final servers = ref.read(serverListProvider);
    final relay = ref.read(relayCoordinatorProvider);
    relay.loadMasterFromServers(servers);
    relay.start();
  }

  @override
  Widget build(BuildContext context) {
    ref.listen<List<ServerConfig>>(serverListProvider, (previous, next) {
      final relay = ref.read(relayCoordinatorProvider);
      relay.loadMasterFromServers(next);
      relay.start();
    });

    final servers = ref.watch(serverListProvider);
    final relayDevices = ref.watch(relayDevicesProvider);
    final relayState = ref.watch(relayStateProvider);
    final relayMaster = ref.watch(relayCoordinatorProvider).masterConfig;

    final normalServers = servers.where((s) => !s.relayMaster).toList();
    final allDevices = [...normalServers, ...relayDevices];

    return Scaffold(
      backgroundColor: AppColors.bgPrimary,
      body: SafeArea(
        child: CustomScrollView(
          physics: const BouncingScrollPhysics(),
          slivers: [
            // ── App Header ──
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: AppTheme.space4,
                  vertical: AppTheme.space3,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('WebTerm', style: AppTypography.brand()),
                        const SizedBox(height: 2),
                        Text(
                          '${allDevices.length} 台设备在线',
                          style: AppTypography.caption(),
                        ),
                      ],
                    ),
                    IconButton(
                      icon: const Icon(
                        Icons.settings,
                        color: AppColors.textSecondary,
                      ),
                      onPressed: () => _showSettingsDialog(context),
                    ),
                  ],
                ),
              ),
            ),

            // ── Relay Master Banner ──
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: AppTheme.space4,
                ),
                child: _buildRelayBanner(context, relayState, relayMaster),
              ),
            ),

            const SliverToBoxAdapter(child: SizedBox(height: AppTheme.space4)),

            // ── Section Title ──
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: AppTheme.space4,
                ),
                child: Text(
                  'DEVICES',
                  style: AppTypography.overline(),
                ),
              ),
            ),

            const SliverToBoxAdapter(child: SizedBox(height: AppTheme.space2)),

            // ── Device Cards ──
            if (allDevices.isEmpty)
              SliverFillRemaining(
                hasScrollBody: false,
                child: _buildEmptyState(),
              )
            else
              SliverPadding(
                padding: const EdgeInsets.symmetric(
                  horizontal: AppTheme.space4,
                ),
                sliver: SliverList(
                  delegate: SliverChildBuilderDelegate((context, index) {
                    final server = allDevices[index];
                    return Padding(
                      padding: const EdgeInsets.only(bottom: AppTheme.space3),
                      child: StaggerItem(
                        index: index,
                        child: _buildDeviceCard(context, server),
                      ),
                    );
                  }, childCount: allDevices.length),
                ),
              ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: AppColors.accent,
        foregroundColor: AppColors.bgPrimary,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppTheme.radiusLg),
        ),
        onPressed: () => _showServerDialog(context, null),
        child: const Icon(Icons.add),
      ),
    );
  }

  // ── Empty State ──

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            r'$ no_devices_found',
            style: AppTypography.mono().copyWith(
              color: AppColors.textDisabled,
            ),
          ),
          const SizedBox(height: AppTheme.space2),
          Text(
            '点击右下角 + 添加服务器或配置中转',
            style: AppTypography.caption(),
          ),
        ],
      ),
    );
  }

  // ── Relay Banner ──

  Widget _buildRelayBanner(
    BuildContext context,
    RelayState state,
    ServerConfig? master,
  ) {
    Color borderColor;
    String titleText;
    String statusSubtitle;
    Color dotColor;
    bool pulsing;

    switch (state) {
      case RelayState.notConfigured:
        borderColor = AppColors.borderPrimary;
        titleText = '中转服务未连接';
        statusSubtitle = '点击配置您的中转主控端服务器';
        dotColor = AppColors.textDisabled;
        pulsing = false;
        break;
      case RelayState.connecting:
        borderColor = AppColors.warning.withAlpha(0x40);
        titleText = '正在连接中转服务...';
        statusSubtitle = master != null ? master.url : '';
        dotColor = AppColors.warning;
        pulsing = true;
        break;
      case RelayState.authFailed:
        borderColor = AppColors.danger.withAlpha(0x40);
        titleText = '中转服务登录失败';
        statusSubtitle = '账号密码或 Token 验证错误';
        dotColor = AppColors.danger;
        pulsing = false;
        break;
      case RelayState.connectFailed:
        borderColor = AppColors.danger.withAlpha(0x40);
        titleText = '连接中转服务失败，正在重试...';
        statusSubtitle = master != null ? master.url : '';
        dotColor = AppColors.danger;
        pulsing = true;
        break;
      case RelayState.connectedFetchingDevices:
        borderColor = AppColors.success.withAlpha(0x40);
        titleText = '已连接中转，正在加载设备...';
        statusSubtitle = master != null ? master.url : '';
        dotColor = AppColors.warning;
        pulsing = true;
        break;
      case RelayState.connectedNoDevices:
        borderColor = AppColors.success.withAlpha(0x40);
        titleText = '中转已连接 (无在线设备)';
        statusSubtitle = master != null ? master.url : '';
        dotColor = AppColors.success;
        pulsing = false;
        break;
      case RelayState.connectedWithDevices:
        borderColor = AppColors.success;
        titleText = '中转服务已连接';
        statusSubtitle = '设备在线中';
        dotColor = AppColors.success;
        pulsing = false;
        break;
      case RelayState.connectedPolling:
        borderColor = AppColors.success.withAlpha(0x60);
        titleText = '中转服务已连接 (轮询模式)';
        statusSubtitle = master != null ? master.url : '';
        dotColor = AppColors.success;
        pulsing = false;
        break;
    }

    return Pressable(
      onTap: () => _showRelayDialog(context, master),
      child: Container(
        padding: const EdgeInsets.all(AppTheme.cardPaddingV),
        decoration: BoxDecoration(
          color: AppColors.bgSecondary,
          borderRadius: BorderRadius.circular(AppTheme.radiusLg),
          border: Border.all(color: borderColor, width: 1.0),
        ),
        child: Row(
          children: [
            StatusDot(color: dotColor, pulsing: pulsing),
            const SizedBox(width: AppTheme.space3),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(titleText, style: AppTypography.heading()),
                  const SizedBox(height: 2),
                  Text(
                    statusSubtitle,
                    style: AppTypography.caption(),
                  ),
                ],
              ),
            ),
            const Icon(Icons.chevron_right, color: AppColors.textTertiary),
          ],
        ),
      ),
    );
  }

  // ── Device Card ──

  Widget _buildDeviceCard(BuildContext context, ServerConfig server) {
    return Pressable(
      onTap: () => context.push('/sessions?serverId=${server.id}'),
      child: Container(
        padding: const EdgeInsets.symmetric(
          horizontal: AppTheme.cardPaddingH,
          vertical: AppTheme.cardPaddingV,
        ),
        decoration: BoxDecoration(
          color: AppColors.bgSecondary,
          borderRadius: BorderRadius.circular(AppTheme.radiusMd),
          border: Border.all(color: AppColors.borderPrimary),
        ),
        child: Row(
          children: [
            // 设备徽章：文字标签（对齐 Android 端 "PC" / "R"）
            _buildDeviceBadge(server),
            const SizedBox(width: AppTheme.space3),

            // 设备名称和地址
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Flexible(
                        child: Text(
                          server.name.isNotEmpty ? server.name : '未命名电脑',
                          style: AppTypography.heading(),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      if (server.relayDevice) ...[
                        const SizedBox(width: AppTheme.space1),
                        _buildTailscaleChip(),
                      ],
                    ],
                  ),
                  const SizedBox(height: 2),
                  Text(
                    server.relayDevice ? '中转设备' : server.url,
                    style: AppTypography.caption(),
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),

            // 操作按钮
            if (!server.relayDevice)
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(
                    icon: const Icon(
                      Icons.edit,
                      color: AppColors.textTertiary,
                      size: 20,
                    ),
                    onPressed: () => _showServerDialog(context, server),
                  ),
                  IconButton(
                    icon: const Icon(
                      Icons.delete_outline,
                      color: AppColors.danger,
                      size: 20,
                    ),
                    onPressed: () => _confirmDeleteServer(context, server),
                  ),
                ],
              )
            else
              const Icon(Icons.chevron_right, color: AppColors.textTertiary),
          ],
        ),
      ),
    );
  }

  /// 设备徽章：文字标签，与 Android 端 HomeScreenBuilder.deviceCard() 对齐
  Widget _buildDeviceBadge(ServerConfig server) {
    final label = server.relayDevice ? 'R' : 'PC';
    final textColor = server.relayDevice ? AppColors.info : AppColors.accent;
    final bgColor = server.relayDevice
        ? AppColors.info.withAlpha(0x4D)
        : AppColors.accent.withAlpha(0x4D);

    return Container(
      width: AppTheme.deviceBadgeSize,
      height: AppTheme.deviceBadgeSize,
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(AppTheme.radiusSm),
      ),
      alignment: Alignment.center,
      child: Text(
        label,
        style: AppTypography.label().copyWith(
          color: textColor,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }

  /// Tailscale 芯片标签
  Widget _buildTailscaleChip() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
      decoration: BoxDecoration(
        color: AppColors.accent.withAlpha(0x1A),
        borderRadius: BorderRadius.circular(AppTheme.radiusSm),
      ),
      child: Text(
        'Tailscale',
        style: AppTypography.caption().copyWith(
          color: AppColors.accentText,
        ),
      ),
    );
  }

  // ── Dialogs (unchanged logic, style-only updates) ──

  void _showServerDialog(BuildContext context, ServerConfig? server) {
    final nameController = TextEditingController(text: server?.name ?? '');
    final urlController = TextEditingController(text: server?.url ?? '');
    final userController = TextEditingController(text: server?.username ?? '');
    final pwdController = TextEditingController(text: server?.password ?? '');

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          backgroundColor: AppColors.bgSecondary,
          title: Text(
            server == null ? '添加在线服务器' : '编辑服务器',
            style: AppTypography.dialogTitle(),
          ),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                _buildDialogField(nameController, '别名 (如：主电脑)'),
                _buildDialogField(urlController, '主机地址 (http://ip:port)'),
                _buildDialogField(userController, '用户名'),
                _buildDialogField(pwdController, '密码', obscure: true),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text(
                '取消',
                style: TextStyle(color: AppColors.textSecondary),
              ),
            ),
            TextButton(
              onPressed: () {
                if (urlController.text.trim().isEmpty) return;
                ref
                    .read(serverListProvider.notifier)
                    .addOrUpdate(
                      server,
                      nameController.text.trim(),
                      urlController.text.trim(),
                      server?.cookie ?? '',
                      userController.text.trim(),
                      pwdController.text.trim(),
                    );
                Navigator.pop(context);
              },
              child: const Text(
                '保存',
                style: TextStyle(color: AppColors.accent),
              ),
            ),
          ],
        );
      },
    );
  }

  void _confirmDeleteServer(BuildContext context, ServerConfig server) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          backgroundColor: AppColors.bgSecondary,
          title: Text('删除确认', style: AppTypography.dialogTitle()),
          content: Text(
            '您确定要删除服务器 "${server.name}" 吗？',
            style: AppTypography.body(),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text(
                '取消',
                style: TextStyle(color: AppColors.textSecondary),
              ),
            ),
            TextButton(
              onPressed: () {
                ref.read(serverListProvider.notifier).remove(server);
                Navigator.pop(context);
              },
              child: const Text(
                '删除',
                style: TextStyle(color: AppColors.danger),
              ),
            ),
          ],
        );
      },
    );
  }

  void _showRelayDialog(BuildContext context, ServerConfig? master) {
    final urlController = TextEditingController(
      text: master?.url ?? 'http://100.121.115.14:8081',
    );
    final userController = TextEditingController(
      text: master?.username ?? 'gao',
    );
    final pwdController = TextEditingController(text: master?.password ?? '');
    final otpController = TextEditingController();

    var otpVisible = false;
    var targetDeviceId = '';
    var tempCookie = '';

    showDialog(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            return AlertDialog(
              backgroundColor: AppColors.bgSecondary,
              title: Text('中转服务设置', style: AppTypography.dialogTitle()),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    _buildDialogField(
                      urlController,
                      '中转主控端地址',
                      enabled: !otpVisible,
                    ),
                    _buildDialogField(
                      userController,
                      '账户电子邮箱',
                      enabled: !otpVisible,
                    ),
                    _buildDialogField(
                      pwdController,
                      '密码',
                      obscure: true,
                      enabled: !otpVisible,
                    ),
                    if (otpVisible) ...[
                      const SizedBox(height: AppTheme.space3),
                      _buildDialogField(
                        otpController,
                        '验证码 (OTP)',
                        keyboardType: TextInputType.number,
                        accent: true,
                      ),
                    ],
                  ],
                ),
              ),
              actions: [
                if (master != null)
                  TextButton(
                    onPressed: () {
                      ref.read(relayCoordinatorProvider).onDisconnectRelay();
                      Navigator.pop(context);
                    },
                    child: const Text(
                      '断开连接',
                      style: TextStyle(color: AppColors.danger),
                    ),
                  ),
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text(
                    '取消',
                    style: TextStyle(color: AppColors.textSecondary),
                  ),
                ),
                TextButton(
                  onPressed: () async {
                    if (otpVisible) {
                      final code = otpController.text.trim();
                      if (code.isEmpty) return;
                      ref
                          .read(relayCoordinatorProvider)
                          .verifyOtp(
                            urlController.text.trim(),
                            userController.text.trim(),
                            code,
                            targetDeviceId,
                            tempCookie,
                            RelayLoginCallback(
                              onSuccess: (url, cookie) {
                                ref
                                    .read(relayCoordinatorProvider)
                                    .onRelayAuthenticated(
                                      url,
                                      cookie,
                                      userController.text.trim(),
                                      pwdController.text.trim(),
                                    );
                                Navigator.pop(context);
                              },
                              onErrorCallback: (msg) {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(content: Text('验证失败: $msg')),
                                );
                              },
                            ),
                          );
                    } else {
                      final url = urlController.text.trim();
                      final user = userController.text.trim();
                      final pwd = pwdController.text.trim();
                      if (url.isEmpty || user.isEmpty || pwd.isEmpty) return;
                      ref
                          .read(relayCoordinatorProvider)
                          .loginRelay(
                            url,
                            user,
                            pwd,
                            RelayLoginCallback(
                              onSuccess: (u, cookie) {
                                ref
                                    .read(relayCoordinatorProvider)
                                    .onRelayAuthenticated(u, cookie, user, pwd);
                                Navigator.pop(context);
                              },
                              onOtpRequiredCallback: (deviceId, cookie) {
                                setDialogState(() {
                                  otpVisible = true;
                                  targetDeviceId = deviceId;
                                  tempCookie = cookie;
                                });
                              },
                              onErrorCallback: (msg) {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(content: Text('登录失败: $msg')),
                                );
                              },
                            ),
                          );
                    }
                  },
                  child: Text(
                    otpVisible ? '验证' : '连接',
                    style: const TextStyle(color: AppColors.accent),
                  ),
                ),
              ],
            );
          },
        );
      },
    );
  }

  void _showSettingsDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) {
        final store = ref.read(serverConfigStoreProvider);
        var size = store.getFontSize();
        var type = store.getFontType();
        var weight = store.getFontWeight();
        var boldWeight = store.getBoldFontWeight();

        return StatefulBuilder(
          builder: (context, setDialogState) {
            return AlertDialog(
              backgroundColor: AppColors.bgSecondary,
              title: Text('设置', style: AppTypography.dialogTitle()),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('终端字体大小: $size', style: AppTypography.body()),
                  Slider(
                    value: size.toDouble(),
                    min: 8,
                    max: 20,
                    activeColor: AppColors.accent,
                    inactiveColor: AppColors.borderPrimary,
                    divisions: 12,
                    onChanged: (val) {
                      setDialogState(() {
                        size = val.toInt();
                      });
                      store.saveFontSize(size);
                    },
                  ),
                  const SizedBox(height: AppTheme.space3),
                  Text('终端字体类型:', style: AppTypography.body()),
                  DropdownButton<String>(
                    value: type,
                    dropdownColor: AppColors.bgSecondary,
                    style: AppTypography.body().copyWith(
                      color: AppColors.textPrimary,
                    ),
                    underline: Container(
                      height: 1,
                      color: AppColors.borderPrimary,
                    ),
                    items: const [
                      DropdownMenuItem(
                        value: 'monospace',
                        child: Text('系统等宽字体 (Monospace)'),
                      ),
                      DropdownMenuItem(
                        value: 'GeistMono',
                        child: Text('Geist Mono'),
                      ),
                    ],
                    onChanged: (val) {
                      if (val != null) {
                        setDialogState(() {
                          type = val;
                        });
                        store.saveFontType(val);
                      }
                    },
                  ),
                  const SizedBox(height: AppTheme.space3),
                  Text('终端默认字重:', style: AppTypography.body()),
                  DropdownButton<int>(
                    value: weight,
                    dropdownColor: AppColors.bgSecondary,
                    style: AppTypography.body().copyWith(
                      color: AppColors.textPrimary,
                    ),
                    underline: Container(
                      height: 1,
                      color: AppColors.borderPrimary,
                    ),
                    items: const [
                      DropdownMenuItem(value: 100, child: Text('W100 (Thin)')),
                      DropdownMenuItem(
                        value: 200,
                        child: Text('W200 (ExtraLight)'),
                      ),
                      DropdownMenuItem(value: 300, child: Text('W300 (Light)')),
                      DropdownMenuItem(
                        value: 400,
                        child: Text('W400 (Normal)'),
                      ),
                      DropdownMenuItem(
                        value: 500,
                        child: Text('W500 (Medium)'),
                      ),
                      DropdownMenuItem(
                        value: 600,
                        child: Text('W600 (SemiBold)'),
                      ),
                      DropdownMenuItem(value: 700, child: Text('W700 (Bold)')),
                      DropdownMenuItem(
                        value: 800,
                        child: Text('W800 (ExtraBold)'),
                      ),
                      DropdownMenuItem(value: 900, child: Text('W900 (Black)')),
                    ],
                    onChanged: (val) {
                      if (val != null) {
                        setDialogState(() {
                          weight = val;
                        });
                        store.saveFontWeight(val);
                      }
                    },
                  ),
                  const SizedBox(height: AppTheme.space3),
                  Text('终端加粗字重:', style: AppTypography.body()),
                  DropdownButton<int>(
                    value: boldWeight,
                    dropdownColor: AppColors.bgSecondary,
                    style: AppTypography.body().copyWith(
                      color: AppColors.textPrimary,
                    ),
                    underline: Container(
                      height: 1,
                      color: AppColors.borderPrimary,
                    ),
                    items: const [
                      DropdownMenuItem(value: 100, child: Text('W100 (Thin)')),
                      DropdownMenuItem(
                        value: 200,
                        child: Text('W200 (ExtraLight)'),
                      ),
                      DropdownMenuItem(value: 300, child: Text('W300 (Light)')),
                      DropdownMenuItem(
                        value: 400,
                        child: Text('W400 (Normal)'),
                      ),
                      DropdownMenuItem(
                        value: 500,
                        child: Text('W500 (Medium)'),
                      ),
                      DropdownMenuItem(
                        value: 600,
                        child: Text('W600 (SemiBold)'),
                      ),
                      DropdownMenuItem(value: 700, child: Text('W700 (Bold)')),
                      DropdownMenuItem(
                        value: 800,
                        child: Text('W800 (ExtraBold)'),
                      ),
                      DropdownMenuItem(value: 900, child: Text('W900 (Black)')),
                    ],
                    onChanged: (val) {
                      if (val != null) {
                        setDialogState(() {
                          boldWeight = val;
                        });
                        store.saveBoldFontWeight(val);
                      }
                    },
                  ),
                  const SizedBox(height: AppTheme.space3),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('PC Agent:', style: AppTypography.body()),
                      TextButton.icon(
                        onPressed: () {
                          Navigator.pop(context);
                          context.push('/agent');
                        },
                        icon: const Icon(Icons.memory_rounded, size: 18),
                        label: const Text('打开'),
                        style: TextButton.styleFrom(
                          foregroundColor: AppColors.accent,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: AppTheme.space3),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('查看崩溃日志:', style: AppTypography.body()),
                      TextButton(
                        onPressed: () async {
                          final crash = await CrashReporter.readLatestCrash();
                          if (!context.mounted) return;
                          Navigator.pop(context);
                          _showCrashLogDialog(context, crash);
                        },
                        child: const Text(
                          '查看最新',
                          style: TextStyle(color: AppColors.accent),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text(
                    '确定',
                    style: TextStyle(color: AppColors.accent),
                  ),
                ),
              ],
            );
          },
        );
      },
    );
  }

  void _showCrashLogDialog(BuildContext context, String? crashLog) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          backgroundColor: AppColors.bgSecondary,
          title: Text('最新崩溃日志', style: AppTypography.dialogTitle()),
          content: SizedBox(
            width: double.maxFinite,
            child: crashLog == null
                ? Text('未找到崩溃日志文件。', style: AppTypography.body())
                : SingleChildScrollView(
                    child: SelectableText(
                      crashLog,
                      style: AppTypography.monoTiny(),
                    ),
                  ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text(
                '关闭',
                style: TextStyle(color: AppColors.accent),
              ),
            ),
          ],
        );
      },
    );
  }

  // ── Reusable dialog field (mono font, aligning with Web/Android) ──

  Widget _buildDialogField(
    TextEditingController controller,
    String label, {
    bool obscure = false,
    bool enabled = true,
    bool accent = false,
    TextInputType keyboardType = TextInputType.text,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: AppTheme.space3),
      child: TextField(
        controller: controller,
        obscureText: obscure,
        enabled: enabled,
        keyboardType: keyboardType,
        style: AppTypography.mono().copyWith(color: AppColors.textPrimary),
        decoration: InputDecoration(
          labelText: label,
          labelStyle: TextStyle(
            color: accent ? AppColors.accentText : AppColors.textSecondary,
            fontFamily: 'GeistSans',
          ),
          enabledBorder: UnderlineInputBorder(
            borderSide: BorderSide(
              color: accent ? AppColors.accent : AppColors.borderPrimary,
            ),
          ),
          focusedBorder: UnderlineInputBorder(
            borderSide: BorderSide(
              color: accent ? AppColors.accent : AppColors.accent,
            ),
          ),
        ),
      ),
    );
  }
}

// ── RelayLoginCallback adapter ──

class RelayLoginCallback implements RelayConfigDialogHelperLoginCallback {
  final void Function(String url, String cookie) onSuccess;
  final void Function(String deviceId, String cookie)? onOtpRequiredCallback;
  final void Function(String msg) onErrorCallback;

  RelayLoginCallback({
    required this.onSuccess,
    this.onOtpRequiredCallback,
    required this.onErrorCallback,
  });

  @override
  void onReady(String url, String cookie) => onSuccess(url, cookie);

  @override
  void onOtpRequired(String targetDeviceId, String cookie) {
    if (onOtpRequiredCallback != null) {
      onOtpRequiredCallback!(targetDeviceId, cookie);
    }
  }

  @override
  void onError(String message) => onErrorCallback(message);
}
