import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:webterm_mobile/core/providers/app_providers.dart';
import 'package:webterm_mobile/core/theme/app_colors.dart';
import 'package:webterm_mobile/core/theme/app_theme.dart';
import 'package:webterm_mobile/core/theme/app_typography.dart';
import 'package:webterm_mobile/models/go_core_agent.dart';

class AgentSettingsScreen extends ConsumerStatefulWidget {
  const AgentSettingsScreen({super.key});

  @override
  ConsumerState<AgentSettingsScreen> createState() =>
      _AgentSettingsScreenState();
}

class _AgentSettingsScreenState extends ConsumerState<AgentSettingsScreen> {
  final _controlUrlController = TextEditingController(
    text: 'http://127.0.0.1:18081',
  );
  final _directAddrController = TextEditingController();
  final _directUserController = TextEditingController();
  final _directPasswordController = TextEditingController();
  final _relayUrlController = TextEditingController();
  final _relaySecretController = TextEditingController();
  final _relayDeviceController = TextEditingController();
  final _shellController = TextEditingController();
  final _cwdController = TextEditingController();

  GoCoreAgentStatus? _status;
  GoCoreAgentConfig _config = const GoCoreAgentConfig();
  List<GoCoreLogEntry> _logs = const [];
  String _mode = 'direct';
  String _message = '';
  bool _busy = false;
  bool _liveTest = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _load());
  }

  @override
  void dispose() {
    _controlUrlController.dispose();
    _directAddrController.dispose();
    _directUserController.dispose();
    _directPasswordController.dispose();
    _relayUrlController.dispose();
    _relaySecretController.dispose();
    _relayDeviceController.dispose();
    _shellController.dispose();
    _cwdController.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    await _run('已刷新 Go Core 状态', () async {
      final snapshot = await ref
          .read(goCoreAgentServiceProvider)
          .fetchSnapshot(_controlUrlController.text);
      _applyConfig(snapshot.config);
      setState(() {
        _status = snapshot.status;
        _logs = snapshot.logs;
      });
    });
  }

  Future<void> _save() async {
    await _run('配置已保存并应用', () async {
      await ref
          .read(goCoreAgentServiceProvider)
          .saveConfig(_controlUrlController.text, _readConfig());
      final snapshot = await ref
          .read(goCoreAgentServiceProvider)
          .fetchSnapshot(_controlUrlController.text);
      _applyConfig(snapshot.config);
      setState(() {
        _status = snapshot.status;
        _logs = snapshot.logs;
      });
    });
  }

  Future<void> _testConnection() async {
    await _run('', () async {
      final result = await ref
          .read(goCoreAgentServiceProvider)
          .testConnection(
            _controlUrlController.text,
            _readConfig(),
            live: _liveTest,
          );
      setState(() {
        _message = result.ok ? result.message : result.error;
      });
    });
  }

  Future<void> _setMode(String mode) async {
    setState(() => _mode = mode);
    await _run('模式已切换', () async {
      await ref
          .read(goCoreAgentServiceProvider)
          .setMode(_controlUrlController.text, mode);
      final snapshot = await ref
          .read(goCoreAgentServiceProvider)
          .fetchSnapshot(_controlUrlController.text);
      _applyConfig(snapshot.config);
      setState(() {
        _status = snapshot.status;
        _logs = snapshot.logs;
      });
    });
  }

  Future<void> _restart() async {
    await _run('Go Core 已重启', () async {
      await ref
          .read(goCoreAgentServiceProvider)
          .restart(_controlUrlController.text);
      final snapshot = await ref
          .read(goCoreAgentServiceProvider)
          .fetchSnapshot(_controlUrlController.text);
      setState(() {
        _status = snapshot.status;
        _logs = snapshot.logs;
      });
    });
  }

  Future<void> _stop() async {
    await _run('Go Core runtime 已停止', () async {
      await ref
          .read(goCoreAgentServiceProvider)
          .stop(_controlUrlController.text);
      final snapshot = await ref
          .read(goCoreAgentServiceProvider)
          .fetchSnapshot(_controlUrlController.text);
      setState(() {
        _status = snapshot.status;
        _logs = snapshot.logs;
      });
    });
  }

  Future<void> _run(
    String successMessage,
    Future<void> Function() action,
  ) async {
    if (_busy) return;
    setState(() {
      _busy = true;
      _message = '';
    });
    try {
      await action();
      if (successMessage.isNotEmpty) {
        setState(() => _message = successMessage);
      }
    } catch (error) {
      setState(() => _message = error.toString());
    } finally {
      if (mounted) {
        setState(() => _busy = false);
      }
    }
  }

  void _applyConfig(GoCoreAgentConfig config) {
    _config = config;
    _mode = config.mode;
    _directAddrController.text = config.direct.addr;
    _directUserController.text = config.direct.user;
    _directPasswordController.text = config.direct.password;
    _relayUrlController.text = config.relay.url;
    _relaySecretController.text = config.relay.secret;
    _relayDeviceController.text = config.relay.deviceName;
    _shellController.text = config.shell.command;
    _cwdController.text = config.shell.cwd;
  }

  GoCoreAgentConfig _readConfig() {
    return _config.copyWith(
      mode: _mode,
      direct: GoCoreDirectConfig(
        addr: _directAddrController.text.trim(),
        user: _directUserController.text.trim(),
        password: _directPasswordController.text,
        webRoot: _config.direct.webRoot,
      ),
      relay: GoCoreRelayConfig(
        url: _relayUrlController.text.trim(),
        secret: _relaySecretController.text,
        deviceName: _relayDeviceController.text.trim(),
      ),
      shell: GoCoreShellConfig(
        command: _shellController.text.trim(),
        cwd: _cwdController.text.trim(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final status = _status;
    return Scaffold(
      backgroundColor: AppColors.bgPrimary,
      appBar: AppBar(
        backgroundColor: AppColors.bgPrimary,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        title: Text('PC Agent', style: AppTypography.brand()),
        actions: [
          IconButton(
            tooltip: '刷新',
            onPressed: _busy ? null : _load,
            icon: const Icon(Icons.refresh, color: AppColors.textSecondary),
          ),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(AppTheme.space4),
          children: [
            _buildStatusPanel(status),
            const SizedBox(height: AppTheme.space4),
            _buildControlAddress(),
            const SizedBox(height: AppTheme.space4),
            _buildModeSegment(),
            const SizedBox(height: AppTheme.space4),
            if (_mode == 'direct') _buildDirectForm() else _buildRelayForm(),
            const SizedBox(height: AppTheme.space4),
            _buildShellForm(),
            const SizedBox(height: AppTheme.space4),
            _buildActions(),
            if (_message.isNotEmpty) ...[
              const SizedBox(height: AppTheme.space3),
              Text(
                _message,
                style: AppTypography.mono().copyWith(
                  fontSize: 12,
                  color: _message.startsWith('Exception')
                      ? AppColors.danger
                      : AppColors.accentText,
                ),
              ),
            ],
            const SizedBox(height: AppTheme.space5),
            _buildLogs(),
          ],
        ),
      ),
    );
  }

  Widget _buildStatusPanel(GoCoreAgentStatus? status) {
    final mode = status?.mode ?? '-';
    final configMode = status?.configMode ?? '-';
    final relayText = status == null
        ? '-'
        : status.relayConnected
            ? '已连接 ${status.relayDeviceId}'
            : status.relayLastError.isEmpty
                ? '未连接'
                : status.relayLastError;
    return _section(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _sectionTitle(Icons.memory_rounded, '运行状态'),
          const SizedBox(height: AppTheme.space3),
          _kv('Runtime', mode),
          _kv('Config', configMode),
          _kv(
            'Direct',
            status?.directListening == true
                ? '监听 ${status?.directAddr ?? ''}'
                : '未监听',
          ),
          _kv('Relay', relayText),
          _kv('Sessions', '${status?.sessionCount ?? 0}'),
          if (status?.restartRequired == true)
            _badge('配置等待应用', AppColors.warning),
        ],
      ),
    );
  }

  Widget _buildControlAddress() {
    return _section(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _sectionTitle(Icons.settings_input_component_rounded, '控制端口'),
          const SizedBox(height: AppTheme.space3),
          _field(
            _controlUrlController,
            'Control API',
            hint: 'http://127.0.0.1:18081',
          ),
        ],
      ),
    );
  }

  Widget _buildModeSegment() {
    return Center(
      child: SegmentedButton<String>(
        segments: const [
          ButtonSegment(
            value: 'direct',
            label: Text('直连'),
            icon: Icon(Icons.lan_rounded),
          ),
          ButtonSegment(
            value: 'relay',
            label: Text('中转'),
            icon: Icon(Icons.hub_rounded),
          ),
        ],
        selected: {_mode},
        onSelectionChanged: _busy ? null : (value) => _setMode(value.first),
        style: ButtonStyle(
          foregroundColor: WidgetStateProperty.all(AppColors.textPrimary),
          backgroundColor: WidgetStateProperty.resolveWith((states) {
            return states.contains(WidgetState.selected)
                ? AppColors.accentBgStrong()
                : AppColors.bgSecondary;
          }),
        ),
      ),
    );
  }

  Widget _buildDirectForm() {
    return _section(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _sectionTitle(Icons.lan_rounded, '直连参数'),
          const SizedBox(height: AppTheme.space3),
          _field(_directAddrController, '监听地址', hint: '127.0.0.1:8080'),
          _field(_directUserController, '用户', hint: 'admin'),
          _field(_directPasswordController, '密码', obscure: true),
        ],
      ),
    );
  }

  Widget _buildRelayForm() {
    return _section(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _sectionTitle(Icons.hub_rounded, '中转参数'),
          const SizedBox(height: AppTheme.space3),
          _field(
            _relayUrlController,
            'Relay URL',
            hint: 'https://relay.example.com',
          ),
          _field(_relaySecretController, 'Relay Secret', obscure: true),
          _field(_relayDeviceController, '设备名', hint: 'MacBook'),
          SwitchListTile(
            value: _liveTest,
            onChanged: (value) => setState(() => _liveTest = value),
            activeThumbColor: AppColors.accent,
            contentPadding: EdgeInsets.zero,
            title: Text('实时注册测试', style: AppTypography.body()),
          ),
        ],
      ),
    );
  }

  Widget _buildShellForm() {
    return _section(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _sectionTitle(Icons.terminal_rounded, '终端参数'),
          const SizedBox(height: AppTheme.space3),
          _field(_shellController, 'Shell', hint: '/bin/zsh'),
          _field(_cwdController, '工作目录', hint: '/Users/gao'),
        ],
      ),
    );
  }

  Widget _buildActions() {
    return Wrap(
      spacing: AppTheme.space2,
      runSpacing: AppTheme.space2,
      children: [
        _button(Icons.network_check_rounded, '测试', _testConnection),
        _button(Icons.save_rounded, '保存', _save),
        _button(Icons.restart_alt_rounded, '重启', _restart),
        _button(Icons.stop_circle_outlined, '停止', _stop, danger: true),
      ],
    );
  }

  Widget _buildLogs() {
    return _section(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _sectionTitle(Icons.subject_rounded, '最近日志'),
          const SizedBox(height: AppTheme.space3),
          if (_logs.isEmpty)
            Text('暂无日志', style: AppTypography.body())
          else
            ..._logs.take(20).map((entry) {
              final color = entry.level == 'error'
                  ? AppColors.danger
                  : entry.level == 'warn'
                      ? AppColors.warning
                      : AppColors.textTertiary;
              return Padding(
                padding: const EdgeInsets.only(bottom: AppTheme.space2),
                child: Text(
                  '#${entry.seq} ${entry.source} ${entry.message}',
                  style: AppTypography.monoTiny().copyWith(color: color),
                ),
              );
            }),
        ],
      ),
    );
  }

  Widget _section({required Widget child}) {
    return Container(
      padding: const EdgeInsets.all(AppTheme.space4),
      decoration: BoxDecoration(
        color: AppColors.bgSecondary,
        borderRadius: BorderRadius.circular(AppTheme.radiusMd),
        border: Border.all(color: AppColors.borderPrimary),
      ),
      child: child,
    );
  }

  Widget _sectionTitle(IconData icon, String title) {
    return Row(
      children: [
        Icon(icon, color: AppColors.accent, size: 18),
        const SizedBox(width: AppTheme.space2),
        Text(title, style: AppTypography.heading()),
      ],
    );
  }

  Widget _field(
    TextEditingController controller,
    String label, {
    String hint = '',
    bool obscure = false,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: AppTheme.space3),
      child: TextField(
        controller: controller,
        obscureText: obscure,
        // 输入框使用等宽字体，与 Web 端 font-mono 对齐
        style: AppTypography.mono().copyWith(color: AppColors.textPrimary),
        decoration: InputDecoration(
          labelText: label,
          hintText: hint,
          labelStyle: const TextStyle(
            color: AppColors.textSecondary,
            fontFamily: 'GeistSans',
          ),
          hintStyle: const TextStyle(
            color: AppColors.textDisabled,
            fontFamily: 'GeistSans',
          ),
          enabledBorder: const UnderlineInputBorder(
            borderSide: BorderSide(color: AppColors.borderPrimary),
          ),
          focusedBorder: const UnderlineInputBorder(
            borderSide: BorderSide(color: AppColors.accent),
          ),
        ),
      ),
    );
  }

  Widget _kv(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: AppTheme.space2),
      child: Row(
        children: [
          SizedBox(width: 86, child: Text(label, style: AppTypography.label())),
          Expanded(
            child: Text(
              value,
              style: AppTypography.body(),
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }

  Widget _badge(String text, Color color) {
    return Container(
      margin: const EdgeInsets.only(top: AppTheme.space2),
      padding: const EdgeInsets.symmetric(
        horizontal: AppTheme.space2,
        vertical: 3,
      ),
      decoration: BoxDecoration(
        color: color.withAlpha(0x22),
        borderRadius: BorderRadius.circular(AppTheme.radiusSm),
      ),
      child: Text(text, style: AppTypography.caption().copyWith(color: color)),
    );
  }

  Widget _button(
    IconData icon,
    String label,
    Future<void> Function() action, {
    bool danger = false,
  }) {
    return FilledButton.icon(
      onPressed: _busy ? null : action,
      icon: Icon(icon, size: 18),
      label: Text(label),
      style: FilledButton.styleFrom(
        backgroundColor: danger ? AppColors.dangerBg() : AppColors.accent,
        foregroundColor: danger ? AppColors.danger : AppColors.bgPrimary,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppTheme.radiusMd),
        ),
      ),
    );
  }
}
