import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:xterm/xterm.dart';
import 'package:xterm/src/core/cell.dart';
import 'package:webterm_mobile/core/theme/app_colors.dart';
import 'package:webterm_mobile/core/theme/app_theme.dart';
import 'package:webterm_mobile/core/theme/app_typography.dart';
import 'package:webterm_mobile/core/theme/app_motion.dart';
import 'package:webterm_mobile/core/providers/app_providers.dart';
import 'package:webterm_mobile/core/storage/terminal_disk_cache.dart';
import 'package:webterm_mobile/models/terminal_launch_state.dart';
import 'package:webterm_mobile/services/terminal_connection.dart';
import 'package:webterm_mobile/services/terminal_title_sync.dart';
import 'package:webterm_mobile/services/terminal_clipboard.dart';
import 'package:webterm_mobile/services/terminal_cache_coordinator.dart';
import 'package:webterm_mobile/services/server_session_monitor.dart';

class TerminalScreen extends ConsumerStatefulWidget {
  final String serverId;
  final String baseUrl;
  final String cookie;
  final String sessionId;
  final String requestTitle;
  final String requestSubtitle;
  final String? instanceId;
  final String? createdAt;

  const TerminalScreen({
    super.key,
    required this.serverId,
    required this.baseUrl,
    required this.cookie,
    required this.sessionId,
    required this.requestTitle,
    required this.requestSubtitle,
    this.instanceId,
    this.createdAt,
  });

  @override
  ConsumerState<TerminalScreen> createState() => _TerminalScreenState();
}

class _TerminalScreenState extends ConsumerState<TerminalScreen>
    implements ClipboardControlKeyHost {
  TerminalConnection? _connection;
  Terminal? _terminal;

  @visibleForTesting
  Terminal? get terminalForTest => _terminal;

  @visibleForTesting
  void refreshForTest() {
    if (mounted) {
      setState(() {});
    }
  }

  @visibleForTesting
  double get lineHeightForTest => _lineHeight;

  @visibleForTesting
  int get lastContentRowForTest => _lastContentRow();

  TerminalTitleSynchronizer? _titleSync;
  TerminalClipboardController? _clipboardController;

  bool _ctrlToggled = false;
  bool _altToggled = false;

  int _fontSize = 14;
  String _fontType = 'monospace';
  int _fontWeight = 500;
  int _boldFontWeight = 700;
  TerminalConnectionState _connectionState = TerminalConnectionState.disconnected;
  int _reconnectAttempts = 0;
  String _currentTitle = 'Terminal';

  // ── Keyboard avoidance ──

  double get _lineHeight => _measuredLineHeight > 0
      ? _measuredLineHeight
      : _fontSize * 1.2;
  double _measuredLineHeight = 0;

  double _maxBodyHeight = 0;

  TerminalCacheCoordinator? _cacheCoordinator;

  @override
  void initState() {
    super.initState();
    _currentTitle = widget.requestTitle;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _initTerminal();
    });
  }

  void _initTerminal() {
    final store = ref.read(serverConfigStoreProvider);
    _fontSize = store.getFontSize();
    _fontType = store.getFontType();
    _fontWeight = store.getFontWeight();
    _boldFontWeight = store.getBoldFontWeight();

    final coordinator = ref.read(cacheCoordinatorProvider);
    _cacheCoordinator = coordinator;
    final cachedMemory = coordinator.getMemory(
      widget.baseUrl,
      widget.sessionId,
      widget.instanceId ?? '',
      widget.createdAt ?? '',
    );

    final launchState = TerminalLaunchState.resolve(
      memory: cachedMemory,
      disk: null,
      requestTitle: widget.requestTitle,
      requestSubtitle: widget.requestSubtitle,
      requestCreatedAt: widget.createdAt,
      requestInstanceId: widget.instanceId,
      requestLastSeq: 0,
      requestColumns: 80,
      requestRows: 24,
    );

    final terminal = Terminal(
      maxLines: 10000,
      reflowEnabled: false,
    );
    _terminal = terminal;

    TerminalConnection conn;

    // Try to get the multiplexed monitor for this server (Direct mode).
    ServerSessionMonitor? monitor;
    try {
      final groups = ref.read(homeCoordinatorProvider).activeGroups;
      for (var g in groups) {
        if (g.server.url == widget.baseUrl) {
          final m = g.monitor;
          if (m != null && m.isConnected()) {
            monitor = m;
            break;
          }
        }
      }
    } catch (_) {}

    if (monitor != null) {
      conn = TerminalConnection.multiplexed(
        sessionId: widget.sessionId,
        monitor: monitor,
        lastSeq: launchState.lastSeq,
        columns: launchState.columns,
        rows: launchState.rows,
      );
    } else {
      conn = TerminalConnection(
        baseUrl: widget.baseUrl,
        cookie: widget.cookie,
        sessionId: widget.sessionId,
        lastSeq: launchState.lastSeq,
        columns: launchState.columns,
        rows: launchState.rows,
      );
    }
    _connection = conn;

    _titleSync = TerminalTitleSynchronizer(
      connectionProvider: () => conn,
    );
    _titleSync!.onTitleUpdated = (title) {
      if (mounted) {
        setState(() {
          _currentTitle = title;
        });
      }
    };

    _clipboardController = TerminalClipboardController(
      controlKeyHost: this,
    );

    conn.onConnectionStatus.listen((status) {
      if (mounted) {
        setState(() {
          _connectionState = status.state;
          _reconnectAttempts = status.reconnectAttempts;
        });
      }
    });

    conn.onOutput.listen((event) {
      try {
        final text = utf8.decode(event.data, allowMalformed: true);
        terminal.write(text);
        if (mounted) {
          setState(() {});
        }
      } catch (_) {}
    });

    conn.onState.listen((event) {
      try {
        final text = utf8.decode(event.data, allowMalformed: true);
        terminal.write(text);
        if (mounted) {
          setState(() {});
        }
      } catch (_) {}
    });

    conn.onScreenState.listen((state) {
      handleScreenState(state);
    });

    conn.onScreenDelta.listen((delta) {
      handleScreenDelta(delta);
    });

    conn.onExit.listen((code) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('会话已退出 (代码: $code)')),
        );
        context.pop();
      }
    });

    terminal.onOutput = (input) {
      var textToSend = input;
      if (_ctrlToggled) {
        if (textToSend.length == 1) {
          final codeUnit = textToSend.codeUnitAt(0);
          if (codeUnit >= 97 && codeUnit <= 122) {
            textToSend = String.fromCharCode(codeUnit - 96);
          } else if (codeUnit >= 65 && codeUnit <= 90) {
            textToSend = String.fromCharCode(codeUnit - 64);
          }
        }
        setState(() {
          _ctrlToggled = false;
        });
      }
      if (_altToggled) {
        textToSend = '\x1b$textToSend';
        setState(() {
          _altToggled = false;
        });
      }
      conn.sendInput(textToSend);
    };

    terminal.onResize = (width, height, pixelWidth, pixelHeight) {
      conn.updateSize(width, height);
      if (height > 0 && pixelHeight > 0) {
        final measured = pixelHeight / height;
        if (measured > 5.0) {
          _measuredLineHeight = measured;
        }
      }
    };

    conn.connect();
    setState(() {});
  }

  int _lastContentRow() {
    final buf = _terminal?.buffer;
    if (buf == null) return 0;

    final visibleRows = _terminal!.viewHeight;
    final scrollBack = buf.scrollBack;

    for (var row = visibleRows - 1; row >= 0; row--) {
      final lineIndex = scrollBack + row;
      if (lineIndex >= buf.height) continue;
      if (buf.lines[lineIndex].getTrimmedLength() > 0) {
        return row;
      }
    }
    return 0;
  }

  void _saveCacheSnapshot() {
    if (_connection == null || _terminal == null || _cacheCoordinator == null) {
      return;
    }
    final coordinator = _cacheCoordinator!;

    coordinator.saveCurrent(TerminalCacheSnapshot(
      baseUrl: widget.baseUrl,
      cookie: widget.cookie,
      sessionId: widget.sessionId,
      instanceId: widget.instanceId ?? '',
      createdAt: widget.createdAt ?? '',
      termTitle: _currentTitle,
      sessionName: widget.requestSubtitle,
      terminalSession: _connection,
      lastSeq: _connection!.lastSeq,
      columns: _terminal!.viewWidth,
      rows: _terminal!.viewHeight,
      diskMetadata: DiskCacheMetadata(
        baseUrl: widget.baseUrl,
        sessionId: widget.sessionId,
        instanceId: widget.instanceId ?? '',
        createdAt: widget.createdAt ?? '',
        termTitle: _currentTitle,
        sessionName: widget.requestSubtitle,
        columns: _terminal!.viewWidth,
        rows: _terminal!.viewHeight,
        lastSeq: _connection!.lastSeq,
      ),
    ));
  }

  @override
  bool readTerminalControlKey() => _ctrlToggled;

  @override
  void clearTerminalControlKey() {
    setState(() {
      _ctrlToggled = false;
    });
  }

  @override
  void dispose() {
    _saveCacheSnapshot();
    _titleSync?.cancel();
    _connection?.close('page disposed');
    super.dispose();
  }

  // ── Build ──

  @override
  Widget build(BuildContext context) {
    if (_terminal == null || _connection == null) {
      return const Scaffold(
        backgroundColor: AppColors.terminalBg,
        body: Center(
          child: CircularProgressIndicator(color: AppColors.accent),
        ),
      );
    }

    final bottomInset = MediaQuery.of(context).viewInsets.bottom;

    return Scaffold(
      backgroundColor: AppColors.terminalBg,
      resizeToAvoidBottomInset: false,
      appBar: _buildAppBar(),
      body: LayoutBuilder(
        builder: (context, constraints) {
          if (bottomInset == 0) {
            _maxBodyHeight = constraints.maxHeight;
          }
          final bodyHeight =
              _maxBodyHeight > 0 ? _maxBodyHeight : constraints.maxHeight;

          double terminalShift = 0;
          if (_terminal != null &&
              _lineHeight > 0 &&
              bodyHeight > 0 &&
              bottomInset > 0) {
            final visibleRows = _terminal!.viewHeight;
            final cursorRow =
                _terminal!.buffer.cursorY.clamp(0, visibleRows - 1);
            final lastContent = _lastContentRow();
            final protectedRow =
                max(cursorRow, lastContent).clamp(0, visibleRows - 1);

            const terminalPadding = 4.0;
            final protectedBottom =
                terminalPadding + (protectedRow + 1) * _lineHeight;
            final quickBarTop =
                bodyHeight - bottomInset - AppTheme.quickbarHeight;
            const buffer = 0.0;
            final neededShift = protectedBottom + buffer - quickBarTop;
            terminalShift = neededShift > 0 ? neededShift : 0;
          }

          return Stack(
            children: [
              Positioned(
                top: 0,
                left: 0,
                right: 0,
                bottom: AppTheme.quickbarHeight + bottomInset,
                child: ClipRect(
                  child: OverflowBox(
                    alignment: Alignment.topCenter,
                    minHeight: bodyHeight - AppTheme.quickbarHeight,
                    maxHeight: bodyHeight - AppTheme.quickbarHeight,
                    child: SizedBox(
                      height: bodyHeight - AppTheme.quickbarHeight,
                      child: Transform.translate(
                        offset: Offset(0, -terminalShift),
                        child: Container(
                          padding: const EdgeInsets.all(4),
                          color: AppColors.terminalBg,
                          child: TerminalView(
                            _terminal!,
                            theme: const TerminalTheme(
                              cursor: AppColors.accent,
                              selection: AppColors.overlay,
                              foreground: AppColors.terminalFg,
                              background: AppColors.terminalBg,
                              black: Color(0XFF000000),
                              red: Color(0XFFCD3131),
                              green: Color(0XFF0DBC79),
                              yellow: Color(0XFFE5E510),
                              blue: Color(0XFF2472C8),
                              magenta: Color(0XFFBC3FBC),
                              cyan: Color(0XFF11A8CD),
                              white: Color(0XFFE5E5E5),
                              brightBlack: Color(0XFF666666),
                              brightRed: Color(0XFFF14C4C),
                              brightGreen: Color(0XFF23D18B),
                              brightYellow: Color(0XFFF5F543),
                              brightBlue: Color(0XFF3B8EEA),
                              brightMagenta: Color(0XFFD670D6),
                              brightCyan: Color(0XFF29B8DB),
                              brightWhite: Color(0XFFFFFFFF),
                              searchHitBackground: Color(0XFFFFFF2B),
                              searchHitBackgroundCurrent: Color(0XFF31FF26),
                              searchHitForeground: Color(0XFF000000),
                            ),
                            textStyle: CustomTerminalStyle(
                              fontSize: _fontSize.toDouble(),
                              fontFamily: _fontType,
                              defaultFontWeight:
                                  _getFontWeightFromValue(_fontWeight),
                              boldFontWeight:
                                  _getFontWeightFromValue(_boldFontWeight),
                            ),
                            autoResize: true,
                            backgroundOpacity: 1.0,
                            cursorType: TerminalCursorType.block,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),

              Positioned(
                left: 0,
                right: 0,
                bottom: bottomInset,
                child: _buildQuickBar(_connection!),
              ),
            ],
          );
        },
      ),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: AppColors.bgSecondary,
      elevation: 0,
      surfaceTintColor: Colors.transparent,
      // 底部分割线对齐设计系统
      bottom: const PreferredSize(
        preferredSize: Size.fromHeight(1.0),
        child: Divider(height: 1, color: AppColors.borderPrimary),
      ),
      leading: IconButton(
        icon: const Icon(Icons.arrow_back, color: AppColors.textPrimary),
        onPressed: () => context.pop(),
      ),
      title: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(_currentTitle, style: AppTypography.heading()),
          _buildConnectionStatusRow(),
        ],
      ),
      actions: [
        IconButton(
          icon: const Icon(Icons.content_copy,
              color: AppColors.textSecondary, size: 20),
          onPressed: () async {
            final buffer = _terminal!.buffer;
            final lines = <String>[];
            for (var i = 0; i < buffer.lines.length; i++) {
              lines.add(buffer.lines[i].toString());
            }
            final messenger = ScaffoldMessenger.of(context);
            await _clipboardController?.copy(lines.join('\n'));
            messenger.showSnackBar(
              const SnackBar(content: Text('已复制终端日志')),
            );
          },
        ),
        IconButton(
          icon: const Icon(Icons.content_paste,
              color: AppColors.textSecondary, size: 20),
          onPressed: () {
            _clipboardController?.paste((text) {
              _connection?.sendInput(text);
            });
          },
        ),
        const SizedBox(width: 8),
      ],
    );
  }

  Widget _buildConnectionStatusRow() {
    final dotColor = _connectionStateColor(_connectionState);
    final pulsing = _connectionState == TerminalConnectionState.connecting ||
        _connectionState == TerminalConnectionState.reconnecting;

    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        StatusDot(color: dotColor, pulsing: pulsing, size: 7),
        const SizedBox(width: 5),
        Text(
          _connectionStateText(_connectionState),
          style: AppTypography.caption().copyWith(
            color: dotColor,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }

  Widget _buildQuickBar(TerminalConnection conn) {
    final keysRow1 = [
      _QuickKey(label: 'ESC', onTap: () => conn.sendInput('\x1b')),
      _QuickKey(label: 'TAB', onTap: () => conn.sendInput('\t')),
      _QuickKey(
        label: 'CTRL',
        isToggled: _ctrlToggled,
        onTap: () => setState(() => _ctrlToggled = !_ctrlToggled),
      ),
      _QuickKey(
        label: 'ALT',
        isToggled: _altToggled,
        onTap: () => setState(() => _altToggled = !_altToggled),
      ),
      _QuickKey(label: '|', onTap: () => conn.sendInput('|')),
      _QuickKey(label: '-', onTap: () => conn.sendInput('-')),
      _QuickKey(label: '/', onTap: () => conn.sendInput('/')),
    ];

    final keysRow2 = [
      _QuickKey(label: 'HOME', onTap: () => conn.sendInput('\x1b[1~')),
      _QuickKey(
          label: 'UP',
          icon: Icons.arrow_upward,
          onTap: () => conn.sendInput('\x1b[A')),
      _QuickKey(label: 'END', onTap: () => conn.sendInput('\x1b[4~')),
      _QuickKey(label: 'PGUP', onTap: () => conn.sendInput('\x1b[5~')),
      _QuickKey(
          label: 'LEFT',
          icon: Icons.arrow_back,
          onTap: () => conn.sendInput('\x1b[D')),
      _QuickKey(
          label: 'DOWN',
          icon: Icons.arrow_downward,
          onTap: () => conn.sendInput('\x1b[B')),
      _QuickKey(
          label: 'RIGHT',
          icon: Icons.arrow_forward,
          onTap: () => conn.sendInput('\x1b[C')),
      _QuickKey(label: 'PGDN', onTap: () => conn.sendInput('\x1b[6~')),
    ];

    return Container(
      key: const ValueKey('quick_bar'),
      color: AppColors.bgSecondary,
      padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 8),
      height: AppTheme.quickbarHeight,
      child: Column(
        children: [
          Expanded(
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: keysRow1.length,
              itemBuilder: (context, idx) => Padding(
                padding: const EdgeInsets.only(right: 6),
                child: keysRow1[idx],
              ),
            ),
          ),
          const SizedBox(height: 6),
          Expanded(
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: keysRow2.length,
              itemBuilder: (context, idx) => Padding(
                padding: const EdgeInsets.only(right: 6),
                child: keysRow2[idx],
              ),
            ),
          ),
        ],
      ),
    );
  }

  String _connectionStateText(TerminalConnectionState state) {
    switch (state) {
      case TerminalConnectionState.connected:
        return '已连接';
      case TerminalConnectionState.connecting:
        return '正在连接...';
      case TerminalConnectionState.reconnecting:
        return '正在重连... (尝试第 $_reconnectAttempts 次)';
      case TerminalConnectionState.disconnected:
        return '连接已断开';
    }
  }

  Color _connectionStateColor(TerminalConnectionState state) {
    switch (state) {
      case TerminalConnectionState.connected:
        return AppColors.success;
      case TerminalConnectionState.connecting:
      case TerminalConnectionState.reconnecting:
        return AppColors.warning;
      case TerminalConnectionState.disconnected:
        return AppColors.danger;
    }
  }

  static int parseColor(String? colorStr) {
    if (colorStr == null || colorStr.isEmpty || colorStr == 'default') return 0;
    if (colorStr == 'named:0' || colorStr == 'named:1') return 0;
    if (colorStr.startsWith('#')) {
      final v = int.parse(colorStr.substring(1), radix: 16) & CellColor.valueMask;
      return CellColor.rgb | v;
    } else if (colorStr.startsWith('ansi:')) {
      final idx = int.parse(colorStr.substring(5));
      return CellColor.palette | (idx & 0xFF);
    } else if (colorStr.startsWith('named:')) {
      final id = int.parse(colorStr.substring(6));
      return CellColor.named | (id & 0xFF);
    }
    return 0;
  }

  int buildCellFlags({
    bool bold = false,
    bool dim = false,
    bool italic = false,
    bool underline = false,
    bool blink = false,
    bool inverse = false,
    bool hidden = false,
    bool strike = false,
  }) {
    int flags = 0;
    if (bold) flags |= CellAttr.bold;
    if (dim) flags |= CellAttr.faint;
    if (italic) flags |= CellAttr.italic;
    if (underline) flags |= CellAttr.underline;
    if (blink) flags |= CellAttr.blink;
    if (inverse) flags |= CellAttr.inverse;
    if (hidden) flags |= CellAttr.invisible;
    if (strike) flags |= CellAttr.strikethrough;
    return flags;
  }

  void _writeSpanToLine(
    BufferLine line,
    int col,
    String text,
    int fg,
    int bg,
    int flags,
  ) {
    int lineCol = col;
    for (int i = 0; i < text.length; i++) {
      if (lineCol >= _terminal!.viewWidth) break;
      if (lineCol >= line.length) {
        line.resize(lineCol + 1);
      }
      final codePoint = text.codeUnitAt(i);
      line.setForeground(lineCol, fg);
      line.setBackground(lineCol, bg);
      line.setAttributes(lineCol, flags);
      line.setCodePoint(lineCol, codePoint);

      final width = line.getWidth(lineCol);
      if (width == 2) {
        final spacerCol = lineCol + 1;
        if (spacerCol < _terminal!.viewWidth) {
          if (spacerCol >= line.length) {
            line.resize(spacerCol + 1);
          }
          line.setCodePoint(spacerCol, 0);
          line.setForeground(spacerCol, fg);
          line.setBackground(spacerCol, bg);
          line.setAttributes(spacerCol, flags);
        }
        lineCol += 2;
      } else {
        lineCol += 1;
      }
    }
  }

  void handleScreenState(Map<String, dynamic> state) {
    if (_terminal == null) return;
    final buffer = _terminal!.buffer;
    final cols = state['cols'] as int;
    final rows = state['rows'] as int;

    _terminal!.resize(cols, rows);

    buffer.eraseDisplay();
    buffer.clearScrollback();

    final cursorRow = state['cursor_row'] as int;
    final cursorCol = state['cursor_col'] as int;
    buffer.setCursor(cursorCol, cursorRow);

    final cursorVisible = state['cursor_visible'] as bool? ?? true;
    _terminal!.setCursorVisibleMode(cursorVisible);

    final scrollBack = buffer.scrollBack;

    final List<dynamic> linesList = state['lines'] ?? [];
    for (var ld in linesList) {
      if (ld is! Map<String, dynamic>) continue;
      final row = ld['row'] as int;
      final absoluteRow = scrollBack + row;
      if (absoluteRow < 0 || absoluteRow >= buffer.lines.length) continue;
      final line = buffer.lines[absoluteRow];

      final List<dynamic>? spansList = ld['spans'];
      if (spansList != null) {
        line.eraseRange(0, line.length, _terminal!.cursor);
        for (var span in spansList) {
          if (span is! Map<String, dynamic>) continue;
          _writeSpanToLine(
            line,
            span['col'] as int? ?? 0,
            span['text'] as String? ?? '',
            parseColor(span['fg'] as String?),
            parseColor(span['bg'] as String?),
            buildCellFlags(
              bold: span['bold'] ?? false,
              dim: span['dim'] ?? false,
              italic: span['italic'] ?? false,
              underline: span['underline'] ?? false,
              blink: span['blink'] ?? false,
              inverse: span['inverse'] ?? false,
              hidden: span['hidden'] ?? false,
              strike: span['strike'] ?? false,
            ),
          );
        }
      }
    }
    if (mounted) {
      setState(() {});
    }
  }

  void handleScreenDelta(Map<String, dynamic> delta) {
    if (_terminal == null) return;
    final buffer = _terminal!.buffer;
    final scrollBack = buffer.scrollBack;

    final cursorRow = delta['cursor_row'] as int?;
    final cursorCol = delta['cursor_col'] as int?;
    if (cursorRow != null && cursorCol != null) {
      buffer.setCursor(cursorCol, cursorRow);
    }
    final cursorVisible = delta['cursor_visible'] as bool?;
    if (cursorVisible != null) {
      _terminal!.setCursorVisibleMode(cursorVisible);
    }

    final List<dynamic> dirtyLines = delta['dirty_lines'] ?? [];
    for (var ld in dirtyLines) {
      if (ld is! Map<String, dynamic>) continue;
      final row = ld['row'] as int;
      final absoluteRow = scrollBack + row;
      if (absoluteRow < 0 || absoluteRow >= buffer.lines.length) continue;
      final line = buffer.lines[absoluteRow];

      final List<dynamic>? cells = ld['cells'];
      if (cells != null) {
        for (var cell in cells) {
          if (cell is! Map<String, dynamic>) continue;
          _writeSpanToLine(
            line,
            cell['col'] as int? ?? 0,
            cell['char'] as String? ?? ' ',
            parseColor(cell['fg'] as String?),
            parseColor(cell['bg'] as String?),
            buildCellFlags(
              bold: cell['bold'] ?? false,
              dim: cell['dim'] ?? false,
              italic: cell['italic'] ?? false,
              underline: cell['underline'] ?? false,
              blink: cell['blink'] ?? false,
              inverse: cell['inverse'] ?? false,
              hidden: cell['hidden'] ?? false,
              strike: cell['strike'] ?? false,
            ),
          );
        }
      }

      final List<dynamic>? spans = ld['spans'];
      if (spans != null) {
        line.eraseRange(0, line.length, _terminal!.cursor);
        for (var span in spans) {
          if (span is! Map<String, dynamic>) continue;
          _writeSpanToLine(
            line,
            span['col'] as int? ?? 0,
            span['text'] as String? ?? '',
            parseColor(span['fg'] as String?),
            parseColor(span['bg'] as String?),
            buildCellFlags(
              bold: span['bold'] ?? false,
              dim: span['dim'] ?? false,
              italic: span['italic'] ?? false,
              underline: span['underline'] ?? false,
              blink: span['blink'] ?? false,
              inverse: span['inverse'] ?? false,
              hidden: span['hidden'] ?? false,
              strike: span['strike'] ?? false,
            ),
          );
        }
      }
    }
    if (mounted) {
      setState(() {});
    }
  }
}

class _QuickKey extends StatelessWidget {
  final String label;
  final IconData? icon;
  final bool isToggled;
  final VoidCallback onTap;

  const _QuickKey({
    required this.label,
    this.icon,
    this.isToggled = false,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Pressable(
      onTap: onTap,
      child: SizedBox(
        height: AppTheme.quickbarKeyHeight,
        child: ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor:
                isToggled ? AppColors.accent : AppColors.bgPrimary,
            foregroundColor:
                isToggled ? AppColors.bgPrimary : AppColors.textPrimary,
            elevation: 0,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(AppTheme.radiusSm),
              side: BorderSide(
                color:
                    isToggled ? AppColors.accent : AppColors.borderPrimary,
                width: 1.0,
              ),
            ),
            padding: const EdgeInsets.symmetric(horizontal: 14),
          ),
          onPressed: onTap,
          child: icon != null
              ? Icon(icon, size: 16)
              : Text(
                  label,
                  style: AppTypography.mono().copyWith(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: isToggled
                        ? AppColors.bgPrimary
                        : AppColors.textPrimary,
                  ),
                ),
        ),
      ),
    );
  }
}

FontWeight _getFontWeightFromValue(int value) {
  switch (value) {
    case 100:
      return FontWeight.w100;
    case 200:
      return FontWeight.w200;
    case 300:
      return FontWeight.w300;
    case 400:
      return FontWeight.w400;
    case 500:
      return FontWeight.w500;
    case 600:
      return FontWeight.w600;
    case 700:
      return FontWeight.w700;
    case 800:
      return FontWeight.w800;
    case 900:
      return FontWeight.w900;
    default:
      return FontWeight.w500;
  }
}

class CustomTerminalStyle extends TerminalStyle {
  final FontWeight defaultFontWeight;
  final FontWeight boldFontWeight;

  const CustomTerminalStyle({
    super.fontSize,
    super.height,
    super.fontFamily,
    super.fontFamilyFallback,
    required this.defaultFontWeight,
    required this.boldFontWeight,
  });

  @override
  TextStyle toTextStyle({
    Color? color,
    Color? backgroundColor,
    bool bold = false,
    bool italic = false,
    bool underline = false,
  }) {
    return TextStyle(
      fontSize: fontSize,
      height: height,
      fontFamily: fontFamily,
      fontFamilyFallback: fontFamilyFallback,
      color: color,
      backgroundColor: backgroundColor,
      fontWeight: bold ? boldFontWeight : defaultFontWeight,
      fontStyle: italic ? FontStyle.italic : FontStyle.normal,
      decoration: underline ? TextDecoration.underline : TextDecoration.none,
    );
  }
}
