import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:webterm_mobile/core/theme/app_colors.dart';
import 'package:webterm_mobile/core/theme/app_theme.dart';
import 'package:webterm_mobile/core/theme/app_typography.dart';
import 'package:webterm_mobile/core/theme/app_motion.dart';
import 'package:webterm_mobile/core/providers/app_providers.dart';
import 'package:webterm_mobile/models/server_config.dart';
import 'package:webterm_mobile/services/server_group_controller.dart';
import 'package:webterm_mobile/services/session_command_controller.dart';

class DeviceSessionsScreen extends ConsumerStatefulWidget {
  final String serverId;

  const DeviceSessionsScreen({super.key, required this.serverId});

  @override
  ConsumerState<DeviceSessionsScreen> createState() =>
      _DeviceSessionsScreenState();
}

class _DeviceSessionsScreenState extends ConsumerState<DeviceSessionsScreen> {
  ServerGroupStatus _groupStatus = ServerGroupStatus.connecting;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _loadSessions();
    });
  }

  void _loadSessions() {
    final server = _findServer();
    if (server == null) return;

    final coordinator = ref.read(homeCoordinatorProvider);
    ref
        .read(homeSessionsProvider.notifier)
        .setStatus(server.id, ServerGroupStatus.connecting);

    coordinator.loadDeviceSessions(server, (status) {
      if (mounted) {
        setState(() {
          _groupStatus = status;
        });
        ref.read(homeSessionsProvider.notifier).setStatus(server.id, status);
      }
    });
  }

  ServerConfig? _findServer() {
    final servers = ref.read(serverListProvider);
    final relayDevices = ref.read(relayDevicesProvider);
    try {
      return [...servers, ...relayDevices]
          .firstWhere((s) => s.id == widget.serverId);
    } catch (_) {
      return null;
    }
  }

  @override
  Widget build(BuildContext context) {
    final server = _findServer();
    if (server == null) {
      return Scaffold(
        backgroundColor: AppColors.bgPrimary,
        appBar: _buildAppBar('未找到'),
        body: Center(
          child: Text('未找到服务器配置。', style: AppTypography.body()),
        ),
      );
    }

    final sessionsState = ref.watch(homeSessionsProvider);
    final sessionList = sessionsState.sessions[server.id] ?? [];
    final error = sessionsState.errors[server.id];

    final commandController = SessionCommandController(
      api: ref.read(webTermApiProvider),
      listener: RiverpodSessionCommandListener(ref, context, server),
    );

    return Scaffold(
      backgroundColor: AppColors.bgPrimary,
      appBar: _buildAppBar(
        server.name.isNotEmpty ? server.name : '服务器会话',
        subtitle: server.url,
        status: _groupStatus,
        actions: [
          if (!server.relayDevice)
            IconButton(
              icon: const Icon(Icons.edit, color: AppColors.textTertiary,
                  size: 20),
              onPressed: () => _showEditServerDialog(context, server),
            ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: () async {
          _loadSessions();
        },
        color: AppColors.accent,
        backgroundColor: AppColors.bgSecondary,
        child: _buildBody(sessionList, error, server, commandController),
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: AppColors.accent,
        foregroundColor: AppColors.bgPrimary,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppTheme.radiusLg),
        ),
        onPressed: () {
          commandController.createSessionOnServer(server);
        },
        child: const Icon(Icons.add),
      ),
    );
  }

  PreferredSizeWidget _buildAppBar(
    String title, {
    String? subtitle,
    ServerGroupStatus? status,
    List<Widget>? actions,
  }) {
    return AppBar(
      backgroundColor: AppColors.bgSecondary,
      elevation: 0,
      surfaceTintColor: Colors.transparent,
      // 底部分割线对齐设计系统
      bottom: const PreferredSize(
        preferredSize: Size.fromHeight(1.0),
        child: Divider(height: 1, color: AppColors.borderPrimary),
      ),
      leading: IconButton(
        icon: const Icon(Icons.arrow_back, color: AppColors.textPrimary),
        onPressed: () => context.pop(),
      ),
      title: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: AppTypography.heading()),
          if (subtitle != null)
            Text(
              subtitle,
              style: AppTypography.caption(),
              overflow: TextOverflow.ellipsis,
            ),
        ],
      ),
      actions: [
        if (status != null) ...[
          _buildStatusRow(status),
          const SizedBox(width: AppTheme.space3),
        ],
        ...?actions,
      ],
    );
  }

  Widget _buildStatusRow(ServerGroupStatus status) {
    final dotColor = switch (status) {
      ServerGroupStatus.connected => AppColors.success,
      ServerGroupStatus.connecting => AppColors.warning,
      ServerGroupStatus.disconnected => AppColors.danger,
    };
    final pulsing = status == ServerGroupStatus.connecting;
    final label = switch (status) {
      ServerGroupStatus.connected => '已连接',
      ServerGroupStatus.connecting => '连接中',
      ServerGroupStatus.disconnected => '已断开',
    };

    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        StatusDot(color: dotColor, pulsing: pulsing),
        const SizedBox(width: 6),
        Text(
          label,
          style: AppTypography.caption().copyWith(fontWeight: FontWeight.w600),
        ),
      ],
    );
  }

  Widget _buildBody(
    List<dynamic> sessionList,
    String? error,
    ServerConfig server,
    SessionCommandController commandController,
  ) {
    if (error != null && sessionList.isEmpty) {
      return ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        children: [
          SizedBox(height: MediaQuery.of(context).size.height * 0.3),
          Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.error_outline, color: AppColors.danger,
                    size: 40),
                const SizedBox(height: AppTheme.space2),
                Text(
                  error,
                  style: AppTypography.body(),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: AppTheme.space2),
                TextButton(
                  onPressed: _loadSessions,
                  child: const Text('重试',
                      style: TextStyle(color: AppColors.accent)),
                ),
              ],
            ),
          ),
        ],
      );
    }

    if (sessionList.isEmpty && _groupStatus == ServerGroupStatus.connecting) {
      return const Center(
        child: CircularProgressIndicator(color: AppColors.accent),
      );
    }

    if (sessionList.isEmpty) {
      return ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        children: [
          SizedBox(height: MediaQuery.of(context).size.height * 0.3),
          Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  r'$ no_active_sessions',
                  style: AppTypography.mono().copyWith(
                    color: AppColors.textDisabled,
                  ),
                ),
                const SizedBox(height: AppTheme.space2),
                Text(
                  '点击右下角 + 创建新会话',
                  style: AppTypography.caption(),
                ),
              ],
            ),
          ),
        ],
      );
    }

    return ListView.builder(
      physics: const AlwaysScrollableScrollPhysics(),
      padding: const EdgeInsets.all(AppTheme.space4),
      itemCount: sessionList.length,
      itemBuilder: (context, index) {
        final session = sessionList[index] as Map<String, dynamic>;
        final sessionId = session['id']?.toString() ?? '';

        return Padding(
          padding: const EdgeInsets.only(bottom: AppTheme.space3),
          child: StaggerItem(
            index: index,
            child: Dismissible(
              key: Key('sess_$sessionId'),
              direction: DismissDirection.endToStart,
              background: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: AppTheme.space4),
                decoration: BoxDecoration(
                  color: AppColors.danger,
                  borderRadius: BorderRadius.circular(AppTheme.radiusMd),
                ),
                alignment: Alignment.centerRight,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Text(
                      '关闭会话',
                      style: AppTypography.heading().copyWith(
                        color: AppColors.bgPrimary,
                      ),
                    ),
                    const SizedBox(width: 8),
                    const Icon(Icons.close, color: AppColors.bgPrimary),
                  ],
                ),
              ),
              onDismissed: (direction) {
                commandController.deleteSession(server, sessionId);
              },
              child: _buildSessionCard(
                  context, server, session, commandController),
            ),
          ),
        );
      },
    );
  }

  Widget _buildSessionCard(
    BuildContext context,
    ServerConfig server,
    Map<String, dynamic> session,
    SessionCommandController commandController,
  ) {
    final sessionId = session['id']?.toString() ?? '';
    final rawTitle = session['termTitle']?.toString() ?? '';
    final termTitle = rawTitle.isEmpty ? 'Terminal' : rawTitle;
    final name = session['name']?.toString() ?? '';
    final columns = session['cols'] as int? ?? 80;
    final rows = session['rows'] as int? ?? 24;
    final instanceId = session['instanceId']?.toString() ?? '';
    final createdAt = session['createdAt']?.toString() ?? '';

    return Pressable(
      onTap: () {
        var url = '/terminal?serverId=${server.id}'
            '&baseUrl=${Uri.encodeComponent(server.url)}'
            '&cookie=${Uri.encodeComponent(server.cookie)}'
            '&sessionId=${Uri.encodeComponent(sessionId)}'
            '&title=${Uri.encodeComponent(termTitle)}'
            '&subtitle=${Uri.encodeComponent(name)}';
        if (instanceId.isNotEmpty) {
          url += '&instanceId=${Uri.encodeComponent(instanceId)}';
        }
        if (createdAt.isNotEmpty) {
          url += '&createdAt=${Uri.encodeComponent(createdAt)}';
        }
        context.push(url);
      },
      child: AppCard(
        padding: const EdgeInsets.symmetric(
          horizontal: AppTheme.cardPaddingH,
          vertical: AppTheme.cardPaddingV,
        ),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    name.isNotEmpty ? name : termTitle,
                    style: AppTypography.heading(),
                  ),
                  const SizedBox(height: AppTheme.space1),
                  Row(
                    children: [
                      Text(
                        sessionId.length > 8 ? sessionId.substring(0, 8) : sessionId,
                        style: AppTypography.monoTiny(),
                      ),
                      const SizedBox(width: AppTheme.space3),
                      Text(
                        '${columns}x$rows',
                        style: AppTypography.caption(),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            IconButton(
              icon: const Icon(Icons.drive_file_rename_outline,
                  color: AppColors.textTertiary, size: 20),
              onPressed: () => _showRenameDialog(
                  context, server, sessionId, name, commandController),
            ),
          ],
        ),
      ),
    );
  }

  void _showRenameDialog(
    BuildContext context,
    ServerConfig server,
    String sessionId,
    String currentName,
    SessionCommandController commandController,
  ) {
    final controller = TextEditingController(text: currentName);
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          backgroundColor: AppColors.bgSecondary,
          title: Text('重命名会话', style: AppTypography.dialogTitle()),
          content: TextField(
            controller: controller,
            style: AppTypography.mono().copyWith(color: AppColors.textPrimary),
            autofocus: true,
            decoration: const InputDecoration(
              labelText: '会话别名',
              labelStyle: TextStyle(color: AppColors.textSecondary),
              enabledBorder: UnderlineInputBorder(
                borderSide: BorderSide(color: AppColors.borderPrimary),
              ),
              focusedBorder: UnderlineInputBorder(
                borderSide: BorderSide(color: AppColors.accent),
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('取消',
                  style: TextStyle(color: AppColors.textSecondary)),
            ),
            TextButton(
              onPressed: () {
                final newName = controller.text.trim();
                commandController.renameSession(server, sessionId, newName);
                Navigator.pop(context);
              },
              child: const Text('重命名',
                  style: TextStyle(color: AppColors.accent)),
            ),
          ],
        );
      },
    );
  }

  void _showEditServerDialog(BuildContext context, ServerConfig server) {
    final nameController = TextEditingController(text: server.name);
    final urlController = TextEditingController(text: server.url);
    final userController = TextEditingController(text: server.username);
    final pwdController = TextEditingController(text: server.password);

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          backgroundColor: AppColors.bgSecondary,
          title: Text('编辑服务器', style: AppTypography.dialogTitle()),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                _field(nameController, '别名'),
                _field(urlController, '主机地址'),
                _field(userController, '用户名'),
                _field(pwdController, '密码', obscure: true),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('取消',
                  style: TextStyle(color: AppColors.textSecondary)),
            ),
            TextButton(
              onPressed: () {
                ref
                    .read(serverListProvider.notifier)
                    .addOrUpdate(
                      server,
                      nameController.text.trim(),
                      urlController.text.trim(),
                      server.cookie,
                      userController.text.trim(),
                      pwdController.text.trim(),
                    );
                Navigator.pop(context);
              },
              child: const Text('保存',
                  style: TextStyle(color: AppColors.accent)),
            ),
          ],
        );
      },
    );
  }

  Widget _field(
    TextEditingController controller,
    String label, {
    bool obscure = false,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: AppTheme.space3),
      child: TextField(
        controller: controller,
        obscureText: obscure,
        style: AppTypography.mono().copyWith(color: AppColors.textPrimary),
        decoration: InputDecoration(
          labelText: label,
          labelStyle: const TextStyle(color: AppColors.textSecondary),
          enabledBorder: const UnderlineInputBorder(
            borderSide: BorderSide(color: AppColors.borderPrimary),
          ),
          focusedBorder: const UnderlineInputBorder(
            borderSide: BorderSide(color: AppColors.accent),
          ),
        ),
      ),
    );
  }
}

class RiverpodSessionCommandListener implements SessionCommandListener {
  final WidgetRef ref;
  final BuildContext context;
  final ServerConfig server;

  RiverpodSessionCommandListener(this.ref, this.context, this.server);

  @override
  void onAuthenticated(ServerConfig server) {
    ref.read(serverListProvider.notifier).updateServer(server);
    ref.read(homeCoordinatorProvider).updateServerInHolder(server);
  }

  @override
  void onOpenTerminal(
    String baseUrl,
    String cookie,
    String sessionId,
    String termTitle,
    String sessionName,
  ) {
    context.push(
      '/terminal?serverId=${server.id}'
      '&baseUrl=${Uri.encodeComponent(baseUrl)}'
      '&cookie=${Uri.encodeComponent(cookie)}'
      '&sessionId=${Uri.encodeComponent(sessionId)}'
      '&title=${Uri.encodeComponent(termTitle)}'
      '&subtitle=${Uri.encodeComponent(sessionName)}',
    );
  }

  @override
  void onRemoveCachedTerminal(String baseUrl, String sessionId) {
    final cache = ref.read(cacheCoordinatorProvider);
    cache.removeTerminal(baseUrl, sessionId, '', '', null);
  }

  @override
  void onSessionClosed(ServerConfig server, String sessionId) {
    ref.read(homeSessionsProvider.notifier).clearServer(server.id);
  }

  @override
  void onShowHome() {
    final coordinator = ref.read(homeCoordinatorProvider);
    coordinator.loadDeviceSessions(server, (status) {
      ref.read(homeSessionsProvider.notifier).setStatus(server.id, status);
    });
  }

  @override
  void showMessage(String message) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }
}
