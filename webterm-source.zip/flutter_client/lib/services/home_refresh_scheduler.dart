import 'dart:async';
import 'server_group_controller.dart';

abstract class HomeRefreshSchedulerListener {
  bool get isHomeRefreshActive;
  List<ServerGroupController> get activeGroups;
  void loadSessionsForGroup(ServerGroupController group);
}

class HomeRefreshScheduler {
  static const int initialDelayMs = 3000;
  static const int maxDelayMs = 60000;

  final HomeRefreshSchedulerListener listener;
  int _delayMs = initialDelayMs;
  Timer? _timer;

  HomeRefreshScheduler(this.listener);

  void reset() {
    _delayMs = initialDelayMs;
    cancel();
  }

  void cancel() {
    _timer?.cancel();
    _timer = null;
  }

  void scheduleInitial() {
    schedule(initialDelayMs);
  }

  void schedule(int requestedDelayMs) {
    cancel();
    if (!listener.isHomeRefreshActive) return;

    var needsFallbackRefresh = false;
    for (var group in listener.activeGroups) {
      if (!group.isConnected()) {
        needsFallbackRefresh = true;
        break;
      }
    }

    if (needsFallbackRefresh) {
      final delay = requestedDelayMs > initialDelayMs ? requestedDelayMs : initialDelayMs;
      _timer = Timer(Duration(milliseconds: delay), _runRefresh);
    }
  }

  void _runRefresh() {
    if (!listener.isHomeRefreshActive) return;

    var needsFallbackRefresh = false;
    for (var group in listener.activeGroups) {
      if (!group.isConnected()) {
        needsFallbackRefresh = true;
        listener.loadSessionsForGroup(group);
      }
    }

    if (needsFallbackRefresh) {
      schedule(_nextDelay());
    }
  }

  int _nextDelay() {
    _delayMs = (_delayMs * 2).clamp(initialDelayMs, maxDelayMs);
    return _delayMs;
  }
}
