import 'package:dio/dio.dart';
import 'package:webterm_mobile/models/go_core_agent.dart';

class GoCoreAgentSnapshot {
  final GoCoreAgentStatus status;
  final GoCoreAgentConfig config;
  final List<GoCoreLogEntry> logs;

  const GoCoreAgentSnapshot({
    required this.status,
    required this.config,
    required this.logs,
  });
}

class GoCoreAgentService {
  final Dio _dio;

  GoCoreAgentService(this._dio);

  Future<GoCoreAgentSnapshot> fetchSnapshot(String controlUrl) async {
    final base = _normalizeControlUrl(controlUrl);
    final responses = await Future.wait([
      _dio.get('$base/control/status'),
      _dio.get('$base/control/config'),
      _dio.get('$base/control/logs', queryParameters: {'limit': 80}),
    ]);
    return GoCoreAgentSnapshot(
      status: GoCoreAgentStatus.fromJson(_asMap(responses[0].data)),
      config: GoCoreAgentConfig.fromJson(_asMap(responses[1].data)),
      logs: _asList(
        responses[2].data,
      ).map((item) => GoCoreLogEntry.fromJson(_asMap(item))).toList(),
    );
  }

  Future<GoCoreAgentConfig> fetchConfig(String controlUrl) async {
    final response = await _dio.get(
      '${_normalizeControlUrl(controlUrl)}/control/config',
    );
    return GoCoreAgentConfig.fromJson(_asMap(response.data));
  }

  Future<void> saveConfig(String controlUrl, GoCoreAgentConfig config) async {
    await _dio.put(
      '${_normalizeControlUrl(controlUrl)}/control/config',
      data: config.toJson(),
    );
  }

  Future<GoCoreConnectionTestResult> testConnection(
    String controlUrl,
    GoCoreAgentConfig config, {
    required bool live,
  }) async {
    final response = await _dio.post(
      '${_normalizeControlUrl(controlUrl)}/control/connection/test',
      data: {'mode': config.mode, 'live': live, 'config': config.toJson()},
      options: Options(
        validateStatus: (status) => status != null && status < 500,
      ),
    );
    return GoCoreConnectionTestResult.fromJson(_asMap(response.data));
  }

  Future<void> setMode(String controlUrl, String mode) async {
    await _dio.post('${_normalizeControlUrl(controlUrl)}/control/mode/$mode');
  }

  Future<void> restart(String controlUrl) async {
    await _dio.post('${_normalizeControlUrl(controlUrl)}/control/restart');
  }

  Future<void> stop(String controlUrl) async {
    await _dio.post('${_normalizeControlUrl(controlUrl)}/control/stop');
  }

  String _normalizeControlUrl(String value) {
    final trimmed = value.trim();
    if (trimmed.isEmpty) {
      return 'http://127.0.0.1:18081';
    }
    final withScheme =
        trimmed.startsWith('http://') || trimmed.startsWith('https://')
        ? trimmed
        : 'http://$trimmed';
    return withScheme.endsWith('/')
        ? withScheme.substring(0, withScheme.length - 1)
        : withScheme;
  }
}

Map<String, dynamic> _asMap(Object? value) {
  if (value is Map<String, dynamic>) {
    return value;
  }
  if (value is Map) {
    return value.map((key, val) => MapEntry(key.toString(), val));
  }
  return <String, dynamic>{};
}

List<dynamic> _asList(Object? value) {
  return value is List ? value : const [];
}
