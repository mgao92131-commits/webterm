import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';
import 'package:web_socket_channel/io.dart';
import 'package:webterm_mobile/core/network/webterm_protocol.dart';
import 'package:webterm_mobile/core/network/webterm_urls.dart';
import 'package:webterm_mobile/models/server_config.dart';

class ServerSessionMonitor {
  ServerConfig server;
  
  bool _connected = false;
  bool _enabled = false;
  int _reconnectAttempts = 0;
  
  void updateServer(ServerConfig newServer) {
    server = newServer;
    if (!_connected && _enabled) {
      _reconnectTimer?.cancel();
      _releaseSocket('config updated');
      _connectNow();
    }
  }
  
  IOWebSocketChannel? _channel;
  Timer? _reconnectTimer;

  // Stream Controllers
  final _onConnectedController = StreamController<bool>.broadcast();
  final _onPollingFallbackController = StreamController<void>.broadcast();
  final _onSessionsController = StreamController<List<dynamic>>.broadcast();
  final _onSessionController = StreamController<Map<String, dynamic>>.broadcast();
  final _onSessionClosedController = StreamController<String>.broadcast();
  final _onDevicesController = StreamController<List<dynamic>>.broadcast();
  final _onErrorController = StreamController<String>.broadcast();
  final _onAuthErrorController = StreamController<void>.broadcast();

  // ── Tunnel frame routing (multiplexed terminal channels) ──
  final _onTunnelFrameController =
      StreamController<Map<String, dynamic>>.broadcast();
  final _activeTerminals = <String, _ActiveTerminalInfo>{};

  /// Subscribed by [TerminalConnection] in multiplexed mode to receive
  /// decoded tunnel frame payloads keyed by tunnelId.
  Stream<Map<String, dynamic>> get onTunnelFrame =>
      _onTunnelFrameController.stream;

  // Streams
  Stream<bool> get onConnected => _onConnectedController.stream;
  Stream<void> get onPollingFallback => _onPollingFallbackController.stream;
  Stream<List<dynamic>> get onSessions => _onSessionsController.stream;
  Stream<Map<String, dynamic>> get onSession => _onSessionController.stream;
  Stream<String> get onSessionClosed => _onSessionClosedController.stream;
  Stream<List<dynamic>> get onDevices => _onDevicesController.stream;
  Stream<String> get onError => _onErrorController.stream;
  Stream<void> get onAuthError => _onAuthErrorController.stream;

  ServerSessionMonitor(this.server);

  void start() {
    if (server.url.isEmpty) {
      stop();
      return;
    }
    _enabled = true;
    if (_channel != null) return;

    _connectNow();
  }

  void stop() {
    _enabled = false;
    _connected = false;
    _reconnectTimer?.cancel();
    _releaseSocket('closing monitor');
  }

  bool isConnected() => _connected;
  bool isEnabled() => _enabled;

  Future<void> _connectNow() async {
    if (!_enabled) return;

    var urlString = '${WebTermUrls.toWebSocketUrl(server.url)}/ws/sessions';
    if (server.relayDevice && server.deviceId.isNotEmpty) {
      urlString += '?deviceId=${WebTermUrls.encodePath(server.deviceId)}';
    }

    try {
      final ws = await WebSocket.connect(
        urlString,
        headers: {'Cookie': server.cookie},
      ).timeout(const Duration(seconds: 8));

      if (!_enabled) {
        ws.close();
        return;
      }

      _channel = IOWebSocketChannel(ws);
      _connected = true;
      _reconnectAttempts = 0;
      _onConnectedController.add(true);

      _channel!.stream.listen(
        (data) {
          if (!_enabled) return;
          if (data is List<int>) {
            _handleTunnelFrame(Uint8List.fromList(data)); // Binary → tunnel frame routing
            return;
          }
          if (data is String) {
            _dispatchMessage(data, server.relayDevice ? server.deviceId : null);
          }
        },
        onError: (err) {
          if (!_enabled) return;
          _handleFailure(err.toString());
        },
        onDone: () {
          if (!_enabled) return;
          _handleDisconnected();
        },
      );

      // Recover active terminals after reconnection.
      if (_activeTerminals.isNotEmpty) {
        _recoverActiveTerminals();
      }
    } on SocketException catch (e) {
      if (e.message.contains('401') || e.toString().contains('401')) {
        _handleAuthError();
      } else {
        _handleFailure(e.toString());
      }
    } catch (e) {
      final errorStr = e.toString();
      if (errorStr.contains('401') || errorStr.contains('Unauthorized')) {
        _handleAuthError();
      } else {
        _handleFailure(errorStr);
      }
    }
  }

  void _handleAuthError() {
    _connected = false;
    _releaseSocket('unauthorized');
    _onErrorController.add('401');
    _onAuthErrorController.add(null);
    _scheduleReconnect();
  }

  void _handleFailure(String error) {
    _connected = false;
    _onErrorController.add(error);
    _handleDisconnected();
  }

  void _handleDisconnected() {
    _connected = false;
    _onConnectedController.add(false);
    _onPollingFallbackController.add(null);
    _releaseSocket('disconnected');
    _scheduleReconnect();
  }

  void _scheduleReconnect() {
    if (!_enabled) return;
    _reconnectTimer?.cancel();
    
    _reconnectAttempts++;
    final cap = math.min(1000 * _reconnectAttempts, 8000);
    final delayMs = math.max(200, (math.Random().nextDouble() * cap).toInt());

    _reconnectTimer = Timer(Duration(milliseconds: delayMs), () {
      if (_enabled) start();
    });
  }

  void _dispatchMessage(String text, String? relayDeviceId) {
    try {
      final Map<String, dynamic> msg = json.decode(text);
      _prefixRelaySessionIds(msg, relayDeviceId);

      final type = msg['type'] as String?;
      if (type == 'sessions') {
        final List<dynamic> data = msg['data'] ?? [];
        _onSessionsController.add(data);
      } else if (type == 'session') {
        final Map<String, dynamic>? sessionData = msg['data'];
        if (sessionData != null) {
          _onSessionController.add(sessionData);
        }
      } else if (type == 'session-closed') {
        final id = msg['id'] as String?;
        if (id != null) {
          _onSessionClosedController.add(id);
        }
      } else if (type == 'devices') {
        final List<dynamic> devices = msg['devices'] ?? [];
        _onDevicesController.add(devices);
      } else if (type == 'error') {
        final message = msg['message']?.toString() ?? 'unknown error';
        _onErrorController.add(message);
      }
    } catch (_) {}
  }

  void requestDevicesList() {
    if (_channel == null || !_connected) return;
    try {
      final msg = json.encode({'type': 'list-devices'});
      _channel!.sink.add(msg);
    } catch (_) {}
  }

  void _prefixRelaySessionIds(Map<String, dynamic> msg, String? relayDeviceId) {
    if (relayDeviceId == null || relayDeviceId.isEmpty) return;
    final type = msg['type'] as String?;
    if (type == 'sessions') {
      final List<dynamic>? sessions = msg['data'];
      if (sessions == null) return;
      for (var session in sessions) {
        if (session is Map<String, dynamic>) {
          _prefixRelaySessionId(session, relayDeviceId);
        }
      }
    } else if (type == 'session') {
      final Map<String, dynamic>? data = msg['data'];
      if (data != null) {
        _prefixRelaySessionId(data, relayDeviceId);
      }
    } else if (type == 'session-closed') {
      final id = _prefixedSessionId(msg['id'] as String?, relayDeviceId);
      if (id.isNotEmpty) msg['id'] = id;
    }
  }

  void _prefixRelaySessionId(Map<String, dynamic>? session, String relayDeviceId) {
    if (session == null) return;
    final id = _prefixedSessionId(session['id'] as String?, relayDeviceId);
    if (id.isNotEmpty) session['id'] = id;
  }

  String _prefixedSessionId(String? id, String relayDeviceId) {
    if (id == null || id.isEmpty || id.contains(':')) return id ?? '';
    return '$relayDeviceId:$id';
  }

  void _releaseSocket(String reason) {
    if (_channel != null) {
      _channel!.sink.close(1000, reason);
      _channel = null;
    }
  }

  void dispose() {
    stop();
    _onConnectedController.close();
    _onPollingFallbackController.close();
    _onSessionsController.close();
    _onSessionController.close();
    _onSessionClosedController.close();
    _onDevicesController.close();
    _onErrorController.close();
    _onAuthErrorController.close();
    _onTunnelFrameController.close();
  }

  // ── Tunnel frame encoding / decoding ──

  void _handleTunnelFrame(Uint8List data) {
    if (data.length < 3) return;
    if (data[0] != 0x01) return; // Only MsgTypeWSData

    final idLen = data[1];
    if (data.length < 2 + idLen + 1) return;

    final tunnelId = utf8.decode(data.sublist(2, 2 + idLen));
    final extraByte = data[2 + idLen];
    final payload = data.sublist(3 + idLen);

    // Manager channel: payload is JSON text, route to _dispatchMessage.
    if (tunnelId == 'manager') {
      final text = utf8.decode(payload);
      _dispatchMessage(text, server.relayDevice ? server.deviceId : null);
      return;
    }

    // Terminal channel: payload is raw webterm.binary.v1 frame.
    _onTunnelFrameController.add({
      'tunnelId': tunnelId,
      'payload': payload,
    });
  }

  void _sendTunnelFrame(String tunnelId, Uint8List payload) {
    if (_channel == null || !_connected) return;

    final idBytes = utf8.encode(tunnelId);
    if (idBytes.length > 255) return;

    final frame = Uint8List(3 + idBytes.length + payload.length);
    frame[0] = 0x01; // MsgTypeWSData
    frame[1] = idBytes.length;
    frame.setAll(2, idBytes);
    frame[2 + idBytes.length] = 0x02; // ExtraByte = Binary
    frame.setAll(3 + idBytes.length, payload);

    _channel!.sink.add(frame);
  }

  // ── Terminal channel control (multiplexed mode) ──

  void activateTerminal(String sessionId,
      {int lastSeq = 0, int cols = 0, int rows = 0}) {
    _activeTerminals[sessionId] = _ActiveTerminalInfo(lastSeq, cols, rows);

    _sendJson({
      'type': 'ws-connect',
      'tunnelConnectionId': 'term:$sessionId',
      'path': '/ws/sessions/$sessionId',
      'protocols': ['webterm.screen.v1', 'webterm.binary.v1'],
    });

    // Immediately send Hello via tunnel frame (Text version).
    _sendTunnelFrameText(
      'term:$sessionId',
      json.encode({
        'type': 'hello',
        'lastSeq': lastSeq,
        'cols': cols,
        'rows': rows,
      }),
    );
  }

  void deactivateTerminal(String sessionId) {
    _activeTerminals.remove(sessionId);
    _sendJson({
      'type': 'ws-close',
      'tunnelConnectionId': 'term:$sessionId',
    });
  }

  void sendTerminalInput(String sessionId, String data) {
    _sendTunnelFrame(
      'term:$sessionId',
      WebTermProtocol.frame(
        WebTermProtocol.msgInput,
        utf8.encode(data),
      ),
    );
  }

  void sendTerminalInputText(String sessionId, String data) {
    _sendTunnelFrameText(
      'term:$sessionId',
      json.encode({
        'type': 'input',
        'data': data,
      }),
    );
  }

  void sendTerminalResize(String sessionId, int cols, int rows) {
    _sendTunnelFrame(
      'term:$sessionId',
      WebTermProtocol.frame(
        WebTermProtocol.msgResize,
        utf8.encode(json.encode({'cols': cols, 'rows': rows})),
      ),
    );
  }

  void sendTerminalResizeText(String sessionId, int cols, int rows) {
    _sendTunnelFrameText(
      'term:$sessionId',
      json.encode({
        'type': 'resize',
        'cols': cols,
        'rows': rows,
      }),
    );
  }

  void _sendTunnelFrameText(String tunnelId, String text) {
    if (_channel == null || !_connected) return;

    final idBytes = utf8.encode(tunnelId);
    if (idBytes.length > 255) return;

    final payload = utf8.encode(text);
    final frame = Uint8List(3 + idBytes.length + payload.length);
    frame[0] = 0x01; // MsgTypeWSData
    frame[1] = idBytes.length;
    frame.setAll(2, idBytes);
    frame[2 + idBytes.length] = 0x01; // ExtraByte = Text (0x01)
    frame.setAll(3 + idBytes.length, payload);

    _channel!.sink.add(frame);
  }

  void _sendJson(Map<String, dynamic> msg) {
    if (_channel == null || !_connected) return;
    _channel!.sink.add(json.encode(msg));
  }

  /// Re-activates all tracked terminals after a physical reconnection.
  void _recoverActiveTerminals() {
    final terminals = Map<String, _ActiveTerminalInfo>.from(_activeTerminals);
    _activeTerminals.clear();
    for (var entry in terminals.entries) {
      activateTerminal(entry.key,
          lastSeq: entry.value.lastSeq,
          cols: entry.value.cols,
          rows: entry.value.rows);
    }
  }
}

class _ActiveTerminalInfo {
  final int lastSeq;
  final int cols;
  final int rows;
  _ActiveTerminalInfo(this.lastSeq, this.cols, this.rows);
}
