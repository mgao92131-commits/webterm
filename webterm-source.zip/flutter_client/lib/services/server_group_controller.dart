import 'package:webterm_mobile/models/server_config.dart';
import 'package:webterm_mobile/services/server_session_monitor.dart';
import 'package:webterm_mobile/services/terminal_cache_scope.dart';

enum ServerGroupStatus {
  connected,
  connecting,
  disconnected,
}

abstract class ServerGroupListener {
  bool isActive(ServerGroupController controller);
  void onRenderSessions(ServerConfig server, List<dynamic> sessions);
  void onSessionClosed(String baseUrl, String sessionId);
  void onScheduleFallbackRefresh();
}

class ServerGroupController {
  ServerConfig server;
  final ServerGroupListener listener;

  ServerSessionMonitor? _monitor;
  List<dynamic> _lastSessions = [];
  
  void Function(ServerGroupStatus)? onStatusChanged;

  void updateServer(ServerConfig newServer) {
    server = newServer;
    _monitor?.updateServer(newServer);
  }

  ServerGroupController({
    required this.server,
    required this.listener,
  });

  void start() {
    if (server.url.isEmpty) {
      stop();
      return;
    }
    if (!listener.isActive(this)) return;
    if (_monitor == null) {
      final m = ServerSessionMonitor(server);
      _monitor = m;

      m.onConnected.listen((connected) {
        listener.onScheduleFallbackRefresh();
        if (listener.isActive(this)) {
          _updateStatus(connected ? ServerGroupStatus.connected : ServerGroupStatus.connecting);
        }
      });

      m.onSessions.listen((sessions) {
        if (!listener.isActive(this)) return;
        _lastSessions = _filterSessionsForCurrentServer(sessions);
        listener.onRenderSessions(server, _lastSessions);
      });

      m.onSession.listen((session) {
        if (belongsToCurrentServer(session)) {
          _upsertLocalSession(session);
        }
      });

      m.onSessionClosed.listen((sessionId) {
        if (listener.isActive(this) && _belongsToCurrentServerId(sessionId)) {
          _removeLocalSession(sessionId);
        }
      });

      m.onPollingFallback.listen((_) {
        if (listener.isActive(this)) {
          _updateStatus(ServerGroupStatus.connecting);
        }
        listener.onScheduleFallbackRefresh();
      });

      m.onError.listen((_) {});
    }
    _monitor!.start();
  }

  void stop() {
    if (_monitor != null) {
      _monitor!.stop();
      _monitor!.dispose();
      _monitor = null;
    }
  }

  bool isConnected() {
    return _monitor != null && _monitor!.isConnected();
  }

  ServerSessionMonitor? get monitor => _monitor;

  List<dynamic> get lastSessions => _lastSessions;

  set lastSessions(List<dynamic> sessions) {
    _lastSessions = _filterSessionsForCurrentServer(sessions);
  }

  List<dynamic> _filterSessionsForCurrentServer(List<dynamic> sessions) {
    final filtered = [];
    for (var session in sessions) {
      if (belongsToCurrentServer(session)) {
        filtered.add(session);
      }
    }
    return filtered;
  }

  bool belongsToCurrentServer(dynamic session) {
    if (session is! Map<String, dynamic>) return false;
    final id = session['id']?.toString() ?? '';
    return _belongsToCurrentServerId(id);
  }

  bool _belongsToCurrentServerId(String sessionId) {
    return TerminalCacheScope.matches(server, server.url, sessionId);
  }

  void _upsertLocalSession(Map<String, dynamic> newData) {
    final id = newData['id']?.toString() ?? '';
    if (id.isEmpty) return;

    var index = _lastSessions.indexWhere((s) => s is Map && s['id'] == id);
    if (index != -1) {
      _lastSessions[index] = newData;
    } else {
      _lastSessions.add(newData);
    }

    listener.onRenderSessions(server, _lastSessions);
  }

  void _removeLocalSession(String id) {
    listener.onSessionClosed(server.url, id);
    _lastSessions.removeWhere((s) => s is Map && s['id'] == id);
    listener.onRenderSessions(server, _lastSessions);
  }

  void _updateStatus(ServerGroupStatus status) {
    if (onStatusChanged != null) {
      onStatusChanged!(status);
    }
  }
}
