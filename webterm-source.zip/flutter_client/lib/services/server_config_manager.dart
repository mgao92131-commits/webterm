import 'package:webterm_mobile/core/storage/server_config_store.dart';
import 'package:webterm_mobile/models/server_config.dart';

class ServerConfigManager {
  final ServerConfigStore store;
  final List<ServerConfig> _servers = [];

  ServerConfigManager(this.store);

  void load() {
    _servers.clear();
    _servers.addAll(store.loadServers());
  }

  void save() {
    store.saveServers(_servers);
  }

  List<ServerConfig> get servers => _servers;

  void addOrUpdate(
    ServerConfig? existingServer,
    String name,
    String url,
    String cookie,
    String username,
    String password, {
    bool? relayMaster,
    bool? relayDevice,
    String? deviceId,
  }) {
    if (existingServer == null) {
      _servers.add(ServerConfig(
        id: 'srv_${DateTime.now().millisecondsSinceEpoch}',
        name: name,
        url: url,
        cookie: cookie,
        username: username,
        password: password,
        relayMaster: relayMaster ?? false,
        relayDevice: relayDevice ?? false,
        deviceId: deviceId ?? '',
      ));
      return;
    }

    final index = _servers.indexWhere((s) => s.id == existingServer.id);
    if (index != -1) {
      _servers[index] = _servers[index].copyWith(
        name: name,
        url: url,
        cookie: cookie,
        username: username,
        password: password,
        relayMaster: relayMaster,
        relayDevice: relayDevice,
        deviceId: deviceId,
      );
    }
  }

  void remove(ServerConfig server) {
    _servers.removeWhere((s) => s.id == server.id);
  }

  void updateServer(ServerConfig server) {
    final index = _servers.indexWhere((s) => s.id == server.id);
    if (index != -1) {
      _servers[index] = server;
    }
  }
}
