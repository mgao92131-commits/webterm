import 'package:webterm_mobile/core/network/webterm_api.dart';
import 'package:webterm_mobile/models/server_config.dart';

abstract class SessionCommandListener {
  void onAuthenticated(ServerConfig server);
  void onOpenTerminal(
    String baseUrl,
    String cookie,
    String sessionId,
    String termTitle,
    String sessionName,
  );
  void onRemoveCachedTerminal(String baseUrl, String sessionId);
  void onSessionClosed(ServerConfig server, String sessionId);
  void onShowHome();
  void showMessage(String message);
}

class SessionCommandController {
  final WebTermApi api;
  final SessionCommandListener listener;

  SessionCommandController({
    required this.api,
    required this.listener,
  });

  Future<void> createSessionOnServer(ServerConfig server) async {
    try {
      final sessionId = await api.createSession(server);
      listener.onOpenTerminal(server.url, server.cookie, sessionId, 'Terminal', '');
    } catch (e) {
      final message = e.toString();
      if (message.contains('401')) {
        if (server.cookie.isNotEmpty) {
          try {
            final newCookie = await api.refresh(server.url, server.cookie);
            final updatedServer = server.copyWith(cookie: newCookie);
            listener.onAuthenticated(updatedServer);
            await createSessionOnServer(updatedServer);
          } catch (_) {
            await _silentLoginAndCreate(server);
          }
          return;
        } else if (server.password.isNotEmpty) {
          await _silentLoginAndCreate(server);
          return;
        }
      }
      listener.showMessage('创建会话失败: $message');
    }
  }

  Future<void> renameSession(ServerConfig server, String sessionId, String newName) async {
    try {
      await api.renameSession(server, sessionId, newName);
      listener.onShowHome();
    } catch (e) {
      final message = e.toString();
      if (message.contains('401') && server.password.isNotEmpty) {
        try {
          final result = await api.login(server.url, server.cookie, server.username, server.password);
          if (result.success && result.cookie != null) {
            final updatedServer = server.copyWith(cookie: result.cookie);
            listener.onAuthenticated(updatedServer);
            await renameSession(updatedServer, sessionId, newName);
            return;
          }
        } catch (_) {}
      }
      listener.showMessage(message);
    }
  }

  Future<void> deleteSession(ServerConfig server, String sessionId) async {
    try {
      listener.onRemoveCachedTerminal(server.url, sessionId);
      await api.deleteSession(server, sessionId);
      listener.onSessionClosed(server, sessionId);
      listener.onShowHome();
    } catch (e) {
      final message = e.toString();
      if (message.contains('401') && server.password.isNotEmpty) {
        try {
          final result = await api.login(server.url, server.cookie, server.username, server.password);
          if (result.success && result.cookie != null) {
            final updatedServer = server.copyWith(cookie: result.cookie);
            listener.onAuthenticated(updatedServer);
            await deleteSession(updatedServer, sessionId);
            return;
          }
        } catch (_) {}
      }
      listener.showMessage(message);
    }
  }

  Future<void> _silentLoginAndCreate(ServerConfig server) async {
    if (server.password.isEmpty) {
      listener.showMessage('静默登录失败，无法创建会话: 密码为空');
      return;
    }
    try {
      final result = await api.login(server.url, server.cookie, server.username, server.password);
      if (result.success && result.cookie != null) {
        final updatedServer = server.copyWith(cookie: result.cookie);
        listener.onAuthenticated(updatedServer);
        await createSessionOnServer(updatedServer);
      } else {
        listener.showMessage('静默登录失败，无法创建会话: ${result.error}');
      }
    } catch (e) {
      listener.showMessage('静默登录失败，无法创建会话: $e');
    }
  }
}
