import 'package:webterm_mobile/core/network/webterm_urls.dart';
import 'package:webterm_mobile/core/storage/terminal_disk_cache.dart';
import 'package:webterm_mobile/models/cached_terminal.dart';
import 'package:webterm_mobile/models/server_config.dart';
import 'package:webterm_mobile/models/session_identity.dart';
import 'package:webterm_mobile/services/terminal_cache_scope.dart';

class TerminalCacheSnapshot {
  String baseUrl;
  String cookie;
  String sessionId;
  String instanceId;
  String termTitle;
  String sessionName;
  String createdAt;
  dynamic terminalSession;
  int lastSeq;
  int columns;
  int rows;
  DiskCacheMetadata? diskMetadata;

  TerminalCacheSnapshot({
    this.baseUrl = '',
    this.cookie = '',
    this.sessionId = '',
    this.instanceId = '',
    this.termTitle = '',
    this.sessionName = '',
    this.createdAt = '',
    this.terminalSession,
    this.lastSeq = 0,
    this.columns = 0,
    this.rows = 0,
    this.diskMetadata,
  });
}

class TerminalCacheCoordinator {
  final TerminalDiskCache diskCache;
  final Map<String, CachedTerminal> memoryCache = {};

  TerminalCacheCoordinator(this.diskCache);

  Future<List<DiskCacheMetadata>> getCachedSessionsForServer(ServerConfig server) {
    return diskCache.getCachedSessionsForServer(server);
  }

  Map<String, CachedTerminal> getMemorySessionsForServer(ServerConfig server) {
    final result = <String, CachedTerminal>{};
    for (var cached in memoryCache.values) {
      if (TerminalCacheScope.matches(server, cached.baseUrl, cached.sessionId)) {
        result[cached.sessionId] = cached;
      }
    }
    return result;
  }

  CachedTerminal? getMemory(String baseUrl, String sessionId, String instanceId, String createdAt) {
    final key = SessionIdentity.cacheKey(baseUrl, sessionId, instanceId, createdAt);
    return key.isEmpty ? null : memoryCache[key];
  }

  Future<RestoreResult?> restore(String baseUrl, String sessionId, String instanceId, String createdAt) {
    return diskCache.restore(baseUrl, sessionId, instanceId, createdAt);
  }

  Future<void> saveCurrent(TerminalCacheSnapshot snapshot) async {
    if (snapshot.baseUrl.isEmpty || snapshot.sessionId.isEmpty || snapshot.terminalSession == null) return;
    
    final key = SessionIdentity.cacheKey(snapshot.baseUrl, snapshot.sessionId, snapshot.instanceId, snapshot.createdAt);
    if (key.isEmpty) return;

    var cached = memoryCache[key];
    if (cached == null) {
      cached = CachedTerminal(
        baseUrl: snapshot.baseUrl,
        cookie: snapshot.cookie,
        sessionId: snapshot.sessionId,
        instanceId: snapshot.instanceId,
        termTitle: snapshot.termTitle,
        sessionName: snapshot.sessionName,
        createdAt: snapshot.createdAt,
        terminalSession: snapshot.terminalSession,
      );
      memoryCache[key] = cached;
    }

    cached.cookie = snapshot.cookie;
    cached.instanceId = snapshot.instanceId;
    cached.termTitle = snapshot.termTitle;
    cached.sessionName = snapshot.sessionName;
    cached.createdAt = snapshot.createdAt;
    cached.terminalSession = snapshot.terminalSession;
    cached.lastSeq = snapshot.lastSeq;
    cached.columns = snapshot.columns;
    cached.rows = snapshot.rows;

    final metadata = snapshot.diskMetadata;
    if (metadata != null) {
      await diskCache.saveMetadata(metadata);
    }
  }

  bool removeTerminal(
    String baseUrl,
    String sessionId,
    String currentBaseUrl,
    String currentSessionId,
    dynamic currentSession,
  ) {
    final removedCurrent = sameServerSession(baseUrl, sessionId, currentBaseUrl, currentSessionId);
    final keys = <String>[];
    final normalizedBaseUrl = WebTermUrls.normalizeBaseUrl(baseUrl);
    
    for (var entry in memoryCache.entries) {
      final cached = entry.value;
      if (normalizedBaseUrl == WebTermUrls.normalizeBaseUrl(cached.baseUrl) && sessionId == cached.sessionId) {
        keys.add(entry.key);
      }
    }
    
    _removeMemoryEntries(keys, currentSession);
    diskCache.clearAsync(baseUrl, sessionId);
    return removedCurrent;
  }

  Future<void> removeMissingForServer(
    ServerConfig server,
    Set<String> liveSessionIdentities,
    dynamic currentSession,
  ) async {
    final staleKeys = <String>[];
    for (var entry in memoryCache.entries) {
      final cached = entry.value;
      if (TerminalCacheScope.matches(server, cached.baseUrl, cached.sessionId) &&
          !liveSessionIdentities.contains(SessionIdentity.value(cached.sessionId, cached.instanceId, cached.createdAt))) {
        staleKeys.add(entry.key);
      }
    }

    for (var key in staleKeys) {
      final cached = memoryCache.remove(key);
      _finishIfInactive(cached, currentSession);
      if (cached != null) {
        await diskCache.clearAsync(cached.baseUrl, cached.sessionId);
      }
    }
    await diskCache.clearMissingForServerAsync(server, liveSessionIdentities);
  }

  Future<void> removeServer(ServerConfig server, dynamic currentSession) async {
    final keys = <String>[];
    for (var entry in memoryCache.entries) {
      final cached = entry.value;
      if (TerminalCacheScope.matches(server, cached.baseUrl, cached.sessionId)) {
        keys.add(entry.key);
      }
    }
    _removeMemoryEntries(keys, currentSession);
    await diskCache.clearServerAsync(server);
  }

  void shutdown(dynamic currentSession) {
    for (var cached in memoryCache.values) {
      _finishIfInactive(cached, currentSession);
    }
    memoryCache.clear();
    diskCache.shutdown();
  }

  void _removeMemoryEntries(List<String> keys, dynamic currentSession) {
    for (var key in keys) {
      final cached = memoryCache.remove(key);
      _finishIfInactive(cached, currentSession);
    }
  }

  void _finishIfInactive(CachedTerminal? cached, dynamic currentSession) {
    if (cached != null && cached.terminalSession != null && cached.terminalSession != currentSession) {
      try {
        cached.terminalSession.disconnect();
      } catch (_) {
        try {
          cached.terminalSession.close();
        } catch (_) {}
      }
    }
  }

  static bool sameServerSession(String baseUrlA, String sessionIdA, String baseUrlB, String sessionIdB) {
    return WebTermUrls.normalizeBaseUrl(baseUrlA) == WebTermUrls.normalizeBaseUrl(baseUrlB) &&
        sessionIdA == sessionIdB;
  }
}
