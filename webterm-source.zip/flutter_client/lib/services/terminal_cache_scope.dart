import 'package:webterm_mobile/core/network/webterm_urls.dart';
import 'package:webterm_mobile/models/server_config.dart';

class TerminalCacheScope {
  TerminalCacheScope._();

  static String key(ServerConfig? server) {
    if (server == null) return '';
    final base = WebTermUrls.normalizeBaseUrl(server.url);
    if (isRelayDevice(server)) {
      return '$base#${server.deviceId}';
    }
    return base;
  }

  static bool matches(ServerConfig? server, String baseUrl, String sessionId) {
    if (server == null) return false;
    if (WebTermUrls.normalizeBaseUrl(server.url) != WebTermUrls.normalizeBaseUrl(baseUrl)) {
      return false;
    }
    if (!isRelayDevice(server)) return true;
    return sessionId.startsWith(relaySessionPrefix(server));
  }

  static bool isRelayDevice(ServerConfig? server) {
    return server != null &&
        server.relayDevice &&
        server.deviceId.isNotEmpty;
  }

  static String relaySessionPrefix(ServerConfig? server) {
    return isRelayDevice(server) ? '${server!.deviceId}:' : '';
  }
}
