import 'package:webterm_mobile/core/network/webterm_api.dart';
import 'package:webterm_mobile/core/storage/terminal_disk_cache.dart';
import 'package:webterm_mobile/models/server_config.dart';
import 'package:webterm_mobile/models/session_identity.dart';
import 'package:webterm_mobile/services/home_refresh_scheduler.dart';
import 'package:webterm_mobile/services/server_group_controller.dart';
import 'package:webterm_mobile/services/terminal_cache_coordinator.dart';
import 'package:webterm_mobile/services/terminal_cache_scope.dart';

abstract class SessionListAdapter {
  bool get hasSessionRows;
  void submitSessions(ServerConfig server, List<dynamic> sessions);
  void showError(ServerConfig server, String error);
}

abstract class HomeServerCoordinatorListener {
  bool isHomeActive();
  void onAuthenticated(ServerConfig server);
  void onRemoveCachedTerminal(String baseUrl, String sessionId);
  void onRemoveMissingCachedSessionsForServer(ServerConfig server, Set<String> liveSessionIdentities);
}

class CachedSessionMapper {
  static List<dynamic> toSessions(List<DiskCacheMetadata> metadataList) {
    return metadataList.map((meta) => {
      'id': meta.sessionId,
      'instanceId': meta.instanceId,
      'createdAt': meta.createdAt,
      'termTitle': meta.termTitle,
      'name': meta.sessionName,
      'cols': meta.columns,
      'rows': meta.rows,
      'lastSeq': meta.lastSeq,
    }).toList();
  }
}

class HomeServerCoordinator implements HomeRefreshSchedulerListener, ServerGroupListener {
  final WebTermApi api;
  final TerminalCacheCoordinator? terminalCache;
  final HomeServerCoordinatorListener listener;
  
  late final HomeRefreshScheduler refreshScheduler;
  @override
  final List<ServerGroupController> activeGroups = [];
  final Map<String, bool> directoryCollapsed = {};
  
  SessionListAdapter? sessionAdapter;

  HomeServerCoordinator({
    required this.api,
    required this.terminalCache,
    required this.listener,
  }) {
    refreshScheduler = HomeRefreshScheduler(this);
  }

  void attachSessionAdapter(SessionListAdapter adapter) {
    sessionAdapter = adapter;
  }

  void loadDeviceSessions(ServerConfig server, void Function(ServerGroupStatus) onStatus) {
    refreshScheduler.reset();
    if (sessionAdapter == null) return;
    
    final tempInMemorySessions = _collectInMemorySessions();
    _stopAllGroups();
    activeGroups.clear();

    final holder = ServerGroupController(
      server: server,
      listener: this,
    );
    holder.onStatusChanged = (status) {
      if (isActive(holder)) {
        onStatus(status);
      }
    };
    activeGroups.add(holder);
    
    _loadSessionsForAdapter(server, onStatus, tempInMemorySessions);
    _connectManagerWS(holder);
    refreshScheduler.scheduleInitial();
  }

  void resume() {
    for (var holder in activeGroups) {
      _connectManagerWS(holder);
    }
    refreshScheduler.reset();
    refreshScheduler.scheduleInitial();
  }

  void pause() {
    refreshScheduler.cancel();
    _stopAllGroups();
  }

  void destroy() {
    pause();
    activeGroups.clear();
    sessionAdapter = null;
  }

  // HomeRefreshSchedulerListener Implementation
  @override
  bool get isHomeRefreshActive => listener.isHomeActive() && sessionAdapter != null;


  @override
  void loadSessionsForGroup(ServerGroupController group) {
    _loadSessionsForAdapter(group.server, group.onStatusChanged ?? (_) {}, null);
  }

  // ServerGroupListener Implementation
  @override
  bool isActive(ServerGroupController controller) {
    return listener.isHomeActive() && sessionAdapter != null && activeGroups.contains(controller);
  }

  @override
  void onRenderSessions(ServerConfig server, List<dynamic> sessions) {
    _hydrateCachedNames(server, sessions);
    _renderServerSessions(server, sessions);
  }

  @override
  void onSessionClosed(String baseUrl, String sessionId) {
    listener.onRemoveCachedTerminal(baseUrl, sessionId);
  }

  @override
  void onScheduleFallbackRefresh() {
    refreshScheduler.scheduleInitial();
  }

  Map<String, List<dynamic>> _collectInMemorySessions() {
    final temp = <String, List<dynamic>>{};
    for (var holder in activeGroups) {
      if (holder.lastSessions.isNotEmpty) {
        temp[TerminalCacheScope.key(holder.server)] = holder.lastSessions;
      }
    }
    return temp;
  }

  void _loadSessionsForAdapter(
    ServerConfig server,
    void Function(ServerGroupStatus) onStatus,
    Map<String, List<dynamic>>? tempInMemorySessions,
  ) {
    if (server.url.isEmpty || sessionAdapter == null) return;
    onStatus(ServerGroupStatus.connecting);

    final loadedFromMemory = _renderTemporarySessionsIntoAdapter(server, tempInMemorySessions);
    if (!loadedFromMemory && terminalCache != null) {
      _prepopulateCachedSessionsIntoAdapter(server);
    }

    if (server.cookie.isNotEmpty) {
      _fetchSessionsIntoAdapter(server, onStatus);
    } else if (server.password.isNotEmpty) {
      _silentLoginAndFetchIntoAdapter(server, onStatus);
    } else {
      onStatus(ServerGroupStatus.disconnected);
      sessionAdapter!.showError(server, '需要登录');
    }
  }

  bool _renderTemporarySessionsIntoAdapter(ServerConfig server, Map<String, List<dynamic>>? tempInMemorySessions) {
    if (tempInMemorySessions == null) return false;
    final sessions = tempInMemorySessions[TerminalCacheScope.key(server)];
    if (sessions == null) return false;
    _hydrateCachedNames(server, sessions);
    final holder = _findHolderForServer(server);
    if (holder != null) holder.lastSessions = sessions;
    _renderServerSessions(server, sessions);
    return true;
  }

  void _prepopulateCachedSessionsIntoAdapter(ServerConfig server) {
    if (terminalCache == null) return;
    terminalCache!.getCachedSessionsForServer(server).then((cached) {
      if (cached.isEmpty) return;
      if (sessionAdapter != null && !sessionAdapter!.hasSessionRows) {
        _renderServerSessions(server, CachedSessionMapper.toSessions(cached));
      }
    });
  }

  void _fetchSessionsIntoAdapter(ServerConfig server, void Function(ServerGroupStatus) onStatus) {
    api.fetchSessions(server).then((sessions) {
      onStatus(ServerGroupStatus.connected);
      final holder = _findHolderForServer(server);
      if (holder != null) holder.lastSessions = sessions;
      _hydrateCachedNames(server, sessions);
      _renderServerSessions(server, sessions);
    }).catchError((err) {
      var code = 0;
      if (err is Exception && err.toString().contains('401')) {
        code = 401;
      }
      if (code == 401) {
        if (server.cookie.isNotEmpty) {
          api.refresh(server.url, server.cookie).then((cookie) {
            final updatedServer = server.copyWith(cookie: cookie);
            listener.onAuthenticated(updatedServer);
            _findHolderForServer(server)?.updateServer(updatedServer);
            _fetchSessionsIntoAdapter(updatedServer, onStatus);
          }).catchError((_) {
            _silentLoginAndFetchIntoAdapter(server, onStatus);
          });
          return;
        } else if (server.password.isNotEmpty) {
          _silentLoginAndFetchIntoAdapter(server, onStatus);
          return;
        }
      }
      _showOfflineCachedSessionsIntoAdapter(server, onStatus, err.toString());
    });
  }

  void _silentLoginAndFetchIntoAdapter(ServerConfig server, void Function(ServerGroupStatus) onStatus) {
    if (server.password.isEmpty) {
      _showOfflineCachedSessionsIntoAdapter(server, onStatus, '登录失败: 密码为空');
      return;
    }
    api.login(server.url, server.cookie, server.username, server.password).then((result) {
      if (result.success && result.cookie != null) {
        final updatedServer = server.copyWith(cookie: result.cookie);
        listener.onAuthenticated(updatedServer);
        _findHolderForServer(server)?.updateServer(updatedServer);
        _fetchSessionsIntoAdapter(updatedServer, onStatus);
      } else {
        _showOfflineCachedSessionsIntoAdapter(server, onStatus, '登录失败: ${result.error}');
      }
    }).catchError((err) {
      _showOfflineCachedSessionsIntoAdapter(server, onStatus, '登录失败: $err');
    });
  }

  void _showOfflineCachedSessionsIntoAdapter(
    ServerConfig server,
    void Function(ServerGroupStatus) onStatus,
    String errorMsg,
  ) {
    if (terminalCache == null) {
      onStatus(ServerGroupStatus.disconnected);
      if (sessionAdapter != null) sessionAdapter!.showError(server, errorMsg);
      return;
    }
    
    terminalCache!.getCachedSessionsForServer(server).then((cachedMetadata) {
      onStatus(ServerGroupStatus.disconnected);
      if (sessionAdapter != null && sessionAdapter!.hasSessionRows) return;

      if (cachedMetadata.isNotEmpty) {
        _renderServerSessions(server, CachedSessionMapper.toSessions(cachedMetadata));
      } else if (sessionAdapter != null) {
        sessionAdapter!.showError(server, errorMsg);
      }
    });
  }

  void _hydrateCachedNames(ServerConfig server, List<dynamic> sessions) {
    if (terminalCache == null) return;
    
    final memoryCaches = terminalCache!.getMemorySessionsForServer(server);
    terminalCache!.getCachedSessionsForServer(server).then((diskCaches) {
      final diskMap = <String, DiskCacheMetadata>{};
      for (var meta in diskCaches) {
        diskMap[meta.sessionId] = meta;
      }

      for (var session in sessions) {
        if (session is Map<String, dynamic>) {
          final sessionId = session['id']?.toString() ?? '';
          String? sessionName;
          final memCached = memoryCaches[sessionId];
          if (memCached != null) {
            sessionName = memCached.sessionName;
          } else {
            final diskCached = diskMap[sessionId];
            if (diskCached != null) {
              sessionName = diskCached.sessionName;
            }
          }
          if (sessionName != null && (session['name']?.toString().trim().isEmpty ?? true)) {
            session['name'] = sessionName;
          }
        }
      }
    });
  }

  void _renderServerSessions(ServerConfig server, List<dynamic> sessions) {
    if (sessionAdapter == null) return;
    _cleanupMissingCachedSessions(server, sessions);
    sessionAdapter!.submitSessions(server, sessions);
  }

  void _cleanupMissingCachedSessions(ServerConfig server, List<dynamic> sessions) {
    final liveIdentities = <String>{};
    for (var session in sessions) {
      if (session is Map<String, dynamic>) {
        final identity = SessionIdentity.value(
          session['id']?.toString() ?? '',
          session['instanceId']?.toString() ?? '',
          session['createdAt']?.toString() ?? '',
        );
        if (identity.isNotEmpty) {
          liveIdentities.add(identity);
        }
      }
    }
    listener.onRemoveMissingCachedSessionsForServer(server, liveIdentities);
  }

  void _connectManagerWS(ServerGroupController holder) {
    if (!listener.isHomeActive() || sessionAdapter == null || holder.server.url.isEmpty) {
      _closeManagerWS(holder);
      return;
    }
    if (!activeGroups.contains(holder)) return;
    holder.start();
  }

  void _closeManagerWS(ServerGroupController holder) {
    holder.stop();
  }

  void _stopAllGroups() {
    for (var holder in activeGroups) {
      _closeManagerWS(holder);
    }
  }

  void updateServerInHolder(ServerConfig server) {
    _findHolderForServer(server)?.updateServer(server);
  }

  ServerGroupController? _findHolderForServer(ServerConfig server) {
    for (var holder in activeGroups) {
      if (holder.server.id == server.id) return holder;
    }
    return null;
  }
}
