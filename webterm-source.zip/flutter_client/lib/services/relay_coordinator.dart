import 'dart:async';
import 'dart:math' as math;
import 'package:webterm_mobile/core/network/webterm_api.dart';
import 'package:webterm_mobile/models/server_config.dart';
import 'package:webterm_mobile/services/server_config_manager.dart';
import 'package:webterm_mobile/services/server_session_monitor.dart';

enum RelayState {
  notConfigured,
  connecting,
  authFailed,
  connectFailed,
  connectedFetchingDevices,
  connectedNoDevices,
  connectedWithDevices,
  connectedPolling,
}

abstract class RelayCoordinatorHost {
  void onRelayDevicesChanged();
  void onRelayAuthDone();
  void saveServers();
  ServerConfigManager get serverConfigs;
}

class RelayCoordinator {
  static const int maxHttpAuthRetries = 2;
  static const Duration httpPollInterval = Duration(milliseconds: 3000);
  static const Duration httpRetryInterval = Duration(milliseconds: 5000);

  final WebTermApi api;
  final RelayCoordinatorHost host;

  ServerConfig? _relayMasterConfig;
  ServerSessionMonitor? _relayMonitor;
  final List<ServerConfig> _relayDevices = [];
  RelayState relayState = RelayState.notConfigured;
  int _httpAuthFailures = 0;
  Timer? _pollTimer;

  // Listeners for UI state binding
  void Function(RelayState)? onStateChanged;

  RelayCoordinator({
    required this.api,
    required this.host,
  });

  ServerConfig? get masterConfig => _relayMasterConfig;
  List<ServerConfig> get devices => _relayDevices;
  bool get hasMaster => _relayMasterConfig != null && _relayMasterConfig!.url.isNotEmpty;

  void loadMasterFromServers(List<ServerConfig> servers) {
    _relayMasterConfig = null;
    for (var s in servers) {
      if (s.relayMaster) {
        _relayMasterConfig = s;
        break;
      }
    }
  }

  void start() {
    if (!hasMaster) {
      stop();
      _updateState(RelayState.notConfigured);
      return;
    }
    if (_relayMonitor != null && _relayMonitor!.isEnabled()) {
      return;
    }
    stop();
    _updateState(RelayState.connecting);

    final monitor = ServerSessionMonitor(_relayMasterConfig!);
    _relayMonitor = monitor;

    monitor.onConnected.listen((connected) {
      if (connected) {
        _pollTimer?.cancel();
        _updateState(RelayState.connectedFetchingDevices);
      }
    });

    monitor.onPollingFallback.listen((_) {
      _updateState(RelayState.connecting);
      _pollTimer?.cancel();
      _fetchDevicesHttp();
    });

    monitor.onDevices.listen((devicesJson) {
      _relayDevices.clear();
      for (var deviceObj in devicesJson) {
        if (deviceObj is Map<String, dynamic>) {
          final deviceId = deviceObj['deviceId']?.toString() ?? '';
          final deviceName = deviceObj['deviceName']?.toString() ?? '';
          if (deviceId.isEmpty) continue;
          if (!_isDeviceOnline(deviceObj)) continue;

          _relayDevices.add(ServerConfig(
            id: 'relay_dev_$deviceId',
            name: deviceName,
            url: _relayMasterConfig!.url,
            cookie: _relayMasterConfig!.cookie,
            username: _relayMasterConfig!.username,
            password: _relayMasterConfig!.password,
            relayMaster: false,
            relayDevice: true,
            deviceId: deviceId,
          ));
        }
      }

      _updateState(_relayDevices.isEmpty
          ? RelayState.connectedNoDevices
          : RelayState.connectedWithDevices);
      _httpAuthFailures = 0;
      host.onRelayDevicesChanged();
    });

    monitor.onError.listen((errorMsg) {
      if (errorMsg.contains('401')) {
        _handleAuthError();
      } else {
        _updateState(RelayState.connectFailed);
      }
    });

    monitor.start();
  }

  void _handleAuthError() {
    if (_relayMasterConfig != null && _relayMasterConfig!.cookie.isNotEmpty) {
      _updateState(RelayState.connecting);
      api.refresh(_relayMasterConfig!.url, _relayMasterConfig!.cookie).then((cookie) {
        _relayMasterConfig = _relayMasterConfig!.copyWith(cookie: cookie);
        
        // Sync back to ServerConfigManager list
        final index = host.serverConfigs.servers.indexWhere((s) => s.id == _relayMasterConfig!.id);
        if (index != -1) {
          host.serverConfigs.servers[index] = _relayMasterConfig!;
        }

        host.saveServers();
        resetReconnectAndStart();
      }).catchError((_) {
        _performPasswordLogin();
      });
    } else {
      _performPasswordLogin();
    }
  }

  void _performPasswordLogin() {
    if (_relayMasterConfig != null &&
        _relayMasterConfig!.username.isNotEmpty &&
        _relayMasterConfig!.password.isNotEmpty) {
      _updateState(RelayState.connecting);
      api.login(
        _relayMasterConfig!.url,
        _relayMasterConfig!.cookie,
        _relayMasterConfig!.username,
        _relayMasterConfig!.password,
      ).then((result) {
        if (result.success && result.cookie != null) {
          _relayMasterConfig = _relayMasterConfig!.copyWith(cookie: result.cookie);
          
          final index = host.serverConfigs.servers.indexWhere((s) => s.id == _relayMasterConfig!.id);
          if (index != -1) {
            host.serverConfigs.servers[index] = _relayMasterConfig!;
          }

          host.saveServers();
          resetReconnectAndStart();
        } else {
          _updateState(RelayState.authFailed);
        }
      }).catchError((_) {
        _updateState(RelayState.authFailed);
      });
    } else {
      _updateState(RelayState.authFailed);
    }
  }

  void stop() {
    _pollTimer?.cancel();
    _httpAuthFailures = 0;
    if (_relayMonitor != null) {
      _relayMonitor!.stop();
      _relayMonitor!.dispose();
      _relayMonitor = null;
    }
  }

  void resetReconnectAndStart() {
    stop();
    start();
  }

  void _fetchDevicesHttp() {
    if (_relayMasterConfig == null) return;
    api.fetchDevices(_relayMasterConfig!.url, _relayMasterConfig!.cookie).then((devicesJson) {
      if (relayState != RelayState.connecting &&
          relayState != RelayState.connectFailed &&
          relayState != RelayState.connectedPolling) {
        return;
      }
      _httpAuthFailures = 0;
      _relayDevices.clear();
      for (var deviceObj in devicesJson) {
        if (deviceObj is Map<String, dynamic>) {
          final deviceId = deviceObj['deviceId']?.toString() ?? '';
          final deviceName = deviceObj['deviceName']?.toString() ?? '';
          if (deviceId.isEmpty) continue;
          if (!_isDeviceOnline(deviceObj)) continue;

          _relayDevices.add(ServerConfig(
            id: 'relay_dev_$deviceId',
            name: deviceName,
            url: _relayMasterConfig!.url,
            cookie: _relayMasterConfig!.cookie,
            username: _relayMasterConfig!.username,
            password: _relayMasterConfig!.password,
            relayMaster: false,
            relayDevice: true,
            deviceId: deviceId,
          ));
        }
      }

      _updateState(RelayState.connectedPolling);
      host.onRelayDevicesChanged();
      _scheduleHttpPoll(httpPollInterval);
    }).catchError((err) {
      // Handle DioException or generic exceptions
      var code = 0;
      if (err is Exception && err.toString().contains('401')) {
        code = 401;
      }
      if (code == 401) {
        _httpAuthFailures++;
        if (_httpAuthFailures > maxHttpAuthRetries) {
          _pollTimer?.cancel();
          _updateState(RelayState.authFailed);
          return;
        }
        _performSilentLoginOrPasswordLoginForHttp();
      } else {
        _updateState(RelayState.connectFailed);
        _scheduleHttpPoll(httpRetryInterval);
      }
    });
  }

  void _performSilentLoginOrPasswordLoginForHttp() {
    if (_relayMasterConfig != null && _relayMasterConfig!.cookie.isNotEmpty) {
      api.refresh(_relayMasterConfig!.url, _relayMasterConfig!.cookie).then((cookie) {
        _relayMasterConfig = _relayMasterConfig!.copyWith(cookie: cookie);
        
        final index = host.serverConfigs.servers.indexWhere((s) => s.id == _relayMasterConfig!.id);
        if (index != -1) {
          host.serverConfigs.servers[index] = _relayMasterConfig!;
        }

        host.saveServers();
        _scheduleHttpPoll(_authRetryDelay());
      }).catchError((_) {
        _performPasswordLoginForHttp();
      });
    } else {
      _performPasswordLoginForHttp();
    }
  }

  void _performPasswordLoginForHttp() {
    if (_relayMasterConfig != null &&
        _relayMasterConfig!.username.isNotEmpty &&
        _relayMasterConfig!.password.isNotEmpty) {
      api.login(
        _relayMasterConfig!.url,
        _relayMasterConfig!.cookie,
        _relayMasterConfig!.username,
        _relayMasterConfig!.password,
      ).then((result) {
        if (result.success && result.cookie != null) {
          _relayMasterConfig = _relayMasterConfig!.copyWith(cookie: result.cookie);
          
          final index = host.serverConfigs.servers.indexWhere((s) => s.id == _relayMasterConfig!.id);
          if (index != -1) {
            host.serverConfigs.servers[index] = _relayMasterConfig!;
          }

          host.saveServers();
          _scheduleHttpPoll(_authRetryDelay());
        } else {
          _updateState(RelayState.authFailed);
        }
      }).catchError((_) {
        _updateState(RelayState.authFailed);
      });
    } else {
      _updateState(RelayState.authFailed);
    }
  }

  void onRelayAuthenticated(String url, String cookie, String username, String password) {
    ServerConfig? existingMaster;
    for (var s in host.serverConfigs.servers) {
      if (s.relayMaster) {
        existingMaster = s;
        break;
      }
    }
    if (existingMaster == null) {
      existingMaster = ServerConfig(
        id: 'relay_mst_${DateTime.now().millisecondsSinceEpoch}',
        name: '中转服务器',
        url: url,
        cookie: cookie,
        username: username,
        password: password,
        relayMaster: true,
        relayDevice: false,
        deviceId: '',
      );
      host.serverConfigs.servers.add(existingMaster);
    } else {
      final index = host.serverConfigs.servers.indexOf(existingMaster);
      existingMaster = existingMaster.copyWith(
        url: url,
        cookie: cookie,
        username: username,
        password: password,
      );
      host.serverConfigs.servers[index] = existingMaster;
    }
    _relayMasterConfig = existingMaster;
    _httpAuthFailures = 0;
    host.saveServers();
    start();
    host.onRelayAuthDone();
  }

  void onDisconnectRelay() {
    host.serverConfigs.servers.removeWhere((s) => s.relayMaster);
    _relayMasterConfig = null;
    _httpAuthFailures = 0;
    host.saveServers();
    stop();
    _relayDevices.clear();
    _updateState(RelayState.notConfigured);
    host.onRelayAuthDone();
  }

  void _updateState(RelayState state) {
    relayState = state;
    if (onStateChanged != null) {
      onStateChanged!(state);
    }
  }

  bool _isDeviceOnline(Map<String, dynamic> deviceObj) {
    return deviceObj['online'] == true ||
        deviceObj['status']?.toString().toLowerCase() == 'online';
  }

  void _scheduleHttpPoll(Duration delay) {
    _pollTimer?.cancel();
    _pollTimer = Timer(delay, () {
      _fetchDevicesHttp();
    });
  }

  Duration _authRetryDelay() {
    return Duration(milliseconds: math.min(httpRetryInterval.inMilliseconds, 500 * _httpAuthFailures));
  }

  void loginRelay(
    String baseUrl,
    String username,
    String password,
    RelayConfigDialogHelperLoginCallback callback,
  ) {
    final oldCookie = _relayMasterConfig != null ? _relayMasterConfig!.cookie : '';
    api.login(baseUrl, oldCookie, username, password).then((result) {
      if (result.success && result.cookie != null) {
        callback.onReady(baseUrl, result.cookie!);
      } else if (result.otpRequired) {
        callback.onOtpRequired(result.targetDeviceId ?? '', result.cookie ?? '');
      } else {
        callback.onError(result.error ?? 'Unknown error');
      }
    }).catchError((err) {
      callback.onError(err.toString());
    });
  }

  void verifyOtp(
    String baseUrl,
    String username,
    String code,
    String targetDeviceId,
    String cookie,
    RelayConfigDialogHelperLoginCallback callback,
  ) {
    api.verifyOtp(baseUrl, username, code, targetDeviceId, cookie).then((result) {
      if (result.success && result.cookie != null) {
        callback.onReady(baseUrl, result.cookie!);
      } else {
        callback.onError(result.error ?? 'Unknown error');
      }
    }).catchError((err) {
      callback.onError(err.toString());
    });
  }

  void destroy() {
    stop();
    _relayDevices.clear();
    _relayMasterConfig = null;
  }
}

abstract class RelayConfigDialogHelperLoginCallback {
  void onReady(String url, String cookie);
  void onOtpRequired(String targetDeviceId, String cookie);
  void onError(String message);
}

