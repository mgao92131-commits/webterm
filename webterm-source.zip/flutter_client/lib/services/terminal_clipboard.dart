import 'package:flutter/services.dart';

abstract class ClipboardControlKeyHost {
  bool readTerminalControlKey();
  void clearTerminalControlKey();
}

class TerminalClipboardController {
  final ClipboardControlKeyHost controlKeyHost;

  TerminalClipboardController({required this.controlKeyHost});

  Future<void> copy(String text) async {
    await Clipboard.setData(ClipboardData(text: text));
  }

  Future<void> paste(void Function(String) writeCallback) async {
    final data = await Clipboard.getData(Clipboard.kTextPlain);
    final text = data?.text;
    if (text != null && text.isNotEmpty) {
      var textStr = text;
      if (controlKeyHost.readTerminalControlKey()) {
        textStr = '\x1b[200~$textStr\x1b[201~';
        controlKeyHost.clearTerminalControlKey();
      }
      writeCallback(textStr);
    }
  }
}
