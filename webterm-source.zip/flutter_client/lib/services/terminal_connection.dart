import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';
import 'package:web_socket_channel/io.dart';
import 'package:webterm_mobile/core/network/webterm_protocol.dart';
import 'package:webterm_mobile/core/network/webterm_urls.dart';
import 'package:webterm_mobile/services/server_session_monitor.dart';

enum TerminalConnectionState {
  disconnected,
  connecting,
  connected,
  reconnecting,
}

class ConnectionStatusUpdate {
  final TerminalConnectionState state;
  final int reconnectAttempts;
  const ConnectionStatusUpdate(this.state, this.reconnectAttempts);
}

class TerminalOutputEvent {
  final int seq;
  final Uint8List data;
  const TerminalOutputEvent(this.seq, this.data);
}

class TerminalStateEvent {
  final int seq;
  final Uint8List data;
  const TerminalStateEvent(this.seq, this.data);
}

class TerminalConnection {
  static const String screenSubprotocol = 'webterm.screen.v1';
  static const String binarySubprotocol = 'webterm.binary.v1';

  final String? baseUrl;
  final String? cookie;
  final String? sessionId;

  // ── Multiplexed mode ──
  ServerSessionMonitor? _monitor;
  StreamSubscription? _tunnelSubscription;

  TerminalConnectionState state = TerminalConnectionState.disconnected;
  int socketGeneration = 0;
  int reconnectAttempts = 0;

  int lastSeq = 0;
  int columns = 0;
  int rows = 0;
  int sentColumns = 0;
  int sentRows = 0;
  bool isScreenMode = true; // 默认使用新重构的 Cell/Span 状态同步协议

  IOWebSocketChannel? _channel;
  Timer? _reconnectTimer;
  Timer? _resizeTimer;

  // Stream Controllers
  final _onConnectionStatusController = StreamController<ConnectionStatusUpdate>.broadcast();
  final _onOutputController = StreamController<TerminalOutputEvent>.broadcast();
  final _onStateController = StreamController<TerminalStateEvent>.broadcast();
  final _onInfoController = StreamController<Map<String, dynamic>>.broadcast();
  final _onExitController = StreamController<int>.broadcast();
  final _onProtocolErrorController = StreamController<String>.broadcast();
  final _onScreenStateController = StreamController<Map<String, dynamic>>.broadcast();
  final _onScreenDeltaController = StreamController<Map<String, dynamic>>.broadcast();

  // Streams
  Stream<ConnectionStatusUpdate> get onConnectionStatus => _onConnectionStatusController.stream;
  Stream<TerminalOutputEvent> get onOutput => _onOutputController.stream;
  Stream<TerminalStateEvent> get onState => _onStateController.stream;
  Stream<Map<String, dynamic>> get onInfo => _onInfoController.stream;
  Stream<int> get onExit => _onExitController.stream;
  Stream<String> get onProtocolError => _onProtocolErrorController.stream;
  Stream<Map<String, dynamic>> get onScreenState => _onScreenStateController.stream;
  Stream<Map<String, dynamic>> get onScreenDelta => _onScreenDeltaController.stream;

  TerminalConnection({
    required this.baseUrl,
    required this.cookie,
    required this.sessionId,
    this.lastSeq = 0,
    this.columns = 0,
    this.rows = 0,
  });

  /// Multiplexed mode — terminal data flows through [monitor]'s tunnel
  /// frames on the single /ws/sessions connection instead of a dedicated
  /// WebSocket.
  TerminalConnection.multiplexed({
    required this.sessionId,
    required ServerSessionMonitor monitor,
    this.lastSeq = 0,
    this.columns = 0,
    this.rows = 0,
  }) : baseUrl = null, cookie = null, _monitor = monitor;

  void connect() {
    _reconnectTimer?.cancel();
    state = TerminalConnectionState.connecting;
    reconnectAttempts = 0;
    _connectNow();
  }

  void reconnectNow() {
    _reconnectTimer?.cancel();
    state = TerminalConnectionState.connecting;
    reconnectAttempts = 0;
    _connectNow();
  }

  void close(String reason) {
    state = TerminalConnectionState.disconnected;
    socketGeneration++;
    _reconnectTimer?.cancel();
    _resizeTimer?.cancel();
    _tunnelSubscription?.cancel();

    if (_monitor != null) {
      _monitor!.deactivateTerminal(sessionId!);
    } else {
      _releaseSocket(reason);
    }
    _onConnectionStatusController.add(ConnectionStatusUpdate(state, reconnectAttempts));
  }

  bool isConnected() => state == TerminalConnectionState.connected;

  void updateLastSeq(int seq) {
    lastSeq = seq;
  }

  void updateSize(int newColumns, int newRows) {
    columns = newColumns;
    rows = newRows;
    _scheduleResize();
  }

  void sendInput(String data) {
    if (_monitor != null) {
      if (isScreenMode) {
        _monitor!.sendTerminalInputText(sessionId!, data);
      } else {
        _monitor!.sendTerminalInput(sessionId!, data);
      }
      return;
    }
    if (isScreenMode) {
      _sendText(json.encode({'type': 'input', 'data': data}));
      return;
    }
    _sendBinary(WebTermProtocol.msgInput, utf8.encode(data));
  }

  void sendTitle(String title) {
    _sendBinary(WebTermProtocol.msgTitle, utf8.encode(title));
  }

  Future<void> _connectNow() async {
    if (sessionId == null) return;

    // ── Multiplexed mode ──
    if (_monitor != null) {
      final gen = ++socketGeneration;
      state = TerminalConnectionState.connected;
      isScreenMode = true; // Multiplexed 优先使用 screen 模式
      reconnectAttempts = 0;
      sentColumns = 0;
      sentRows = 0;
      _onConnectionStatusController
          .add(ConnectionStatusUpdate(state, reconnectAttempts));

      _monitor!.activateTerminal(sessionId!,
          lastSeq: lastSeq, cols: columns, rows: rows);

      _tunnelSubscription = _monitor!.onTunnelFrame
          .where((f) => f['tunnelId'] == 'term:$sessionId')
          .listen((f) {
        if (gen != socketGeneration) return;
        _handleServerMessage(f['payload'] as Uint8List);
      });

      return;
    }

    // ── Standalone mode: dedicated WebSocket ──
    if (baseUrl == null || cookie == null) return;
    if (_channel != null) {
      _releaseSocket('reconnecting');
    }

    state = TerminalConnectionState.connecting;
    _onConnectionStatusController.add(ConnectionStatusUpdate(state, reconnectAttempts));
    
    final generation = ++socketGeneration;
    final encodedId = WebTermUrls.encodePath(sessionId!);
    final wsUrl = '${WebTermUrls.toWebSocketUrl(baseUrl!)}/ws/sessions/$encodedId';

    try {
      final ws = await WebSocket.connect(
        wsUrl,
        headers: {'Cookie': cookie!},
        protocols: [screenSubprotocol, binarySubprotocol],
      ).timeout(const Duration(seconds: 8));

      if (generation != socketGeneration) {
        ws.close();
        return;
      }

      _channel = IOWebSocketChannel(ws);
      state = TerminalConnectionState.connected;
      isScreenMode = ws.protocol == screenSubprotocol;
      reconnectAttempts = 0;
      sentColumns = 0;
      sentRows = 0;
      _onConnectionStatusController.add(ConnectionStatusUpdate(state, reconnectAttempts));

      // Build Hello Payload
      if (isScreenMode) {
        final hello = json.encode({
          'type': 'hello',
          'lastSeq': lastSeq,
          'cols': columns,
          'rows': rows,
        });
        _sendText(hello);
      } else {
        final hello = <String, dynamic>{'lastSeq': lastSeq};
        if (columns > 0 && rows > 0) {
          hello['cols'] = columns;
          hello['rows'] = rows;
          sentColumns = columns;
          sentRows = rows;
        }
        _sendBinary(WebTermProtocol.msgHello, utf8.encode(json.encode(hello)));
      }
      _sendResizeNow();

      _channel!.stream.listen(
        (data) {
          if (generation != socketGeneration) return;
          if (data is String) {
            _handleTextMessage(data);
          } else if (data is List<int>) {
            _handleServerMessage(Uint8List.fromList(data));
          }
        },
        onError: (err) {
          if (generation != socketGeneration) return;
          _releaseSocket('error');
          _scheduleReconnect(err.toString());
        },
        onDone: () {
          if (generation != socketGeneration) return;
          _releaseSocket('closed');
          _scheduleReconnect('socket closed');
        },
      );
    } catch (e) {
      if (generation == socketGeneration) {
        _releaseSocket('failed');
        _scheduleReconnect(e.toString());
      }
    }
  }

  void _scheduleReconnect(String reason) {
    // Multiplexed mode: reconnection is handled by ServerSessionMonitor.
    if (_monitor != null) return;

    if (state == TerminalConnectionState.disconnected || sessionId == null || cookie == null || baseUrl == null) return;
    if (state == TerminalConnectionState.reconnecting) return;

    state = TerminalConnectionState.reconnecting;
    _onConnectionStatusController.add(ConnectionStatusUpdate(state, reconnectAttempts));

    reconnectAttempts++;
    final shift = math.min(reconnectAttempts - 1, 15);
    final cap = math.min(15000, 1000 * (1 << shift));
    final delayMs = math.max(200, (math.Random().nextDouble() * cap).toInt());

    _reconnectTimer?.cancel();
    _reconnectTimer = Timer(Duration(milliseconds: delayMs), () {
      if (state == TerminalConnectionState.reconnecting) {
        _connectNow();
      }
    });
  }

  void _handleServerMessage(Uint8List frame) {
    if (frame.isEmpty) return;
    if (frame[0] == 123) { // '{'
      try {
        final text = utf8.decode(frame);
        _handleTextMessage(text);
      } catch (_) {}
      return;
    }
    final type = frame[0];
    final payload = frame.sublist(1);

    if (type == WebTermProtocol.msgOutput) {
      if (payload.length >= 8) {
        final seq = WebTermProtocol.readUint64(payload, 0);
        if (seq <= lastSeq) return;
        lastSeq = seq;
        _onOutputController.add(TerminalOutputEvent(seq, payload.sublist(8)));
      } else {
        _onOutputController.add(TerminalOutputEvent(0, payload));
      }
      return;
    }

    if (type == WebTermProtocol.msgState) {
      if (payload.length >= 8) {
        final seq = WebTermProtocol.readUint64(payload, 0);
        if (seq < lastSeq) return;
        lastSeq = seq;
        _onStateController.add(TerminalStateEvent(seq, payload.sublist(8)));
      }
      return;
    }

    if (type == WebTermProtocol.msgInfo) {
      try {
        final infoMap = WebTermProtocol.controlPayload(payload);
        _onInfoController.add(infoMap);
      } catch (_) {}
      return;
    }

    if (type == WebTermProtocol.msgExit) {
      int code = 0;
      if (payload.isNotEmpty) {
        try {
          final msg = WebTermProtocol.controlPayload(payload);
          code = (msg['code'] as int?) ?? 0;
        } catch (_) {}
      }
      _onExitController.add(code);
      return;
    }

    if (type == WebTermProtocol.msgPong) {
      return;
    }

    // Unknown message type
    try {
      final msg = WebTermProtocol.controlPayload(payload);
      _onProtocolErrorController.add('Unknown message type: 0x${type.toRadixString(16)} payload=$msg');
    } catch (e) {
      _onProtocolErrorController.add('Unknown message type: 0x${type.toRadixString(16)} ($e)');
    }
  }

  void _scheduleResize() {
    if (columns <= 0 || rows <= 0 || state != TerminalConnectionState.connected) return;
    _resizeTimer?.cancel();
    _resizeTimer = Timer(const Duration(milliseconds: 100), () {
      _sendResizeNow();
    });
  }

  void _sendResizeNow() {
    _resizeTimer?.cancel();
    if (columns <= 0 || rows <= 0) return;
    if (columns == sentColumns && rows == sentRows) return;

    if (_monitor != null) {
      if (isScreenMode) {
        _monitor!.sendTerminalResizeText(sessionId!, columns, rows);
      } else {
        _monitor!.sendTerminalResize(sessionId!, columns, rows);
      }
      sentColumns = columns;
      sentRows = rows;
      return;
    }

    if (state != TerminalConnectionState.connected) return;

    if (isScreenMode) {
      _sendText(json.encode({'type': 'resize', 'cols': columns, 'rows': rows}));
    } else {
      final payload = json.encode({'cols': columns, 'rows': rows});
      _sendBinary(WebTermProtocol.msgResize, utf8.encode(payload));
    }
    sentColumns = columns;
    sentRows = rows;
  }

  void _sendBinary(int type, List<int> payload) {
    if (_channel == null || state != TerminalConnectionState.connected) return;
    _channel!.sink.add(WebTermProtocol.frame(type, Uint8List.fromList(payload)));
  }

  void _sendText(String text) {
    if (_channel == null || state != TerminalConnectionState.connected) return;
    _channel!.sink.add(text);
  }

  void _handleTextMessage(String text) {
    try {
      final msg = json.decode(text);
      if (msg is Map<String, dynamic>) {
        final type = msg['type'] as String?;
        final seq = msg['seq'] as int?;
        if (seq != null) {
          lastSeq = seq;
        }
        if (type == 'screen-state') {
          _onScreenStateController.add(msg);
        } else if (type == 'screen-delta') {
          _onScreenDeltaController.add(msg);
        }
      }
    } catch (_) {}
  }

  void _releaseSocket(String reason) {
    if (_channel != null) {
      _channel!.sink.close(1000, reason);
      _channel = null;
    }
  }

  void dispose() {
    close('disposing');
    _onConnectionStatusController.close();
    _onOutputController.close();
    _onStateController.close();
    _onInfoController.close();
    _onExitController.close();
    _onProtocolErrorController.close();
    _onScreenStateController.close();
    _onScreenDeltaController.close();
  }
}
