import 'dart:async';
import 'terminal_connection.dart';

class TerminalTitleSynchronizer {
  static const int maxTermTitleChars = 256;

  final TerminalConnection Function() connectionProvider;
  Timer? _debounceTimer;
  String _lastUploadedTitle = '';
  String _pendingTitle = '';

  void Function(String)? onTitleUpdated;

  TerminalTitleSynchronizer({required this.connectionProvider});

  void onTitleChanged(String rawTitle) {
    final title = sanitize(rawTitle);
    if (title.isEmpty) return;

    _pendingTitle = title;
    if (onTitleUpdated != null) {
      onTitleUpdated!(title);
    }

    _debounceTimer?.cancel();
    _debounceTimer = Timer(const Duration(milliseconds: 300), _uploadTitle);
  }

  void cancel() {
    _debounceTimer?.cancel();
  }

  void reset() {
    cancel();
    _lastUploadedTitle = '';
    _pendingTitle = '';
  }

  void _uploadTitle() {
    final titleToUpload = sanitize(_pendingTitle);
    if (titleToUpload.isEmpty || titleToUpload == _lastUploadedTitle) return;

    final conn = connectionProvider();
    if (conn.isConnected()) {
      conn.sendTitle(titleToUpload);
      _lastUploadedTitle = titleToUpload;
    }
  }

  static String sanitize(String? title) {
    if (title == null) return '';
    final trimmed = title.trim();
    if (trimmed.isEmpty) return '';

    final buffer = StringBuffer();
    var count = 0;

    for (var rune in trimmed.runes) {
      if (count >= maxTermTitleChars) break;

      // ISO Control range check
      if ((rune >= 0 && rune <= 31) || (rune >= 127 && rune <= 159)) {
        continue;
      }

      buffer.writeCharCode(rune);
      count++;
    }
    return buffer.toString().trim();
  }
}
