import 'package:flutter/material.dart';

/// WebTerm 动效系统
///
/// 与 docs/design-system.md 对齐，Android 端通过 AlphaAnimation / RippleDrawable
/// 等价实现。美学约束：Swiss 现代主义 — 精确、克制、无弹性/弹簧动画。
///
/// 组件：
///  - [StatusDot]      状态指示灯（支持脉冲动画）
///  - [StaggerItem]    列表项 staggered 入场
///  - [Pressable]       按钮按下缩放反馈
class AppMotion {
  AppMotion._();

  // ── 时长（与 DesignTokens.ANIM_* 对齐） ──

  /// 快速反馈：hover、按钮按下（150ms）
  static const Duration fast = Duration(milliseconds: 150);

  /// 状态变化（200ms）
  static const Duration normal = Duration(milliseconds: 200);

  /// 页面过渡（150ms）
  static const Duration page = Duration(milliseconds: 150);

  /// 列表项入场 stagger 间隔（30ms）
  static const Duration staggerInterval = Duration(milliseconds: 30);

  // ── 曲线 ──

  /// 入场动画曲线
  static const Curve defaultCurve = Curves.easeOut;

  /// 状态切换 / 按钮反馈曲线
  static const Curve stateCurve = Curves.easeInOut;

  // ── 数值 ──

  /// 按钮按下时的缩放值
  static const double pressScale = 0.97;
}

// ────────────────────────────────────────────────────
// StatusDot — 状态指示灯
// ────────────────────────────────────────────────────

/// 设计系统状态指示灯。
///
/// 三种状态：
///   - 静态实心：connected / disconnected（颜色由外部控制）
///   - 脉冲动画：connecting 状态（opacity 1.0 ↔ 0.2，周期 600ms）
///
/// 与 Android [StatusIndicatorView] 行为完全一致：
///   - CONNECTED:    纯色 solid
///   - CONNECTING:   脉冲 AlphaAnimation 1.0→0.2
///   - DISCONNECTED: 纯色 solid
class StatusDot extends StatefulWidget {
  const StatusDot({
    super.key,
    required this.color,
    this.pulsing = false,
    this.size = 8.0,
  });

  /// 指示灯颜色（通常来自 AppColors.success / warning / danger）
  final Color color;

  /// 是否播放脉冲动画（用于 connecting 状态）
  final bool pulsing;

  /// 指示灯直径，默认 8dp（与 DesignTokens.STATUS_DOT_SIZE 对齐）
  final double size;

  @override
  State<StatusDot> createState() => _StatusDotState();
}

class _StatusDotState extends State<StatusDot>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late final Animation<double> _opacity;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 600),
      vsync: this,
    );
    _opacity = Tween<double>(begin: 1.0, end: 0.2).animate(_controller);
    if (widget.pulsing) {
      _controller.repeat(reverse: true);
    }
  }

  @override
  void didUpdateWidget(StatusDot oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.pulsing && !_controller.isAnimating) {
      _controller.repeat(reverse: true);
    } else if (!widget.pulsing && _controller.isAnimating) {
      _controller.stop();
      _controller.value = 1.0;
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _opacity,
      builder: (context, child) {
        return Opacity(
          opacity: widget.pulsing ? _opacity.value : 1.0,
          child: child,
        );
      },
      child: Container(
        width: widget.size,
        height: widget.size,
        decoration: BoxDecoration(
          color: widget.color,
          shape: BoxShape.circle,
        ),
      ),
    );
  }
}

// ────────────────────────────────────────────────────
// StaggerItem — 列表项 staggered 入场
// ────────────────────────────────────────────────────

/// 列表项 staggered 入场动画。
///
/// 每个 item 延迟 `index × interval` 后执行 fade-in + slide-up（8px），
/// 与 Web 端 CSS `@keyframes cardIn` + `animation-delay` 行为等价。
///
/// 用法：
/// ```dart
/// ListView.builder(
///   itemCount: items.length,
///   itemBuilder: (context, index) {
///     return StaggerItem(
///       index: index,
///       child: MyCard(item: items[index]),
///     );
///   },
/// )
/// ```
class StaggerItem extends StatefulWidget {
  const StaggerItem({
    super.key,
    required this.index,
    required this.child,
    this.interval = AppMotion.staggerInterval,
  });

  /// 在列表中的位置，决定延迟时间
  final int index;

  /// 需要动画入场的子组件
  final Widget child;

  /// 每项之间的延迟间隔，默认 30ms
  final Duration interval;

  @override
  State<StaggerItem> createState() => _StaggerItemState();
}

class _StaggerItemState extends State<StaggerItem>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late final Animation<double> _opacity;
  late final Animation<Offset> _slide;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );
    _opacity = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _controller, curve: AppMotion.defaultCurve),
    );
    _slide = Tween<Offset>(
      begin: const Offset(0, 0.1),
      end: Offset.zero,
    ).animate(
      CurvedAnimation(parent: _controller, curve: AppMotion.defaultCurve),
    );

    // 延迟启动，实现 staggered 效果
    Future.delayed(widget.interval * widget.index, () {
      if (mounted) _controller.forward();
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: _opacity,
      child: SlideTransition(
        position: _slide,
        child: widget.child,
      ),
    );
  }
}

// ────────────────────────────────────────────────────
// Pressable — 按钮按下缩放反馈
// ────────────────────────────────────────────────────

/// 按钮按下缩放反馈。
///
/// 按下时缩放至 0.97，松开回弹至 1.0。与 Web 端 `active:scale-[0.97]`
/// 和 Android 端 RippleDrawable 的视觉反馈对齐。
///
/// 用法：
/// ```dart
/// Pressable(
///   onTap: () => doSomething(),
///   child: myCardOrButton,
/// )
/// ```
class Pressable extends StatefulWidget {
  const Pressable({
    super.key,
    required this.child,
    this.onTap,
    this.scaleAmount = AppMotion.pressScale,
  });

  final Widget child;
  final VoidCallback? onTap;
  final double scaleAmount;

  @override
  State<Pressable> createState() => _PressableState();
}

class _PressableState extends State<Pressable> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown:
          widget.onTap != null ? (_) => setState(() => _pressed = true) : null,
      onTapUp: widget.onTap != null
          ? (_) {
              setState(() => _pressed = false);
              widget.onTap?.call();
            }
          : null,
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedScale(
        scale: _pressed ? widget.scaleAmount : 1.0,
        duration: AppMotion.fast,
        curve: AppMotion.stateCurve,
        child: widget.child,
      ),
    );
  }
}
