import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'app_colors.dart';
import 'app_typography.dart';
import 'app_motion.dart';

class AppTheme {
  AppTheme._();

  // ── Spacing（与 DesignTokens.SPACE_* 对齐） ──

  static const double space1 = 4;
  static const double space2 = 8;
  static const double space3 = 12;
  static const double space4 = 16;
  static const double space5 = 24;
  static const double space6 = 32;
  static const double space8 = 48;

  // ── Radius（与 DesignTokens.RADIUS_* 对齐） ──

  static const double radiusSm = 4;
  static const double radiusMd = 6;
  static const double radiusLg = 8;

  // ── Animation Durations（委托给 AppMotion，保留兼容） ──

  static const Duration animFast = AppMotion.fast;
  static const Duration animNormal = AppMotion.normal;
  static const Duration animPage = AppMotion.page;

  // ── Component sizes（与 DesignTokens 对齐） ──

  static const double topbarHeight = 44;
  static const double topbarIconSize = 36;
  static const double quickbarHeight = 92;
  static const double quickbarKeyHeight = 36;
  static const double statusDotSize = 8;
  static const double deviceBadgeSize = 42;
  static const double cardPaddingV = 12;
  static const double cardPaddingH = 14;

  // ── Dividers（统一顶栏 / 区块底部分割线） ──

  /// 1px 底部分割线，用于顶栏和区块分隔
  static const BorderSide dividerSide = BorderSide(
    color: AppColors.borderPrimary,
    width: 1.0,
  );

  /// 顶栏底部 1px 分割线装饰
  static const BoxDecoration topbarDecoration = BoxDecoration(
    color: AppColors.bgSecondary,
    border: Border(bottom: dividerSide),
  );

  // ── ThemeData ──

  static ThemeData get darkTheme {
    return ThemeData(
      brightness: Brightness.dark,
      scaffoldBackgroundColor: AppColors.bgPrimary,
      primaryColor: AppColors.accent,
      cardColor: AppColors.bgSecondary,
      fontFamily: 'GeistSans',
      colorScheme: const ColorScheme.dark(
        primary: AppColors.accent,
        surface: AppColors.bgSecondary,
        error: AppColors.danger,
      ),
      textTheme: TextTheme(
        bodyLarge: AppTypography.body(),
        bodyMedium: AppTypography.body(),
        labelLarge: AppTypography.label(),
        labelSmall: AppTypography.caption(),
      ),
      dividerTheme: const DividerThemeData(
        color: AppColors.borderPrimary,
        thickness: 1.0,
        space: 0.0,
      ),
      // 页面过渡动画：fade 150ms（与 Web 端 fade 过渡对齐）
      pageTransitionsTheme: PageTransitionsTheme(
        builders: {
          TargetPlatform.android:
              const FadeUpwardsPageTransitionsBuilder(),
          TargetPlatform.iOS: const CupertinoPageTransitionsBuilder(),
        },
      ),
      // AppBar 默认样式对齐设计系统
      appBarTheme: const AppBarTheme(
        backgroundColor: AppColors.bgSecondary,
        elevation: 0,
        scrolledUnderElevation: 0,
        surfaceTintColor: Colors.transparent,
      ),
      // 输入框默认样式
      inputDecorationTheme: InputDecorationTheme(
        filled: false,
        labelStyle: AppTypography.body().copyWith(
          color: AppColors.textSecondary,
        ),
        hintStyle: AppTypography.body().copyWith(
          color: AppColors.textDisabled,
        ),
        enabledBorder: const UnderlineInputBorder(
          borderSide: BorderSide(color: AppColors.borderPrimary),
        ),
        focusedBorder: const UnderlineInputBorder(
          borderSide: BorderSide(color: AppColors.accent),
        ),
      ),
    );
  }
}

/// 设计系统卡片容器。
///
/// 与 Android 端 UIUtils.panelBackground() 对齐：
///   - 背景：bg_secondary (#111113)
///   - 边框：border-primary (#27272A) 1px
///   - 圆角：radius-md (6dp)
class AppCard extends StatelessWidget {
  const AppCard({
    super.key,
    required this.child,
    this.padding,
    this.onTap,
  });

  final Widget child;
  final EdgeInsetsGeometry? padding;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final card = Container(
      padding: padding ??
          const EdgeInsets.symmetric(
            horizontal: AppTheme.cardPaddingH,
            vertical: AppTheme.cardPaddingV,
          ),
      decoration: BoxDecoration(
        color: AppColors.bgSecondary,
        borderRadius: BorderRadius.circular(AppTheme.radiusMd),
        border: Border.all(color: AppColors.borderPrimary),
      ),
      child: child,
    );

    if (onTap != null) {
      return GestureDetector(onTap: onTap, child: card);
    }
    return card;
  }
}

/// 设计系统分组区块容器。
///
/// 与 Android 端 section card 对齐：
///   - 背景：bg_secondary + border-primary + radius-md
///   - 内部 padding: space4
class AppSection extends StatelessWidget {
  const AppSection({
    super.key,
    required this.child,
    this.title,
    this.titleIcon,
  });

  final Widget child;
  final String? title;
  final IconData? titleIcon;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(AppTheme.space4),
      decoration: BoxDecoration(
        color: AppColors.bgSecondary,
        borderRadius: BorderRadius.circular(AppTheme.radiusMd),
        border: Border.all(color: AppColors.borderPrimary),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          if (title != null) ...[
            _SectionTitle(icon: titleIcon, title: title!),
            const SizedBox(height: AppTheme.space3),
          ],
          child,
        ],
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle({this.icon, required this.title});

  final IconData? icon;
  final String title;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        if (icon != null) ...[
          Icon(icon, color: AppColors.accent, size: 18),
          const SizedBox(width: AppTheme.space2),
        ],
        Text(title, style: AppTypography.heading()),
      ],
    );
  }
}
