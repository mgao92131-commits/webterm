import 'package:flutter/material.dart';

class AppColors {
  AppColors._();

  // ── Background ──
  static const bgPrimary = Color(0xFF0A0A0B);
  static const bgSecondary = Color(0xFF111113);
  static const bgTertiary = Color(0xFF18181B);

  // ── Borders ──
  static const borderPrimary = Color(0xFF27272A);
  static const borderSecondary = Color(0xFF1F1F23);
  static const borderHover = Color(0xFF3F3F46);

  // ── Text ──
  static const textPrimary = Color(0xFFFAFAFA);
  static const textSecondary = Color(0xFFA1A1AA);
  static const textTertiary = Color(0xFF71717A);
  static const textDisabled = Color(0xFF52525B);

  // ── Accent ──
  static const accent = Color(0xFF10B981);
  static const accentHover = Color(0xFF34D399);
  static const accentText = Color(0xFF6EE7B7);

  // ── Semantic ──
  static const success = Color(0xFF10B981);
  static const warning = Color(0xFFF59E0B);
  static const danger = Color(0xFFEF4444);
  static const info = Color(0xFF3B82F6);

  // ── Terminal ──
  static const terminalBg = Color(0xFF000000);
  static const terminalFg = Color(0xFFE5E7EB);

  // ── Overlay ──
  static const overlay = Color(0xCC000000);

  // ── Computed backgrounds ──
  static Color accentBg() => accent.withAlpha(0x1A);
  static Color accentBgStrong() => accent.withAlpha(0x4D);
  static Color dangerBg() => danger.withAlpha(0x1A);
  static Color warningBg() => warning.withAlpha(0x1A);
  static Color successBg() => success.withAlpha(0x1A);
}
