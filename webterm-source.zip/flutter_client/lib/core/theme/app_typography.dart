import 'package:flutter/material.dart';
import 'app_colors.dart';

/// WebTerm 排版系统
///
/// 与 docs/design-system.md 字体层级对齐：
///   - 标题/正文：Geist Sans
///   - 代码/终端/数据：Geist Mono
///
/// 字号层级参考 DesignTokens.TEXT_*_SIZE
class AppTypography {
  AppTypography._();

  static const String _fontSans = 'GeistSans';
  static const String _fontMono = 'GeistMono';

  // ── Sans Serif（UI 文字） ──

  /// 品牌名/页面标题 16px w600
  static TextStyle brand() =>
      _base(_fontSans, 16, AppColors.textPrimary, FontWeight.w600);

  /// 大数字/关键状态显示 24px w700
  static TextStyle display() =>
      _base(_fontSans, 24, AppColors.textPrimary, FontWeight.w700);

  /// 区块标题 14px w600
  static TextStyle heading() =>
      _base(_fontSans, 14, AppColors.textPrimary, FontWeight.w600);

  /// 正文 13px w400（略小于 heading，增加层级对比）
  static TextStyle body() =>
      _base(_fontSans, 13, AppColors.textSecondary, FontWeight.w400);

  /// 标签/徽章 12px w500
  static TextStyle label() =>
      _base(_fontSans, 12, AppColors.textTertiary, FontWeight.w500);

  /// 辅助信息 11px w400
  static TextStyle caption() =>
      _base(_fontSans, 11, AppColors.textTertiary, FontWeight.w400);

  /// 分类标签 10px w600 + letterSpacing（overline 风格）
  static TextStyle overline() =>
      _base(_fontSans, 10, AppColors.textTertiary, FontWeight.w600).copyWith(
        letterSpacing: 1.2,
      );

  // ── Monospace（代码/终端/ID） ──

  /// 等宽正文 13px w400
  static TextStyle mono() =>
      _base(_fontMono, 13, AppColors.textPrimary, FontWeight.w400);

  /// 等宽小字 11px w400（日志、ID、路径）
  static TextStyle monoTiny() =>
      _base(_fontMono, 11, AppColors.textSecondary, FontWeight.w400);

  // ── Dialog ──

  /// 对话框标题 16px w600
  static TextStyle dialogTitle() =>
      _base(_fontSans, 16, AppColors.textPrimary, FontWeight.w600);

  // ── Internal ──

  static TextStyle _base(
    String family,
    double size,
    Color color,
    FontWeight weight,
  ) {
    return TextStyle(
      fontFamily: family,
      fontSize: size,
      color: color,
      fontWeight: weight,
      height: 1.4,
    );
  }
}
