import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:dio/dio.dart';
import 'package:webterm_mobile/core/network/webterm_api.dart';
import 'package:webterm_mobile/core/storage/server_config_store.dart';
import 'package:webterm_mobile/core/storage/terminal_disk_cache.dart';
import 'package:webterm_mobile/models/server_config.dart';
import 'package:webterm_mobile/services/server_config_manager.dart';
import 'package:webterm_mobile/services/terminal_cache_coordinator.dart';
import 'package:webterm_mobile/services/relay_coordinator.dart';
import 'package:webterm_mobile/services/home_server_coordinator.dart';
import 'package:webterm_mobile/services/server_group_controller.dart';
import 'package:webterm_mobile/services/go_core_agent_service.dart';

final sharedPreferencesProvider = Provider<SharedPreferences>((ref) {
  throw UnimplementedError(
    'sharedPreferencesProvider must be overridden in main()',
  );
});

final dioProvider = Provider<Dio>((ref) => Dio());

final webTermApiProvider = Provider<WebTermApi>((ref) {
  return WebTermApi(ref.watch(dioProvider));
});

final goCoreAgentServiceProvider = Provider<GoCoreAgentService>((ref) {
  return GoCoreAgentService(ref.watch(dioProvider));
});

final serverConfigStoreProvider = Provider<ServerConfigStore>((ref) {
  return ServerConfigStore(ref.watch(sharedPreferencesProvider));
});

final serverConfigManagerProvider = Provider<ServerConfigManager>((ref) {
  final store = ref.watch(serverConfigStoreProvider);
  return ServerConfigManager(store);
});

class ServerConfigListNotifier extends StateNotifier<List<ServerConfig>> {
  final ServerConfigManager manager;

  ServerConfigListNotifier(this.manager) : super([]) {
    load();
  }

  void load() {
    manager.load();
    state = List.from(manager.servers);
  }

  void save() {
    manager.save();
    state = List.from(manager.servers);
  }

  void addOrUpdate(
    ServerConfig? existingServer,
    String name,
    String url,
    String cookie,
    String username,
    String password, {
    bool? relayMaster,
    bool? relayDevice,
    String? deviceId,
  }) {
    manager.addOrUpdate(
      existingServer,
      name,
      url,
      cookie,
      username,
      password,
      relayMaster: relayMaster,
      relayDevice: relayDevice,
      deviceId: deviceId,
    );
    save();
  }

  void remove(ServerConfig server) {
    manager.remove(server);
    save();
  }

  void updateServer(ServerConfig server) {
    manager.updateServer(server);
    save();
  }
}

final serverListProvider =
    StateNotifierProvider<ServerConfigListNotifier, List<ServerConfig>>((ref) {
      final manager = ref.watch(serverConfigManagerProvider);
      return ServerConfigListNotifier(manager);
    });

// Relay implementation
class RiverpodRelayHost implements RelayCoordinatorHost {
  final Ref ref;
  RiverpodRelayHost(this.ref);

  @override
  ServerConfigManager get serverConfigs =>
      ref.read(serverConfigManagerProvider);

  @override
  void onRelayDevicesChanged() {
    ref.read(relayDevicesProvider.notifier).state = List.from(
      ref.read(relayCoordinatorProvider).devices,
    );
  }

  @override
  void onRelayAuthDone() {
    ref.read(serverListProvider.notifier).load();
  }

  @override
  void saveServers() {
    ref.read(serverListProvider.notifier).save();
  }
}

final relayDevicesProvider = StateProvider<List<ServerConfig>>((ref) => []);
final relayStateProvider = StateProvider<RelayState>(
  (ref) => RelayState.notConfigured,
);

final relayCoordinatorProvider = Provider<RelayCoordinator>((ref) {
  final api = ref.watch(webTermApiProvider);
  final host = RiverpodRelayHost(ref);
  final coordinator = RelayCoordinator(api: api, host: host);

  coordinator.onStateChanged = (state) {
    ref.read(relayStateProvider.notifier).state = state;
  };

  ref.onDispose(() {
    coordinator.destroy();
  });

  return coordinator;
});

// Disk cache
final diskCacheProvider = Provider<TerminalDiskCache>((ref) {
  throw UnimplementedError('diskCacheProvider must be overridden in main()');
});

final cacheCoordinatorProvider = Provider<TerminalCacheCoordinator>((ref) {
  return TerminalCacheCoordinator(ref.watch(diskCacheProvider));
});

// Home sessions state
class HomeSessionsState {
  final Map<String, List<dynamic>> sessions;
  final Map<String, String> errors;
  final Map<String, ServerGroupStatus> statuses;

  HomeSessionsState({
    this.sessions = const {},
    this.errors = const {},
    this.statuses = const {},
  });

  HomeSessionsState copyWith({
    Map<String, List<dynamic>>? sessions,
    Map<String, String>? errors,
    Map<String, ServerGroupStatus>? statuses,
  }) {
    return HomeSessionsState(
      sessions: sessions ?? this.sessions,
      errors: errors ?? this.errors,
      statuses: statuses ?? this.statuses,
    );
  }
}

class HomeSessionsNotifier extends StateNotifier<HomeSessionsState> {
  HomeSessionsNotifier() : super(HomeSessionsState());

  void setSessions(String serverId, List<dynamic> sessionsList) {
    final currentSessions = Map<String, List<dynamic>>.from(state.sessions);
    currentSessions[serverId] = sessionsList;
    final currentErrors = Map<String, String>.from(state.errors);
    currentErrors.remove(serverId);
    state = state.copyWith(sessions: currentSessions, errors: currentErrors);
  }

  void setError(String serverId, String error) {
    final currentErrors = Map<String, String>.from(state.errors);
    currentErrors[serverId] = error;
    state = state.copyWith(errors: currentErrors);
  }

  void setStatus(String serverId, ServerGroupStatus status) {
    final currentStatuses = Map<String, ServerGroupStatus>.from(state.statuses);
    currentStatuses[serverId] = status;
    state = state.copyWith(statuses: currentStatuses);
  }

  void clearServer(String serverId) {
    final currentSessions = Map<String, List<dynamic>>.from(state.sessions);
    currentSessions.remove(serverId);
    final currentErrors = Map<String, String>.from(state.errors);
    currentErrors.remove(serverId);
    final currentStatuses = Map<String, ServerGroupStatus>.from(state.statuses);
    currentStatuses.remove(serverId);
    state = state.copyWith(
      sessions: currentSessions,
      errors: currentErrors,
      statuses: currentStatuses,
    );
  }
}

final homeSessionsProvider =
    StateNotifierProvider<HomeSessionsNotifier, HomeSessionsState>((ref) {
      return HomeSessionsNotifier();
    });

class RiverpodHomeHost
    implements HomeServerCoordinatorListener, SessionListAdapter {
  final Ref ref;
  RiverpodHomeHost(this.ref);

  @override
  bool isHomeActive() => true;

  @override
  void onAuthenticated(ServerConfig server) {
    ref.read(serverListProvider.notifier).updateServer(server);
    ref.read(homeCoordinatorProvider).updateServerInHolder(server);
  }

  @override
  void onRemoveCachedTerminal(String baseUrl, String sessionId) {
    // Intentionally left blank as cache coordinator manages deletions directly
  }

  @override
  void onRemoveMissingCachedSessionsForServer(
    ServerConfig server,
    Set<String> liveSessionIdentities,
  ) {
    final coordinator = ref.read(cacheCoordinatorProvider);
    coordinator.removeMissingForServer(server, liveSessionIdentities, null);
  }

  @override
  bool get hasSessionRows {
    return ref.read(homeSessionsProvider).sessions.isNotEmpty;
  }

  @override
  void submitSessions(ServerConfig server, List<dynamic> sessions) {
    ref.read(homeSessionsProvider.notifier).setSessions(server.id, sessions);
  }

  @override
  void showError(ServerConfig server, String error) {
    ref.read(homeSessionsProvider.notifier).setError(server.id, error);
  }
}

final homeCoordinatorProvider = Provider<HomeServerCoordinator>((ref) {
  final api = ref.watch(webTermApiProvider);
  final cache = ref.watch(cacheCoordinatorProvider);
  final host = RiverpodHomeHost(ref);
  final coordinator = HomeServerCoordinator(
    api: api,
    terminalCache: cache,
    listener: host,
  );

  coordinator.attachSessionAdapter(host);

  ref.onDispose(() {
    coordinator.destroy();
  });

  return coordinator;
});
