import 'package:dio/dio.dart';
import 'package:webterm_mobile/models/server_config.dart';
import 'package:webterm_mobile/core/network/webterm_urls.dart';

class LoginResult {
  final bool success;
  final bool otpRequired;
  final String? targetDeviceId;
  final String? cookie;
  final String? error;

  const LoginResult({
    required this.success,
    this.otpRequired = false,
    this.targetDeviceId,
    this.cookie,
    this.error,
  });

  factory LoginResult.success(String cookie) =>
      LoginResult(success: true, cookie: cookie);

  factory LoginResult.otpRequired(String targetDeviceId, String cookie) =>
      LoginResult(success: false, otpRequired: true, targetDeviceId: targetDeviceId, cookie: cookie);

  factory LoginResult.error(String error) =>
      LoginResult(success: false, error: error);
}

class WebTermApi {
  final Dio _dio;

  WebTermApi(Dio dio) : _dio = dio;

  Future<LoginResult> login(
    String baseUrl,
    String? cookie,
    String username,
    String password,
  ) async {
    try {
      final normalizedUrl = WebTermUrls.normalizeBaseUrl(baseUrl);
      final response = await _dio.post(
        '$normalizedUrl/api/auth/login',
        data: {'username': username, 'password': password},
        options: Options(
          headers: {'Cookie': cookie ?? ''},
          validateStatus: (status) => status != null && status < 500,
        ),
      );

      if (response.statusCode != 200) {
        return LoginResult.error('Login failed: ${response.statusCode} ${response.data}');
      }

      final mergedCookie = _parseAndMergeCookies(cookie, response.headers['set-cookie']);
      final data = response.data;
      if (data is Map && data['otp_required'] == true) {
        final targetDeviceId = data['target_device_id']?.toString() ?? '';
        return LoginResult.otpRequired(targetDeviceId, mergedCookie);
      }

      if (mergedCookie.isEmpty) {
        return LoginResult.error('Login did not return an auth cookie.');
      }

      return LoginResult.success(mergedCookie);
    } catch (e) {
      return LoginResult.error('Login failed: $e');
    }
  }

  Future<LoginResult> verifyOtp(
    String baseUrl,
    String username,
    String code,
    String targetDeviceId,
    String? cookie,
  ) async {
    try {
      final normalizedUrl = WebTermUrls.normalizeBaseUrl(baseUrl);
      final response = await _dio.post(
        '$normalizedUrl/api/auth/verify-otp',
        data: {
          'email': username,
          'code': code,
          'target_device_id': targetDeviceId,
        },
        options: Options(
          headers: {'Cookie': cookie ?? ''},
          validateStatus: (status) => status != null && status < 500,
        ),
      );

      if (response.statusCode != 200) {
        return LoginResult.error('OTP verification failed: ${response.statusCode} ${response.data}');
      }

      final mergedCookie = _parseAndMergeCookies(cookie, response.headers['set-cookie']);
      if (mergedCookie.isEmpty) {
        return LoginResult.error('OTP verification did not return an auth cookie.');
      }

      return LoginResult.success(mergedCookie);
    } catch (e) {
      return LoginResult.error('OTP verification failed: $e');
    }
  }

  Future<String> refresh(String baseUrl, String? cookie) async {
    final normalizedUrl = WebTermUrls.normalizeBaseUrl(baseUrl);
    final response = await _dio.post(
      '$normalizedUrl/api/auth/refresh',
      options: Options(
        headers: {'Cookie': cookie ?? ''},
      ),
    );

    if (response.statusCode != 200) {
      throw Exception('Refresh failed: ${response.statusCode} ${response.data}');
    }

    return _parseAndMergeCookies(cookie, response.headers['set-cookie']);
  }

  Future<List<dynamic>> fetchDevices(String baseUrl, String? cookie) async {
    final normalizedUrl = WebTermUrls.normalizeBaseUrl(baseUrl);
    final response = await _dio.get(
      '$normalizedUrl/api/devices',
      options: Options(
        headers: {'Cookie': cookie ?? ''},
      ),
    );

    if (response.statusCode != 200) {
      throw DioException(
        requestOptions: response.requestOptions,
        response: response,
      );
    }

    return response.data as List<dynamic>;
  }

  Future<List<dynamic>> fetchSessions(ServerConfig server) async {
    final headers = <String, String>{
      'Cookie': server.cookie,
    };
    if (server.relayDevice && server.deviceId.isNotEmpty) {
      headers['x-device-id'] = server.deviceId;
    }

    final response = await _dio.get(
      '${server.url}/api/sessions',
      options: Options(headers: headers),
    );

    if (response.statusCode != 200) {
      throw DioException(
        requestOptions: response.requestOptions,
        response: response,
      );
    }

    return response.data as List<dynamic>;
  }

  Future<String> createSession(ServerConfig server) async {
    final headers = <String, String>{
      'Cookie': server.cookie,
    };
    if (server.relayDevice && server.deviceId.isNotEmpty) {
      headers['x-device-id'] = server.deviceId;
    }

    final response = await _dio.post(
      '${server.url}/api/sessions',
      data: {'name': 'Android'}, // Keep compatibility payload
      options: Options(headers: headers),
    );

    if (response.statusCode != 200) {
      throw Exception('Session creation failed: ${response.statusCode} ${response.data}');
    }

    final data = response.data;
    if (data is Map && data.containsKey('id')) {
      return data['id'] as String;
    }
    throw Exception('Session response error: missing id');
  }

  Future<String> createSessionRaw(String baseUrl, String? cookie) async {
    final normalizedUrl = WebTermUrls.normalizeBaseUrl(baseUrl);
    final response = await _dio.post(
      '$normalizedUrl/api/sessions',
      data: {'name': 'Android'},
      options: Options(
        headers: {'Cookie': cookie ?? ''},
      ),
    );

    if (response.statusCode != 200) {
      throw Exception('Session creation failed: ${response.statusCode} ${response.data}');
    }

    final data = response.data;
    if (data is Map && data.containsKey('id')) {
      return data['id'] as String;
    }
    throw Exception('Session response error: missing id');
  }

  Future<void> renameSession(ServerConfig server, String sessionId, String newName) async {
    final headers = <String, String>{
      'Cookie': server.cookie,
    };
    if (server.relayDevice && server.deviceId.isNotEmpty) {
      headers['x-device-id'] = server.deviceId;
    }

    final response = await _dio.patch(
      '${server.url}/api/sessions/${WebTermUrls.encodePath(sessionId)}',
      data: {'name': newName},
      options: Options(headers: headers),
    );

    if (response.statusCode != 200) {
      throw Exception('Rename failed: ${response.statusCode} ${response.data}');
    }
  }

  Future<void> deleteSession(ServerConfig server, String sessionId) async {
    final headers = <String, String>{
      'Cookie': server.cookie,
    };
    if (server.relayDevice && server.deviceId.isNotEmpty) {
      headers['x-device-id'] = server.deviceId;
    }

    final response = await _dio.delete(
      '${server.url}/api/sessions/${WebTermUrls.encodePath(sessionId)}',
      options: Options(headers: headers),
    );

    if (response.statusCode != 200) {
      throw Exception('Close failed: ${response.statusCode} ${response.data}');
    }
  }

  Future<void> deleteSessionRaw(String baseUrl, String? cookie, String sessionId) async {
    final headers = <String, String>{
      'Cookie': cookie ?? '',
    };
    if (sessionId.contains(':')) {
      final parts = sessionId.split(':');
      if (parts.isNotEmpty && parts[0].isNotEmpty) {
        headers['x-device-id'] = parts[0];
      }
    }

    final normalizedUrl = WebTermUrls.normalizeBaseUrl(baseUrl);
    final response = await _dio.delete(
      '$normalizedUrl/api/sessions/${WebTermUrls.encodePath(sessionId)}',
      options: Options(headers: headers),
    );

    if (response.statusCode != 200) {
      throw Exception('Close failed: ${response.statusCode} ${response.data}');
    }
  }

  static String _parseAndMergeCookies(String? oldCookieHeader, List<String>? setCookieHeaders) {
    final cookieMap = <String, String>{};
    if (oldCookieHeader != null && oldCookieHeader.isNotEmpty) {
      final parts = oldCookieHeader.split(';');
      for (var part in parts) {
        final eq = part.indexOf('=');
        if (eq > 0) {
          final name = part.substring(0, eq).trim();
          final value = part.substring(eq + 1).trim();
          if (name.isNotEmpty) {
            cookieMap[name] = value;
          }
        }
      }
    }
    if (setCookieHeaders != null) {
      for (var header in setCookieHeaders) {
        final semicolon = header.indexOf(';');
        final cookiePart = semicolon >= 0 ? header.substring(0, semicolon) : header;
        final eq = cookiePart.indexOf('=');
        if (eq > 0) {
          final name = cookiePart.substring(0, eq).trim();
          final value = cookiePart.substring(eq + 1).trim();
          if (name.isNotEmpty) {
            cookieMap[name] = value;
          }
        }
      }
    }
    return cookieMap.entries.map((e) => '${e.key}=${e.value}').join('; ');
  }
}
