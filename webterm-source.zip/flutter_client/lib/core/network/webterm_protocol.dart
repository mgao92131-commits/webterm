import 'dart:typed_data';
import 'dart:convert';

/// WebTerm binary framing protocol.
///
/// Each frame consists of a 1-byte message type followed by an optional
/// payload. Control messages carry JSON-encoded payloads.
class WebTermProtocol {
  WebTermProtocol._();

  // ── Message types ──
  static const int msgInput = 0x01;
  static const int msgOutput = 0x02;
  static const int msgResize = 0x03;
  static const int msgHello = 0x04;
  static const int msgInfo = 0x05;
  static const int msgExit = 0x06;
  static const int msgPing = 0x07;
  static const int msgPong = 0x08;
  static const int msgTitle = 0x09;
  static const int msgState = 0x0a;

  /// Builds a binary frame: `[type | payload...]`.
  static Uint8List frame(int type, Uint8List? payload) {
    final length = 1 + (payload?.length ?? 0);
    final buffer = Uint8List(length);
    buffer[0] = type;
    if (payload != null) {
      buffer.setRange(1, length, payload);
    }
    return buffer;
  }

  /// Decodes a JSON control payload from raw bytes.
  ///
  /// Returns an empty map for null, empty, or literal `"null"` payloads.
  static Map<String, dynamic> controlPayload(Uint8List? payload) {
    if (payload == null || payload.isEmpty) return {};
    final text = utf8.decode(payload).trim();
    if (text.isEmpty || text == 'null') return {};
    return json.decode(text) as Map<String, dynamic>;
  }

  /// Reads a big-endian unsigned 64-bit integer from [data] at [offset].
  static int readUint64(Uint8List data, int offset) {
    int value = 0;
    for (int i = 0; i < 8; i++) {
      value = (value << 8) | (data[offset + i] & 0xff);
    }
    return value;
  }
}
