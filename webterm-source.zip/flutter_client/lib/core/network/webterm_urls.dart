/// URL helper utilities for WebTerm server communication.
class WebTermUrls {
  WebTermUrls._();

  /// Normalizes a raw base URL by trimming whitespace, stripping trailing
  /// slashes, and ensuring an HTTP scheme is present.
  static String normalizeBaseUrl(String? raw) {
    var value = (raw ?? '').trim();
    while (value.endsWith('/')) {
      value = value.substring(0, value.length - 1);
    }
    if (value.isEmpty) return '';
    if (!value.startsWith('http://') && !value.startsWith('https://')) {
      value = 'http://$value';
    }
    return value;
  }

  /// Converts an HTTP(S) base URL to the corresponding WebSocket URL.
  static String toWebSocketUrl(String baseUrl) {
    if (baseUrl.startsWith('https://')) {
      return 'wss://${baseUrl.substring(8)}';
    }
    if (baseUrl.startsWith('http://')) {
      return 'ws://${baseUrl.substring(7)}';
    }
    return 'ws://$baseUrl';
  }

  /// Percent-encodes a single path segment.
  static String encodePath(String value) => Uri.encodeComponent(value);
}
