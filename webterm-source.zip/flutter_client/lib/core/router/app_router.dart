import 'package:go_router/go_router.dart';
import 'package:webterm_mobile/screens/home_screen.dart';
import 'package:webterm_mobile/screens/device_sessions_screen.dart';
import 'package:webterm_mobile/screens/terminal_screen.dart';
import 'package:webterm_mobile/screens/agent_settings_screen.dart';

final goRouter = GoRouter(
  initialLocation: '/',
  routes: [
    GoRoute(path: '/', builder: (context, state) => const HomeScreen()),
    GoRoute(
      path: '/sessions',
      builder: (context, state) {
        final serverId = state.uri.queryParameters['serverId'] ?? '';
        return DeviceSessionsScreen(serverId: serverId);
      },
    ),
    GoRoute(
      path: '/agent',
      builder: (context, state) => const AgentSettingsScreen(),
    ),
    GoRoute(
      path: '/terminal',
      builder: (context, state) {
        final params = state.uri.queryParameters;
        return TerminalScreen(
          serverId: params['serverId'] ?? '',
          baseUrl: params['baseUrl'] ?? '',
          cookie: params['cookie'] ?? '',
          sessionId: params['sessionId'] ?? '',
          requestTitle: params['title'] ?? 'Terminal',
          requestSubtitle: params['subtitle'] ?? '',
          instanceId: params['instanceId'],
          createdAt: params['createdAt'],
        );
      },
    ),
  ],
);
