import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';

class CrashReporter {
  static const String crashLogDirName = 'crash-logs';
  static const int maxLogFiles = 10;

  final Directory filesDir;

  CrashReporter(this.filesDir);

  static Future<void> install() async {
    final dir = await getApplicationDocumentsDirectory();
    final reporter = CrashReporter(dir);
    
    FlutterError.onError = (details) {
      FlutterError.presentError(details);
      reporter.writeCrash(details.exception, details.stack);
    };
    
    PlatformDispatcher.instance.onError = (error, stack) {
      reporter.writeCrash(error, stack);
      return true;
    };
  }

  static Future<String?> readLatestCrash() async {
    try {
      final dir = await getApplicationDocumentsDirectory();
      final reporter = CrashReporter(dir);
      return reporter.getLatestCrashContent();
    } catch (_) {
      return null;
    }
  }

  Directory get _crashDir => Directory('${filesDir.path}/$crashLogDirName');

  void writeCrash(Object error, StackTrace? stack) {
    try {
      final dir = _crashDir;
      if (!dir.existsSync()) {
        dir.createSync(recursive: true);
      }

      final now = DateTime.now();
      final stamp = '${now.year}${_pad(now.month)}${_pad(now.day)}-'
          '${_pad(now.hour)}${_pad(now.minute)}${_pad(now.second)}-'
          '${now.millisecond.toString().padLeft(3, '0')}';
      
      final file = File('${dir.path}/crash-$stamp.txt');
      file.writeAsStringSync(_buildCrashText(error, stack, stamp));

      _trimOldLogs(dir);
    } catch (_) {}
  }

  String? getLatestCrashContent() {
    try {
      final latest = _latestCrashFile();
      if (latest != null && latest.existsSync()) {
        return latest.readAsStringSync();
      }
    } catch (_) {}
    return null;
  }

  File? _latestCrashFile() {
    final dir = _crashDir;
    if (!dir.existsSync()) return null;

    final files = dir.listSync().whereType<File>().where((f) => f.path.endsWith('.txt')).toList();
    if (files.isEmpty) return null;

    files.sort((a, b) => b.lastModifiedSync().compareTo(a.lastModifiedSync()));
    return files.first;
  }

  String _buildCrashText(Object error, StackTrace? stack, String stamp) {
    final buffer = StringBuffer();
    buffer.writeln('WebTerm Flutter crash log');
    buffer.writeln('timestamp: $stamp');
    buffer.writeln('package: webterm_mobile');
    buffer.writeln('version: 1.0.0+1');
    buffer.writeln('os: ${Platform.operatingSystem} (${Platform.operatingSystemVersion})');
    buffer.writeln('dart: ${Platform.version}');
    buffer.writeln();
    buffer.writeln('Exception: $error');
    if (stack != null) {
      buffer.writeln('Stacktrace:');
      buffer.writeln(stack.toString());
    }
    return buffer.toString();
  }

  void _trimOldLogs(Directory dir) {
    try {
      final files = dir.listSync().whereType<File>().where((f) => f.path.endsWith('.txt')).toList();
      if (files.length <= maxLogFiles) return;

      files.sort((a, b) => b.lastModifiedSync().compareTo(a.lastModifiedSync()));
      for (var i = maxLogFiles; i < files.length; i++) {
        files[i].deleteSync();
      }
    } catch (_) {}
  }

  String _pad(int value) => value.toString().padLeft(2, '0');
}
