import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:webterm_mobile/models/server_config.dart';

class ServerConfigStore {
  static const String prefsName = 'webterm';
  static const String defaultUrl = 'http://100.121.115.14:8081';
  static const String defaultUser = 'gao';

  static const String _keyServersList = 'servers_list';
  static const String _keyTerminalFontSize = 'terminal_font_size';
  static const String _keyTerminalFontType = 'terminal_font_type';
  static const String _keyTerminalFontWeight = 'terminal_font_weight';
  static const String _keyTerminalBoldFontWeight = 'terminal_bold_font_weight';

  final SharedPreferences _prefs;

  ServerConfigStore(SharedPreferences prefs) : _prefs = prefs;

  List<ServerConfig> loadServers() {
    final servers = <ServerConfig>[];
    final jsonStr = _prefs.getString(_keyServersList) ?? '';
    
    if (jsonStr.isNotEmpty) {
      try {
        final List<dynamic> decoded = json.decode(jsonStr);
        for (var item in decoded) {
          if (item is Map<String, dynamic>) {
            servers.add(ServerConfig.fromJson(item));
          }
        }
      } catch (e) {
        // Log or handle parse error
      }
    }

    if (servers.isEmpty) {
      final oldUrl = _prefs.getString('url') ?? '';
      if (oldUrl.isNotEmpty) {
        servers.add(ServerConfig(
          id: 'srv_${DateTime.now().millisecondsSinceEpoch}',
          name: '主电脑',
          url: oldUrl,
          cookie: '',
          username: _prefs.getString('user') ?? '',
          password: _prefs.getString('password') ?? '',
        ));
        saveServers(servers);
      }
    }
    return servers;
  }

  Future<void> saveServers(List<ServerConfig> servers) async {
    final encoded = servers.map((s) => s.toJson()).toList();
    await _prefs.setString(_keyServersList, json.encode(encoded));
  }

  int getFontSize() {
    return _prefs.getInt(_keyTerminalFontSize) ?? 14;
  }

  Future<void> saveFontSize(int size) async {
    await _prefs.setInt(_keyTerminalFontSize, size);
  }

  String getFontType() {
    return _prefs.getString(_keyTerminalFontType) ?? 'GeistMono';
  }

  Future<void> saveFontType(String type) async {
    await _prefs.setString(_keyTerminalFontType, type);
  }

  int getFontWeight() {
    return _prefs.getInt(_keyTerminalFontWeight) ?? 500;
  }

  Future<void> saveFontWeight(int weight) async {
    await _prefs.setInt(_keyTerminalFontWeight, weight);
  }

  int getBoldFontWeight() {
    return _prefs.getInt(_keyTerminalBoldFontWeight) ?? 700;
  }

  Future<void> saveBoldFontWeight(int weight) async {
    await _prefs.setInt(_keyTerminalBoldFontWeight, weight);
  }
}
