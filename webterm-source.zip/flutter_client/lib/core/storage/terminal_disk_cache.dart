import 'dart:convert';
import 'dart:io';
import 'package:crypto/crypto.dart';
import 'package:path_provider/path_provider.dart';
import 'package:webterm_mobile/core/network/webterm_urls.dart';
import 'package:webterm_mobile/models/server_config.dart';
import 'package:webterm_mobile/models/session_identity.dart';
import 'package:webterm_mobile/services/terminal_cache_scope.dart';

class DiskCacheMetadata {
  String baseUrl = '';
  String sessionId = '';
  String instanceId = '';
  String createdAt = '';
  String termTitle = '';
  String sessionName = '';
  int columns = 0;
  int rows = 0;
  int lastSeq = 0;
  int updatedAt = 0;

  DiskCacheMetadata({
    this.baseUrl = '',
    this.sessionId = '',
    this.instanceId = '',
    this.createdAt = '',
    this.termTitle = '',
    this.sessionName = '',
    this.columns = 0,
    this.rows = 0,
    this.lastSeq = 0,
    this.updatedAt = 0,
  });

  DiskCacheMetadata.clone(DiskCacheMetadata other) {
    baseUrl = other.baseUrl;
    sessionId = other.sessionId;
    instanceId = other.instanceId;
    createdAt = other.createdAt;
    termTitle = other.termTitle;
    sessionName = other.sessionName;
    columns = other.columns;
    rows = other.rows;
    lastSeq = other.lastSeq;
    updatedAt = other.updatedAt;
  }

  factory DiskCacheMetadata.fromJson(Map<String, dynamic> json) {
    return DiskCacheMetadata(
      baseUrl: json['baseUrl'] as String? ?? '',
      sessionId: json['sessionId'] as String? ?? '',
      instanceId: json['instanceId'] as String? ?? '',
      createdAt: json['createdAt'] as String? ?? '',
      termTitle: json['termTitle'] as String? ?? '',
      sessionName: json['sessionName'] as String? ?? '',
      columns: json['cols'] as int? ?? 0,
      rows: json['rows'] as int? ?? 0,
      lastSeq: json['lastSeq'] as int? ?? 0,
      updatedAt: json['updatedAt'] as int? ?? 0,
    );
  }

  Map<String, dynamic> toJson() => {
        'baseUrl': baseUrl,
        'sessionId': sessionId,
        'instanceId': instanceId,
        'createdAt': createdAt,
        'termTitle': termTitle,
        'sessionName': sessionName,
        'cols': columns,
        'rows': rows,
        'lastSeq': lastSeq,
        'updatedAt': updatedAt > 0 ? updatedAt : DateTime.now().millisecondsSinceEpoch,
      };
}

class RestoreResult {
  final DiskCacheMetadata metadata;
  final int lastSeq;

  const RestoreResult(this.metadata, this.lastSeq);
}

class TerminalDiskCache {
  final Directory cacheDir;

  TerminalDiskCache(Directory appFilesDir)
      : cacheDir = Directory('${appFilesDir.path}/terminal-cache') {
    if (!cacheDir.existsSync()) {
      cacheDir.createSync(recursive: true);
    }
  }

  static Future<TerminalDiskCache> create() async {
    final dir = await getApplicationDocumentsDirectory();
    return TerminalDiskCache(dir);
  }

  Future<int> saveMetadata(DiskCacheMetadata metadata) async {
    try {
      final copy = DiskCacheMetadata.clone(metadata);
      await _saveMetadataOnly(copy);
      return copy.lastSeq;
    } catch (e) {
      return metadata.lastSeq;
    }
  }

  Future<RestoreResult?> restore(
    String baseUrl,
    String sessionId,
    String expectedInstanceId,
    String expectedCreatedAt,
  ) async {
    final cacheKeyStr = key(baseUrl, sessionId, expectedInstanceId, expectedCreatedAt);
    if (cacheKeyStr.isEmpty) return null;

    final metaF = _metaFile(cacheKeyStr);
    final frameF = _frameFile(cacheKeyStr);
    final snapshotF = _snapshotFile(cacheKeyStr);

    final metadata = await _readMetadata(metaF);
    if (metadata == null) return null;

    if (!_isSameSession(metadata, baseUrl, sessionId, expectedInstanceId, expectedCreatedAt)) {
      await clear(baseUrl, sessionId, expectedInstanceId, expectedCreatedAt);
      return null;
    }

    _deleteFileSync(frameF);
    _deleteFileSync(snapshotF);
    await _writeMigratedMetadata(metaF, metadata);

    return RestoreResult(metadata, 0);
  }

  Future<List<DiskCacheMetadata>> getCachedSessionsForServer(ServerConfig server) async {
    final result = <DiskCacheMetadata>[];
    if (!cacheDir.existsSync()) return result;

    final files = cacheDir.listSync();
    for (var entity in files) {
      if (entity is File && entity.path.endsWith('.json')) {
        final metadata = await _readMetadata(entity);
        if (metadata != null && TerminalCacheScope.matches(server, metadata.baseUrl, metadata.sessionId)) {
          result.add(metadata);
        }
      }
    }

    result.sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
    return result;
  }

  Future<void> clearAsync(String baseUrl, String sessionId) async {
    final normalized = WebTermUrls.normalizeBaseUrl(baseUrl);
    await _clearMatching(normalized, sessionId);
  }

  Future<void> clearServerAsync(ServerConfig server) async {
    if (!cacheDir.existsSync()) return;
    final files = cacheDir.listSync();
    for (var entity in files) {
      if (entity is File && entity.path.endsWith('.json')) {
        final metadata = await _readMetadata(entity);
        if (metadata != null && TerminalCacheScope.matches(server, metadata.baseUrl, metadata.sessionId)) {
          await _deletePairForMetadataFile(entity);
        }
      }
    }
  }

  Future<void> clearMissingForServerAsync(ServerConfig server, Set<String> liveSessionIdentities) async {
    if (!cacheDir.existsSync()) return;
    final files = cacheDir.listSync();
    for (var entity in files) {
      if (entity is File && entity.path.endsWith('.json')) {
        final metadata = await _readMetadata(entity);
        if (metadata != null &&
            TerminalCacheScope.matches(server, metadata.baseUrl, metadata.sessionId) &&
            !liveSessionIdentities.contains(
                SessionIdentity.value(metadata.sessionId, metadata.instanceId, metadata.createdAt))) {
          await _deletePairForMetadataFile(entity);
        }
      }
    }
  }

  void shutdown() {
    // No executor cleanup required in Dart
  }

  Future<void> _saveMetadataOnly(DiskCacheMetadata metadata) async {
    final cacheKeyStr = key(metadata.baseUrl, metadata.sessionId, metadata.instanceId, metadata.createdAt);
    if (cacheKeyStr.isEmpty) return;

    final metaF = _metaFile(cacheKeyStr);
    metadata.lastSeq = 0;
    await _writeMetadata(metaF, metadata);

    _deleteFileSync(_frameFile(cacheKeyStr));
    _deleteFileSync(_snapshotFile(cacheKeyStr));
  }

  Future<void> _writeMigratedMetadata(File metaFile, DiskCacheMetadata metadata) async {
    try {
      await _writeMetadata(metaFile, metadata);
    } catch (_) {}
  }

  Future<DiskCacheMetadata?> _readMetadata(File file) async {
    if (!file.existsSync()) return null;
    try {
      final content = await file.readAsString(encoding: utf8);
      if (content.isEmpty) return null;
      return DiskCacheMetadata.fromJson(json.decode(content) as Map<String, dynamic>);
    } catch (_) {
      return null;
    }
  }

  Future<void> _writeMetadata(File file, DiskCacheMetadata metadata) async {
    final parent = file.parent;
    if (!parent.existsSync()) {
      parent.createSync(recursive: true);
    }
    final tmp = File('${file.path}.tmp');
    metadata.updatedAt = DateTime.now().millisecondsSinceEpoch;
    await tmp.writeAsString(json.encode(metadata.toJson()), encoding: utf8);
    await _replaceFile(tmp, file);
  }

  Future<void> _replaceFile(File source, File target) async {
    if (target.existsSync()) {
      target.deleteSync();
    }
    await source.rename(target.path);
  }

  bool _isSameSession(
    DiskCacheMetadata metadata,
    String baseUrl,
    String sessionId,
    String expectedInstanceId,
    String expectedCreatedAt,
  ) {
    if (WebTermUrls.normalizeBaseUrl(metadata.baseUrl) != WebTermUrls.normalizeBaseUrl(baseUrl)) {
      return false;
    }
    if (metadata.sessionId != sessionId) {
      return false;
    }
    final expectedInstance = expectedInstanceId.trim();
    final cachedInstance = metadata.instanceId.trim();
    if (expectedInstance.isNotEmpty || cachedInstance.isNotEmpty) {
      return expectedInstance.isNotEmpty && expectedInstance == cachedInstance;
    }
    final expectedCreated = expectedCreatedAt.trim();
    final cachedCreated = metadata.createdAt.trim();
    return expectedCreated.isNotEmpty && expectedCreated == cachedCreated;
  }

  Future<void> clear(String baseUrl, String sessionId, String instanceId, String createdAt) async {
    final cacheKeyStr = key(baseUrl, sessionId, instanceId, createdAt);
    if (cacheKeyStr.isNotEmpty) {
      await _deleteKey(cacheKeyStr);
    }
  }

  Future<void> _clearMatching(String normalizedBaseUrl, String sessionId) async {
    if (!cacheDir.existsSync()) return;
    final files = cacheDir.listSync();
    for (var entity in files) {
      if (entity is File && entity.path.endsWith('.json')) {
        final metadata = await _readMetadata(entity);
        if (metadata != null &&
            normalizedBaseUrl == WebTermUrls.normalizeBaseUrl(metadata.baseUrl) &&
            sessionId == metadata.sessionId) {
          await _deletePairForMetadataFile(entity);
        }
      }
    }
  }

  Future<void> _deleteKey(String keyStr) async {
    _deleteFileSync(_frameFile(keyStr));
    _deleteFileSync(_metaFile(keyStr));
  }

  Future<void> _deletePairForMetadataFile(File metaFile) async {
    final path = metaFile.path;
    if (!path.endsWith('.json')) return;
    final baseName = path.substring(0, path.length - '.json'.length);
    _deleteFileSync(metaFile);
    _deleteFileSync(File('$baseName.frames'));
    _deleteFileSync(File('$baseName.snapshot.gz'));
  }

  void _deleteFileSync(File file) {
    if (file.existsSync()) {
      try {
        file.deleteSync();
      } catch (_) {}
    }
  }

  File _frameFile(String keyStr) => File('${cacheDir.path}/$keyStr.frames');
  File _metaFile(String keyStr) => File('${cacheDir.path}/$keyStr.json');
  File _snapshotFile(String keyStr) => File('${cacheDir.path}/$keyStr.snapshot.gz');

  static String key(String baseUrl, String sessionId, String instanceId, String createdAt) {
    final identity = SessionIdentity.value(sessionId, instanceId, createdAt);
    if (identity.isEmpty) return '';
    return sha256Of('${WebTermUrls.normalizeBaseUrl(baseUrl)}#$identity');
  }

  static String sha256Of(String text) {
    return sha256.convert(utf8.encode(text)).toString();
  }
}
