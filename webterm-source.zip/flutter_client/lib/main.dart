import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:path_provider/path_provider.dart';

import 'core/crash_reporter.dart';
import 'core/providers/app_providers.dart';
import 'core/router/app_router.dart';
import 'core/theme/app_theme.dart';
import 'core/storage/terminal_disk_cache.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // 1. 安装崩溃日志记录器
  await CrashReporter.install();

  // 2. 初始化 SharedPreferences
  final sharedPrefs = await SharedPreferences.getInstance();

  // 3. 初始化终端磁盘缓存（二级缓存）
  final docsDir = await getApplicationDocumentsDirectory();
  final diskCache = TerminalDiskCache(docsDir);

  runApp(
    ProviderScope(
      overrides: [
        // 重写 SharedPreferences Provider 和 DiskCache Provider 以注入初始化后的实例
        sharedPreferencesProvider.overrideWithValue(sharedPrefs),
        diskCacheProvider.overrideWithValue(diskCache),
      ],
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp.router(
      title: 'WebTerm',
      theme: AppTheme.darkTheme,
      routerConfig: goRouter,
      debugShowCheckedModeBanner: false,
    );
  }
}
