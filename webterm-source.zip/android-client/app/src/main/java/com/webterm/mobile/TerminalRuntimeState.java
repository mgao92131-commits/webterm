package com.webterm.mobile;

import android.widget.TextView;

import com.termux.terminal.TerminalSession;

final class TerminalRuntimeState {
    private String baseUrl;
    private String cookie;
    private String sessionId;
    private boolean relayDevice;
    private String relayDeviceId = "";
    private String instanceId = "";
    private String createdAt = "";
    private long lastSeq;
    private int columns;
    private int rows;

    boolean hasSession() {
        return sessionId != null;
    }

    String baseUrl() {
        return baseUrl;
    }

    String cookie() {
        return cookie;
    }

    String sessionId() {
        return sessionId;
    }

    boolean isRelayDevice() {
        return relayDevice;
    }

    String relayDeviceId() {
        return relayDeviceId;
    }

    String instanceId() {
        return instanceId;
    }

    String createdAt() {
        return createdAt;
    }

    long lastSeq() {
        return lastSeq;
    }

    void resetLastSeq() {
        lastSeq = 0;
    }

    int columns() {
        return columns;
    }

    int rows() {
        return rows;
    }

    void setServerSession(String baseUrl, String cookie, String sessionId, boolean relayDevice, String relayDeviceId) {
        this.baseUrl = baseUrl;
        this.cookie = cookie;
        this.sessionId = sessionId;
        this.relayDevice = relayDevice;
        this.relayDeviceId = relayDeviceId == null ? "" : relayDeviceId;
    }

    void applyLaunchState(TerminalLaunchState launchState) {
        createdAt = launchState.createdAt;
        instanceId = launchState.instanceId;
        lastSeq = launchState.lastSeq;
        columns = launchState.columns;
        rows = launchState.rows;
    }

    void updateIdentity(String instanceId, String createdAt) {
        if (instanceId != null && !instanceId.isEmpty()) {
            this.instanceId = instanceId;
        }
        if (createdAt != null && !createdAt.isEmpty()) {
            this.createdAt = createdAt;
        }
    }

    void updateSize(int columns, int rows) {
        this.columns = columns;
        this.rows = rows;
    }

    void onOutput(long seq, byte[] bytes) {
        if (seq <= 0) return;
        lastSeq = seq;
    }

    void clearServerSession() {
        baseUrl = null;
        cookie = null;
        sessionId = null;
        relayDevice = false;
        relayDeviceId = "";
    }

    void clearTerminalDetails() {
        instanceId = "";
        createdAt = "";
        columns = 0;
        rows = 0;
        lastSeq = 0;
    }

    void clearPersistence() {
    }

    TerminalCacheCoordinator.Snapshot snapshot(TextView titleView, TextView subtitleView, TerminalSession terminalSession) {
        TerminalCacheCoordinator.Snapshot snapshot = new TerminalCacheCoordinator.Snapshot();
        snapshot.baseUrl = baseUrl;
        snapshot.cookie = cookie;
        snapshot.sessionId = sessionId;
        snapshot.instanceId = instanceId;
        snapshot.termTitle = titleView == null ? "" : String.valueOf(titleView.getText());
        snapshot.sessionName = subtitleView == null ? "" : String.valueOf(subtitleView.getText());
        snapshot.createdAt = createdAt;
        snapshot.terminalSession = terminalSession;
        snapshot.lastSeq = lastSeq;
        snapshot.columns = columns;
        snapshot.rows = rows;
        snapshot.diskMetadata = diskMetadata(titleView, subtitleView);
        return snapshot;
    }

    TerminalDiskCache.Metadata diskMetadata(TextView titleView, TextView subtitleView) {
        if (baseUrl == null || sessionId == null) return null;
        TerminalDiskCache.Metadata metadata = new TerminalDiskCache.Metadata();
        metadata.baseUrl = baseUrl;
        metadata.sessionId = sessionId;
        metadata.instanceId = instanceId == null ? "" : instanceId;
        metadata.createdAt = createdAt == null ? "" : createdAt;
        metadata.termTitle = titleView == null ? "" : String.valueOf(titleView.getText());
        metadata.sessionName = subtitleView == null ? "" : String.valueOf(subtitleView.getText());
        metadata.columns = columns;
        metadata.rows = rows;
        metadata.lastSeq = lastSeq;
        return metadata;
    }
}
