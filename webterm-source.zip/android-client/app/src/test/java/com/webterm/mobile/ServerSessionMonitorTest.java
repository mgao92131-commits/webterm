package com.webterm.mobile;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Test;

public class ServerSessionMonitorTest {
    @Test
    public void dispatchMessageDeliversSessionTitleUpdates() {
        RecordingListener listener = new RecordingListener();

        ServerSessionMonitor.dispatchMessage(
            "{\"type\":\"session\",\"data\":{\"id\":\"mac:s1\",\"termTitle\":\"vim README.md\",\"cwd\":\"/tmp\"}}",
            listener
        );

        assertNotNull(listener.session);
        assertEquals("mac:s1", listener.session.optString("id"));
        assertEquals("vim README.md", listener.session.optString("termTitle"));
        assertEquals("/tmp", listener.session.optString("cwd"));
    }

    @Test
    public void dispatchMessageDeliversSessionListsWithTitles() {
        RecordingListener listener = new RecordingListener();

        ServerSessionMonitor.dispatchMessage(
            "{\"type\":\"sessions\",\"data\":[{\"id\":\"mac:s1\",\"termTitle\":\"zsh\"},{\"id\":\"mac:s2\",\"termTitle\":\"top\"}]}",
            listener
        );

        assertNotNull(listener.sessions);
        assertEquals(2, listener.sessions.length());
        assertEquals("zsh", listener.sessions.optJSONObject(0).optString("termTitle"));
        assertEquals("top", listener.sessions.optJSONObject(1).optString("termTitle"));
    }

    @Test
    public void dispatchMessagePrefixesRelaySessionIds() {
        RecordingListener listener = new RecordingListener();

        ServerSessionMonitor.dispatchMessage(
            "{\"type\":\"session\",\"data\":{\"id\":\"s2\",\"termTitle\":\"top\"}}",
            listener,
            "d1"
        );

        assertNotNull(listener.session);
        assertEquals("d1:s2", listener.session.optString("id"));
        assertEquals("top", listener.session.optString("termTitle"));
    }

    private static final class RecordingListener implements ServerSessionMonitor.Listener {
        JSONArray sessions;
        JSONObject session;

        @Override
        public void onMonitorConnected() {
        }

        @Override
        public void onMonitorPollingFallback() {
        }

        @Override
        public void onMonitorSessions(JSONArray sessions) {
            this.sessions = sessions;
        }

        @Override
        public void onMonitorSession(JSONObject session) {
            this.session = session;
        }

        @Override
        public void onMonitorSessionClosed(String sessionId) {
        }

        @Override
        public void onMonitorDevices(JSONArray devices) {
        }

        @Override
        public void onMonitorError(String errorMsg) {
        }
    }
}
